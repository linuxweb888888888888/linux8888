/**
 * HitBTC AI Scalper - Headless Node.js Edition
 * Run this script to execute the bot 24/7 without a browser.
 * Usage: node headless.js
 */

const fetch = require('node-fetch');
const ccxt = require('ccxt');

// --- CONFIGURATION ---
const MIN_QTY = 0.001;
const RAW_SYMBOL = 'ATOMUSDT_PERP'; // HitBTC Exchange ID
let CCXT_SYMBOL = 'ATOM/USDT:USDT'; // Default CCXT Unified Symbol (Will be resolved dynamically)

const TAKER_FEE_RATE = 0.0009;
const LEVERAGE = 20;
const RSI_PERIOD = 14;
const EMA_PERIOD = 20;
const BB_PERIOD = 20;
const BB_MULTIPLIER = 2;
const SCALING_FACTOR = 100_000_000;
const MIN_ROIE_PCT = 0.0015;
const MAX_WALLET_USAGE_PCT = 0.60;

const API_KEY = '-3Mn7DL8P20iTj7QPoOSgyATuDcF-87h';
const API_SECRET = 'WzxCckLuICMXcjdRL-CbgcsbpGXHePcs';

// --- TERMINAL COLORS ---
const C = {
    Reset: "\x1b[0m",
    Red: "\x1b[31m",
    Green: "\x1b[32m",
    Yellow: "\x1b[33m",
    Blue: "\x1b[34m",
    Cyan: "\x1b[36m",
    Dim: "\x1b[2m"
};

// --- STATE ---
let priceHistory = [];
let rsiHistory = [];
let ccxtExchange = null;
let market = { symbol: RAW_SYMBOL, mid: 0, bid: 0, ask: 0, timestamp: 0 };
let activePosition = null;
let wallet = { 
    balance: 0, 
    usedMargin: 0, 
    freeMargin: 0, 
    totalProfit: 0, 
    efficiencyIndex: 90 
};

// --- HELPERS ---
function log(msg, type='INFO') {
    const ts = new Date().toLocaleTimeString();
    let color = C.Reset;
    if (type === 'ERROR') color = C.Red;
    if (type === 'SUCCESS') color = C.Green;
    if (type === 'WARNING') color = C.Yellow;
    if (type === 'SYSTEM') color = C.Blue;
    if (type === 'TRADE') color = C.Cyan;

    console.log(`${C.Dim}[${ts}]${C.Reset} ${color}[${type}]${C.Reset} ${msg}`);
}

function calculateRSI(prices) {
  if (prices.length < RSI_PERIOD + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = prices.length - RSI_PERIOD; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff >= 0) gains += diff; else losses -= diff;
  }
  if (losses === 0) return 100;
  const rs = gains / losses;
  return 100 - (100 / (1 + rs));
}

function calculateBollingerBands(prices) {
    if (prices.length < BB_PERIOD) return { position: 0.5 };
    const slice = prices.slice(-BB_PERIOD);
    const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
    const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / slice.length;
    const stdDev = Math.sqrt(variance);
    const upper = mean + (BB_MULTIPLIER * stdDev);
    const lower = mean - (BB_MULTIPLIER * stdDev);
    const current = prices[prices.length - 1];
    let position = 0.5;
    if (upper - lower !== 0) position = (current - lower) / (upper - lower);
    return { upper, lower, position };
}

function calculateDivergence(prices, rsis) {
    if (prices.length < 10 || rsis.length < 10) return 0;
    const pC = prices[prices.length - 1], pP = prices[prices.length - 6];
    const rC = rsis[rsis.length - 1], rP = rsis[rsis.length - 6];
    if (pC < pP && rC > rP + 2) return 1;
    if (pC > pP && rC < rP - 2) return -1;
    return 0;
}

// --- CORE ---
async function init() {
    try {
        log('Initializing CCXT for HitBTC Futures...', 'SYSTEM');
        // Switch to 'swap' for Perpetuals on V3 API
        ccxtExchange = new ccxt.hitbtc({ 
            apiKey: API_KEY, 
            secret: API_SECRET, 
            options: { defaultType: 'swap' } 
        });
        
        log('Loading Markets...', 'SYSTEM');
        const markets = await ccxtExchange.loadMarkets();
        
        // Dynamic Symbol Resolution
        // Look for the market where 'id' equals RAW_SYMBOL ('ATOMUSDT_PERP')
        const marketInfo = Object.values(markets).find(m => m.id === RAW_SYMBOL);
        
        if (marketInfo) {
            CCXT_SYMBOL = marketInfo.symbol;
            log(`Mapped ${RAW_SYMBOL} -> ${CCXT_SYMBOL}`, 'SUCCESS');
        } else {
            log(`Could not resolve ${RAW_SYMBOL}. Trying default: ${CCXT_SYMBOL}`, 'WARNING');
            // Fallback: check if default exists
            if (!markets[CCXT_SYMBOL]) {
                log(`Symbol ${CCXT_SYMBOL} not found in loaded markets. Available examples: ${Object.keys(markets).slice(0,3).join(', ')}`, 'ERROR');
            }
        }

    } catch (e) { log(`Init Failed: ${e.message}`, 'ERROR'); }
}

async function updateMarket() {
    try {
        const ticker = await ccxtExchange.fetchTicker(CCXT_SYMBOL);
        market.mid = (ticker.bid + ticker.ask) / 2;
        market.bid = ticker.bid;
        market.ask = ticker.ask;
        market.timestamp = Date.now();
        priceHistory.push(market.mid);
        if (priceHistory.length > 100) priceHistory.shift();
    } catch (e) {
        log(`Market Data Error: ${e.message}`, 'ERROR');
    }
}

async function syncWallet() {
    try {
        const bal = await ccxtExchange.fetchBalance({ type: 'swap' });
        const usdt = bal['USDT'];
        if (usdt) {
            wallet.balance = usdt.total || 0;
            wallet.freeMargin = usdt.free || 0;
            wallet.usedMargin = usdt.used || 0;
        }
    } catch (e) {}
}

async function syncPosition() {
    try {
        // Fetch positions using unified symbol
        const positions = await ccxtExchange.fetchPositions([CCXT_SYMBOL]);
        const pos = positions.find(p => p.symbol === CCXT_SYMBOL);
        if (pos && parseFloat(pos.contracts) > 0) {
            activePosition = {
                direction: pos.side.toUpperCase(),
                entryPrice: parseFloat(pos.entryPrice),
                size: parseFloat(pos.contracts),
                unrealizedPnL: parseFloat(pos.unrealizedPnl || 0),
                timestamp: activePosition ? activePosition.timestamp : Date.now(),
                highestPnL: activePosition ? Math.max(activePosition.highestPnL, parseFloat(pos.unrealizedPnl)) : parseFloat(pos.unrealizedPnl)
            };
        } else {
            if (activePosition) log('Position closed detected.', 'INFO');
            activePosition = null;
        }
    } catch (e) {}
}

async function order(side, amount) {
    try {
        log(`EXECUTING: ${side.toUpperCase()} ${amount} ${CCXT_SYMBOL}...`, 'TRADE');
        const ord = await ccxtExchange.createMarketOrder(CCXT_SYMBOL, side, amount);
        log(`Order Filled: ${ord.id} @ ${ord.price}`, 'SUCCESS');
    } catch (e) { log(`Order Failed: ${e.message}`, 'ERROR'); }
}

// --- STRATEGY LOOP ---
let tickCount = 0;

async function loop() {
    tickCount++;
    await updateMarket();
    await syncWallet();
    await syncPosition();

    // Calculations
    const rsi = calculateRSI(priceHistory);
    rsiHistory.push(rsi);
    if (rsiHistory.length > 50) rsiHistory.shift();
    
    const bb = calculateBollingerBands(priceHistory);
    const divergence = calculateDivergence(priceHistory, rsiHistory);
    
    // Status Log (Every 5 ticks or ~10s)
    if (tickCount % 5 === 0) {
        const posStr = activePosition 
            ? `POS: ${activePosition.direction} ${activePosition.size} (PnL: ${activePosition.unrealizedPnL.toFixed(5)})` 
            : 'POS: NONE';
        log(`PRICE: ${market.mid.toFixed(4)} | RSI: ${rsi.toFixed(1)} | ${posStr} | BAL: ${wallet.balance.toFixed(4)}`, 'SYSTEM');
    }

    // Logic Triggers
    const atLower = bb.position <= 0.1;
    const atUpper = bb.position >= 0.9;
    const isOversold = rsi < 35;
    const isOverbought = rsi > 65;
    let dir = 'NEUTRAL';
    let conf = 0;

    if (atLower && isOversold) { dir = 'LONG'; conf = 75 + (divergence===1?15:0); }
    else if (atUpper && isOverbought) { dir = 'SHORT'; conf = 75 + (divergence===-1?15:0); }
    
    // Execution Logic
    if (!activePosition) {
         if (dir !== 'NEUTRAL' && conf > 55) {
             const walletUsage = wallet.usedMargin / (wallet.balance || 1);
             if (walletUsage < MAX_WALLET_USAGE_PCT && wallet.freeMargin > 0.0001) {
                 log(`SIGNAL: ${dir} (${conf}%) - Entering...`, 'TRADE');
                 await order(dir === 'LONG' ? 'buy' : 'sell', MIN_QTY);
             } else {
                 if (tickCount % 5 === 0) log(`Signal ${dir} ignored. Usage: ${(walletUsage*100).toFixed(1)}%`, 'WARNING');
             }
         }
    } else {
        // PnL Management
        const pnl = activePosition.unrealizedPnL;
        const size = activePosition.size;
        const entry = activePosition.entryPrice;
        const fee = (size * entry * TAKER_FEE_RATE) * 2;
        const target = Math.max(fee * 3, (size * entry * MIN_ROIE_PCT));
        
        // Log PnL status occasionally
        if (tickCount % 10 === 0) {
            log(`Target: ${target.toFixed(6)} | Current: ${pnl.toFixed(6)} | High: ${activePosition.highestPnL.toFixed(6)}`, 'INFO');
        }

        if (pnl > target * 1.1) { // Force Take Profit
             log(`Take Profit Triggered! PnL ${pnl.toFixed(6)} > Target ${target.toFixed(6)}`, 'SUCCESS');
             await order(activePosition.direction === 'LONG' ? 'sell' : 'buy', size);
        } else if (activePosition.highestPnL > target && pnl < target * 0.8) { // Ratchet
             log(`Ratchet Stop Triggered. Locked Profit.`, 'WARNING');
             await order(activePosition.direction === 'LONG' ? 'sell' : 'buy', size);
        } else if (pnl < -0.0005 && conf > 80 && dir !== activePosition.direction) { // Stop & Reverse
             log(`Stop & Reverse Triggered on Strong Signal (${conf}%)`, 'WARNING');
             await order(activePosition.direction === 'LONG' ? 'sell' : 'buy', size);
        }
        
        // De-Risking
        if (wallet.usedMargin / wallet.balance > 0.85 && pnl < -0.0005) {
             log('High Margin Usage + Drawdown. De-Risking (Trim).', 'WARNING');
             await order(activePosition.direction === 'LONG' ? 'sell' : 'buy', MIN_QTY);
        }
    }
}

module.exports = { start: loop }; 

// Auto-start if run directly
if (require.main === module) {
    console.log(`${C.Green}Starting HitBTC Headless Bot...${C.Reset}`);
    init().then(() => setInterval(loop, 2000));
}