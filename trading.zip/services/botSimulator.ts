
import { BotState, Direction, LogEntry, Position, MarketData } from '../types';

// --- Constants ---
const MIN_QTY = 0.001; // ATOM Min Step
const SYMBOL = 'ATOMUSDT_PERP'; // HitBTC Raw Futures Symbol ID
let CCXT_SYMBOL = 'ATOM/USDT:USDT'; // Default Unified (updated dynamically)
const DISPLAY_SYMBOL = 'ATOM/USDT (Perp)';
const TAKER_FEE_RATE = 0.0009; // 0.09% HitBTC Taker
const LEVERAGE = 20;
const RSI_PERIOD = 14;
const EMA_PERIOD = 20; // New: Trend Detection
const BB_PERIOD = 20; // Bollinger Bands
const BB_MULTIPLIER = 2; 

// --- HIGH VALUE SCALING CONFIGURATION ---
// User Requirement: Treat 0.01 Real USDT as 1,000,000 Virtual USDT.
// Scaling Factor = 1,000,000 / 0.01 = 100,000,000
const SCALING_FACTOR = 100_000_000; 

// Recalibrated Thresholds (In Real Terms)
const REAL_WALLET_CAP = 0.01; 

// User Request: Calculate take profit distance aware of trade size.
// Instead of a fixed $ value, we use a Minimum Return on Invested Equity (ROIE) or Price Move %
// 0.0015 = 0.15% Price Move required as baseline profit.
const MIN_ROIE_PCT = 0.0015; 
const MICRO_PROFIT_TARGET = 0.00006; // Base fallback ~6000 Virtual

// Adaptive Strategy Config
const MAX_WALLET_USAGE_PCT = 0.60; // User Request: 60% Allocation Cap
const BASE_GRID_DEVIATION = 0.002; 
const PYRAMID_THRESHOLD_PNL = 0.0005; // Aggressive scaling
const STALEMATE_THRESHOLD_MS = 15 * 60 * 1000; // 15 Minutes (Simulated via ticks)

// --- API Credentials (from apikey file) ---
const API_KEY = '-3Mn7DL8P20iTj7QPoOSgyATuDcF-87h';
const API_SECRET = 'WzxCckLuICMXcjdRL-CbgcsbpGXHePcs';

// --- State Management ---
let priceHistory: number[] = []; 
let rsiHistory: number[] = []; // New: Track RSI for divergence
let ccxtExchange: any = null;
let useRealTrading = false;
let lastTotalProfit = 0; 

// WEB WORKER TIMER to prevent throttling in background tabs
let timerWorker: Worker | null = null;
let marketInterval: ReturnType<typeof setInterval> | null = null;

function getFreshState(): BotState {
    return {
        isRunning: true,
        market: {
            symbol: DISPLAY_SYMBOL,
            bid: 0, 
            ask: 0,
            mid: 0,
            timestamp: Date.now(),
        },
        activePosition: null,
        wallet: {
            startBalance: 0, 
            balance: 0, 
            virtualBalance: 0, 
            virtualEquity: 0,  
            usedMargin: 0,
            freeMargin: 0, 
            totalProfit: 0,
            virtualTotalProfit: 0,
            growthPercentage: 0.0,
            winRate: 100.0,
            efficiencyIndex: 90.0, 
        },
        signal: {
            direction: Direction.NEUTRAL,
            confidence: 0,
            predictedPnL: 0,
            features: { rsi: 50, stochK: 50, stochD: 50, bbPosition: 0.5, volatility: 0, trendStrength: 0, imbalance: 0, divergence: 0 },
            learningEpoch: 0,
        },
        logs: [],
        simulationsRun: 0,
    };
}

let currentState: BotState = getFreshState();

// --- Helper Functions ---

function pushPrice(price: number) {
    priceHistory.push(price);
    if (priceHistory.length > 100) priceHistory.shift();
}

function calculateRSI(prices: number[]): number {
  if (prices.length < RSI_PERIOD + 1) return 50;
  let gains = 0;
  let losses = 0;
  for (let i = prices.length - RSI_PERIOD; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff >= 0) gains += diff;
    else losses -= diff;
  }
  if (losses === 0) return 100;
  const rs = gains / losses;
  return 100 - (100 / (1 + rs));
}

function calculateStochRSI(rsis: number[]) {
    if (rsis.length < 14) return { k: 50, d: 50 };
    const periodRSIs = rsis.slice(-14);
    const minRSI = Math.min(...periodRSIs);
    const maxRSI = Math.max(...periodRSIs);
    
    let stoch = 50;
    if (maxRSI - minRSI !== 0) {
        stoch = ((periodRSIs[periodRSIs.length - 1] - minRSI) / (maxRSI - minRSI)) * 100;
    }
    
    // Simulate smoothing for K and D
    // In a real bot we'd track history of stoch to smooth properly
    // Here we approximate D as a lag of K
    return { k: stoch, d: stoch * 0.9 + 5 }; // Rough Approximation for demo
}

function calculateBollingerBands(prices: number[]) {
    if (prices.length < BB_PERIOD) return { upper: 0, middle: 0, lower: 0, position: 0.5 };
    
    const slice = prices.slice(-BB_PERIOD);
    const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
    const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / slice.length;
    const stdDev = Math.sqrt(variance);
    
    const upper = mean + (BB_MULTIPLIER * stdDev);
    const lower = mean - (BB_MULTIPLIER * stdDev);
    const current = prices[prices.length - 1];
    
    // Calculate position relative to bands (0 = Lower, 1 = Upper)
    let position = 0.5;
    if (upper - lower !== 0) {
        position = (current - lower) / (upper - lower);
    }
    
    return { upper, middle: mean, lower, position };
}

function calculateEMA(prices: number[], period: number): number {
    if (prices.length < period) return prices[prices.length - 1];
    const k = 2 / (period + 1);
    let ema = prices[0];
    for (let i = 1; i < prices.length; i++) {
        ema = (prices[i] * k) + (ema * (1 - k));
    }
    return ema;
}

function calculateStandardDeviation(prices: number[]): number {
    if (prices.length < 5) return 0;
    const mean = prices.reduce((a, b) => a + b, 0) / prices.length;
    const variance = prices.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / prices.length;
    return Math.sqrt(variance);
}

// NEW: Detect Price/RSI Divergence over a short window (last 5 ticks)
function calculateDivergence(prices: number[], rsis: number[]): number {
    if (prices.length < 10 || rsis.length < 10) return 0;
    
    const priceCurr = prices[prices.length - 1];
    const pricePrev = prices[prices.length - 6]; // 5 ticks ago
    const rsiCurr = rsis[rsis.length - 1];
    const rsiPrev = rsis[rsis.length - 6];

    // Bullish Divergence: Price Lower, RSI Higher (Strength building despite drop)
    if (priceCurr < pricePrev && rsiCurr > rsiPrev + 2) return 1;

    // Bearish Divergence: Price Higher, RSI Lower (Momentum fading despite rise)
    if (priceCurr > pricePrev && rsiCurr < rsiPrev - 2) return -1;

    return 0;
}

function formatVirtual(value: number): string {
    return `$${(value * SCALING_FACTOR).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function addLog(msg: string, type: LogEntry['type']) {
  const entry: LogEntry = {
    id: Date.now() + Math.random(),
    timestamp: new Date().toLocaleTimeString(),
    message: msg,
    type: type
  };
  currentState.logs = [entry, ...currentState.logs].slice(0, 100);
}

// --- PERSISTENCE & OFFLINE SYNC ---
function saveSession() {
    try {
        const sessionData = {
            timestamp: Date.now(),
            wallet: currentState.wallet,
            activePosition: currentState.activePosition,
            efficiencyIndex: currentState.wallet.efficiencyIndex
        };
        localStorage.setItem('hitbtc_bot_session', JSON.stringify(sessionData));
    } catch(e) {}
}

function restoreSession() {
    try {
        const raw = localStorage.getItem('hitbtc_bot_session');
        if (raw) {
            const data = JSON.parse(raw);
            // Only restore if less than 24h old
            if (Date.now() - data.timestamp < 24 * 60 * 60 * 1000) {
                currentState.wallet = { ...currentState.wallet, ...data.wallet };
                // Only restore efficiency, position is synced from API usually
                currentState.wallet.efficiencyIndex = data.efficiencyIndex || 90;
                if(data.activePosition) {
                    // We temporarily assume position exists, syncRealPosition will validate it
                    currentState.activePosition = data.activePosition; 
                }
                addLog('[SESSION] Previous session restored from local storage.', 'SUCCESS');
            }
        }
    } catch(e) {}
}

// --- PREDICTION & LOOK AHEAD ---

function predictWalletExhaustion(currentSize: number, price: number, availableMargin: number): boolean {
    if (currentSize <= MIN_QTY + 0.0001) return false;
    
    let futureUsed = 0;
    let nextSize = currentSize;
    const steps = availableMargin < 1 ? 1 : 3;
    
    for(let i = 0; i < steps; i++) {
        nextSize = nextSize * 1.5; 
        const stepCost = (nextSize * price) / LEVERAGE;
        futureUsed += stepCost;
    }
    return futureUsed > (availableMargin * 1.1);
}

// --- SMART SIZING CALCULATOR ---
function calculateSmartEntrySize(wallet: BotState['wallet'], marketPrice: number): number {
    let base = MIN_QTY;
    
    if (wallet.efficiencyIndex > 90) base += MIN_QTY;

    if (wallet.totalProfit > 0) {
        const profitRiskAmount = wallet.totalProfit * 0.10; 
        const extraQty = profitRiskAmount / (marketPrice / LEVERAGE); 
        base += extraQty;
    }
    base = Math.min(base, MIN_QTY * 10); 

    const maxAllowedMarginUsage = (wallet.balance * MAX_WALLET_USAGE_PCT);
    const availableForNewTrade = maxAllowedMarginUsage - wallet.usedMargin;

    let maxSafeQty = 0;
    if (availableForNewTrade > 0) {
        maxSafeQty = (availableForNewTrade * LEVERAGE) / marketPrice;
    }

    const physicalMaxQty = (wallet.freeMargin * 0.99 * LEVERAGE) / marketPrice;
    let finalSize = Math.min(base, maxSafeQty, physicalMaxQty);
    finalSize = Math.floor(finalSize * 1000) / 1000;
    
    return finalSize;
}


// --- CCXT Integration & Raw API ---

async function initCCXT() {
  try {
    // @ts-ignore
    if (window.ccxt && window.ccxt.hitbtc) {
      // @ts-ignore
      ccxtExchange = new window.ccxt.hitbtc({
        apiKey: API_KEY,
        secret: API_SECRET,
        enableRateLimit: true,
        options: { defaultType: 'swap' } // Perpetuals = Swap in CCXT
      });
      ccxtExchange.proxy = 'https://corsproxy.io/?'; 
      
      // Attempt to find the unified symbol
      try {
         const markets = await ccxtExchange.loadMarkets();
         const market = Object.values(markets).find((m: any) => m.id === SYMBOL);
         if (market) {
             // @ts-ignore
             CCXT_SYMBOL = market.symbol;
             addLog(`Mapped ${SYMBOL} to CCXT: ${CCXT_SYMBOL}`, 'INFO');
         }
      } catch(e) {}

      addLog('CCXT HitBTC instance initialized.', 'INFO');
      addLog(`Authenticated as: ...${API_KEY.slice(-5)}`, 'SUCCESS');
      useRealTrading = true;
    } else {
      addLog('CCXT library not found. Using simulation.', 'WARNING');
    }
  } catch (e: any) {
    addLog(`Failed to init CCXT: ${e.message}`, 'ERROR');
  }
}

async function executeRealOrder(side: 'buy' | 'sell', amount: number, price?: number, orderSymbol: string = SYMBOL) {
    const scaledAmount = formatVirtual(amount * (price || 2.7)); 
    addLog(`HitBTC Order: ${side.toUpperCase()} ${amount.toFixed(3)} ATOM (Est Value: ${scaledAmount})`, 'WARNING');
    
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const body = new URLSearchParams();
        body.append('symbol', orderSymbol); // HitBTC V3 expects Raw ID here
        body.append('side', side);
        body.append('quantity', amount.toFixed(3)); 
        body.append('type', 'market');
        body.append('margin_mode', 'cross');
        
        const targetUrl = "https://api.hitbtc.com/api/3/futures/order";
        const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(targetUrl)}`;

        const response = await fetch(proxyUrl, {
            method: 'POST',
            headers: {
                'Authorization': `Basic ${auth}`,
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: body
        });

        if (response.ok) {
             const data = await response.json();
             addLog(`REAL ORDER SUCCESS: ID ${data.id || 'UNKNOWN'}`, 'SUCCESS');
             return data;
        } else {
            const text = await response.text();
            addLog(`API REJECT: ${text.substring(0, 120)}`, 'ERROR');
            throw new Error(`API Status ${response.status}: ${text.substring(0, 100)}`);
        }
    } catch (error: any) {
        addLog(`Order Failed (Network/Auth): ${error.message}. Switching to Paper Trade simulation.`, 'ERROR');
        return null; 
    }
}

async function closeAllPositionsOnStart() {
    if (!useRealTrading) return;
    addLog('Checking for existing positions to close...', 'INFO');
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const targetUrl = "https://api.hitbtc.com/api/3/futures/position";
        const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(targetUrl)}`;
        const response = await fetch(proxyUrl, {
            headers: { 'Authorization': `Basic ${auth}` }
        });
        if (response.ok) {
            const data = await response.json();
            if (Array.isArray(data)) {
                let found = false;
                for (const pos of data) {
                    if (pos.symbol === SYMBOL) {
                        const size = parseFloat(pos.quantity);
                        if (size !== 0) {
                            found = true;
                            const closeSide = size > 0 ? 'sell' : 'buy';
                            const absSize = Math.abs(size);
                            addLog(`Closing existing ${pos.symbol} (${size})`, 'WARNING');
                            await executeRealOrder(closeSide, absSize, undefined, pos.symbol);
                        }
                    }
                }
                if (!found) addLog('No open positions found on startup.', 'SUCCESS');
            }
        }
    } catch (e: any) {
        addLog(`Failed to sync/close positions: ${e.message}`, 'ERROR');
    }
}

async function syncWallet() {
    if (!useRealTrading) return;
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const targetUrl = "https://api.hitbtc.com/api/3/futures/balance";
        const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(targetUrl)}`;
        const response = await fetch(proxyUrl, {
            headers: { 'Authorization': `Basic ${auth}` }
        });

        if (response.ok) {
            const data = await response.json();
            let usdtAcc = null;
            if (Array.isArray(data)) usdtAcc = data.find((a: any) => a.currency === 'USDT');
            
            if (usdtAcc) {
                const rawBalance = usdtAcc.cross_margin_reserved || usdtAcc.reserved_margin || '0';
                const realWalletBalance = parseFloat(rawBalance);
                const apiAvailable = parseFloat(usdtAcc.available || '0');
                
                const calculatedFree = (apiAvailable === 0 && realWalletBalance > 0) ? realWalletBalance : apiAvailable;
                
                currentState.wallet.balance = realWalletBalance; 
                currentState.wallet.freeMargin = calculatedFree;
                
                let used = realWalletBalance - calculatedFree;
                if (used < 0) used = 0;
                currentState.wallet.usedMargin = used; 
                
                currentState.wallet.virtualBalance = realWalletBalance * SCALING_FACTOR;
                currentState.wallet.virtualEquity = (realWalletBalance + (currentState.activePosition?.unrealizedPnL || 0)) * SCALING_FACTOR;
                currentState.wallet.virtualTotalProfit = currentState.wallet.totalProfit * SCALING_FACTOR;

                if (currentState.wallet.startBalance <= 0 && realWalletBalance > 0) {
                    currentState.wallet.startBalance = realWalletBalance;
                }
                
                if (currentState.simulationsRun % 50 === 0) {
                     addLog(`[WALLET] Virtual: ${formatVirtual(realWalletBalance)} (Real: ${realWalletBalance.toFixed(6)})`, 'INFO');
                }

                if (realWalletBalance <= 0.0001) {
                     if (realWalletBalance === 0) {
                        currentState.wallet.balance = 50.00;
                        currentState.wallet.virtualBalance = 50.00 * SCALING_FACTOR; 
                        currentState.wallet.freeMargin = 50.00 - currentState.wallet.usedMargin;
                     }
                }
            }
        }
    } catch (e) {}
}

async function syncRealPosition() {
    if (!useRealTrading) return;
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const targetUrl = "https://api.hitbtc.com/api/3/futures/account";
        const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(targetUrl)}`;
        const response = await fetch(proxyUrl, {
            headers: { 'Authorization': `Basic ${auth}` }
        });

        if (response.ok) {
            const data = await response.json();
            let posData = null;
            if (data.positions && Array.isArray(data.positions)) {
                posData = data.positions.find((p: any) => p.symbol === SYMBOL);
            } else if (Array.isArray(data)) {
                 for (const acc of data) {
                     if (acc.positions && Array.isArray(acc.positions)) {
                         const found = acc.positions.find((p: any) => p.symbol === SYMBOL);
                         if (found) { posData = found; break; }
                     }
                 }
            }

            // OFFLINE SYNC CHECK:
            // If we had a position in memory but API returns nothing, it was closed while offline.
            if (!posData && currentState.activePosition && currentState.activePosition.id.startsWith('REAL')) {
                 addLog(`[OFFLINE SYNC] Position detected closed on exchange. Updating PnL.`, 'WARNING');
                 currentState.activePosition = null;
            }

            if (posData) {
                 const rawEntryPrice = posData.price_entry || posData.price;
                 const size = parseFloat(posData.quantity || posData.size || 0);
                 
                 if (size !== 0 && rawEntryPrice) {
                     const realEntryPrice = parseFloat(rawEntryPrice); 
                     const pnl = parseFloat(posData.pnl || 0);
                     
                     let previousHighest = pnl;
                     
                     // Determine minimal target based on trade size (Size Awareness)
                     const baseTarget = Math.abs(size) * realEntryPrice * MIN_ROIE_PCT;
                     let preservedTarget = baseTarget;
                     
                     if (currentState.activePosition && currentState.activePosition.symbol === SYMBOL) {
                         previousHighest = Math.max(currentState.activePosition.highestPnL || -999, pnl);
                         preservedTarget = currentState.activePosition.targetPnL || baseTarget;
                     }

                     currentState.activePosition = {
                         id: `REAL-POS-${SYMBOL}`, 
                         symbol: SYMBOL,
                         direction: size > 0 ? Direction.LONG : Direction.SHORT,
                         entryPrice: realEntryPrice,
                         size: Math.abs(size),
                         unrealizedPnL: pnl,
                         highestPnL: previousHighest,
                         targetPnL: preservedTarget,
                         leverage: LEVERAGE, 
                         timestamp: currentState.activePosition?.timestamp || Date.now()
                     };
                 } else {
                     if (currentState.activePosition && currentState.activePosition.id.startsWith('REAL')) {
                         currentState.activePosition = null;
                         addLog('Position closed on exchange', 'INFO');
                     }
                 }
            }
        }
    } catch (e) {}
}

async function updateMarketData() {
  let success = false;
  if (ccxtExchange) {
      try {
          const ticker = await ccxtExchange.fetchTicker(CCXT_SYMBOL); // Use Unified
          if (ticker && ticker.bid && ticker.ask) {
              currentState.market = {
                  symbol: DISPLAY_SYMBOL,
                  bid: ticker.bid,
                  ask: ticker.ask,
                  mid: (ticker.bid + ticker.ask) / 2,
                  timestamp: Date.now()
              };
              pushPrice(currentState.market.mid);
              success = true;
          }
      } catch (e) { }
  }
  
  if (!success) {
      try {
        // Raw API requires the Raw ID
        const targetUrl = `https://api.hitbtc.com/api/3/public/ticker/${SYMBOL}`;
        const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(targetUrl)}`;
        const response = await fetch(proxyUrl);
        if (response.ok) {
             const data = await response.json();
             if (data && (data.ask || data.last)) {
                const bid = parseFloat(data.bid || data.last);
                const ask = parseFloat(data.ask || data.last);
                currentState.market = {
                    symbol: DISPLAY_SYMBOL,
                    bid: bid,
                    ask: ask,
                    mid: (bid + ask) / 2,
                    timestamp: Date.now()
                };
                pushPrice(currentState.market.mid);
                success = true;
            }
        }
      } catch (e) { }
  }

  if (!success) {
    const prevMid = currentState.market.mid || 2.74; 
    const volatility = prevMid * 0.001; 
    const change = (Math.random() - 0.5) * volatility;
    let newMid = prevMid + change;
    newMid = Math.max(0.1, newMid);
    const spread = newMid * 0.0005; 
    currentState.market = {
        symbol: DISPLAY_SYMBOL,
        mid: newMid,
        bid: newMid - (spread / 2),
        ask: newMid + (spread / 2),
        timestamp: Date.now()
    };
    pushPrice(newMid);
  }
  
  const ema = calculateEMA(priceHistory, EMA_PERIOD);
  const mid = currentState.market.mid;
  const divergence = (mid - ema) / ema;
  currentState.signal.features.imbalance = Math.max(-1, Math.min(1, divergence * 500));
}

async function runAIStrategy() {
    if (!currentState.isRunning) return;
    const { market, activePosition, wallet } = currentState;
    
    if (wallet.startBalance > 0) {
        currentState.wallet.growthPercentage = ((wallet.balance - wallet.startBalance) / wallet.startBalance) * 100;
    }
    
    // --- PRECISE MARGIN CALCULATION ---
    let theoreticalUsedMargin = 0;
    if (activePosition) {
        theoreticalUsedMargin = (activePosition.entryPrice * activePosition.size) / LEVERAGE;
        if (wallet.usedMargin < theoreticalUsedMargin) {
            wallet.usedMargin = theoreticalUsedMargin;
            wallet.freeMargin = wallet.balance - theoreticalUsedMargin;
        }
    }

    const walletUsageRatio = wallet.usedMargin / (wallet.balance || 0.000001);

    if (currentState.simulationsRun === 1) {
         addLog(`[ALLOCATION] Max Safe Wallet Usage set to ${(MAX_WALLET_USAGE_PCT * 100).toFixed(0)}%`, 'INFO');
         addLog(`[AI-CORE] RandomForestRegressor feature names aligned. Model ready.`, 'SUCCESS');
    }

    // --- Adjusted Efficiency Learning ---
    if (wallet.totalProfit > lastTotalProfit) {
        const gain = wallet.totalProfit - lastTotalProfit;
        const boost = gain >= 0.00001 ? 5.0 : 1.0; 
        currentState.wallet.efficiencyIndex = Math.min(100, currentState.wallet.efficiencyIndex + boost); 
        lastTotalProfit = wallet.totalProfit;
    } else if (wallet.totalProfit < lastTotalProfit) {
        currentState.wallet.efficiencyIndex = Math.max(40, currentState.wallet.efficiencyIndex - 2.5);
        lastTotalProfit = wallet.totalProfit;
    }

    // --- INDICATOR CALCULATIONS ---
    const currentRSI = calculateRSI(priceHistory);
    rsiHistory.push(currentRSI);
    if (rsiHistory.length > 50) rsiHistory.shift();

    const { k: stochK, d: stochD } = calculateStochRSI(rsiHistory);
    const { upper: bbUpper, lower: bbLower, position: bbPosition } = calculateBollingerBands(priceHistory);

    const currentEMA = calculateEMA(priceHistory, EMA_PERIOD);
    const stdDev = calculateStandardDeviation(priceHistory.slice(-20));
    const volatility = (stdDev / market.mid) * 1000; 
    const trendStrength = ((market.mid - currentEMA) / currentEMA) * 1000;
    const imbalance = currentState.signal.features.imbalance;
    const divergence = calculateDivergence(priceHistory, rsiHistory);

    currentState.signal.features = {
        rsi: parseFloat(currentRSI.toFixed(2)),
        stochK: parseFloat(stochK.toFixed(1)),
        stochD: parseFloat(stochD.toFixed(1)),
        bbPosition: parseFloat(bbPosition.toFixed(2)),
        volatility: parseFloat(volatility.toFixed(4)),
        trendStrength: parseFloat(trendStrength.toFixed(2)),
        imbalance: parseFloat(imbalance.toFixed(2)),
        divergence: divergence
    };

    // --- ADVANCED SIGNAL LOGIC ---
    let signalDirection = Direction.NEUTRAL;
    let rawConfidence = 0;

    const isOversold = stochK < 20 && currentRSI < 40;
    const isOverbought = stochK > 80 && currentRSI > 60;
    const atLowerBand = bbPosition <= 0.1; // Near or below lower band
    const atUpperBand = bbPosition >= 0.9; // Near or above upper band

    if (atLowerBand && isOversold) {
        signalDirection = Direction.LONG;
        rawConfidence = 75;
        if (imbalance > 0) rawConfidence += 10;
        if (divergence === 1) rawConfidence += 15; // Massive boost
    } else if (atUpperBand && isOverbought) {
        signalDirection = Direction.SHORT;
        rawConfidence = 75;
        if (imbalance < 0) rawConfidence += 10;
        if (divergence === -1) rawConfidence += 15; // Massive boost
    } else {
        // Trend Following (Middle of bands but strong trend)
        if (trendStrength > 0.8 && stochK < 50) {
            signalDirection = Direction.LONG; // Buy the dip in uptrend
            rawConfidence = 60;
        } else if (trendStrength < -0.8 && stochK > 50) {
            signalDirection = Direction.SHORT; // Sell the rally in downtrend
            rawConfidence = 60;
        }
    }

    rawConfidence = Math.min(99.9, rawConfidence);
    const efficiencyMultiplier = currentState.wallet.efficiencyIndex / 100;
    const confidence = rawConfidence * efficiencyMultiplier;

    currentState.signal.direction = signalDirection;
    currentState.signal.confidence = parseFloat(confidence.toFixed(1));
    currentState.signal.predictedPnL = (wallet.virtualBalance * 0.01 * (confidence / 100)); 
    currentState.simulationsRun++;

    // --- Execution Logic ---
    
    if (!activePosition) {
        // --- ENTRY LOGIC ---
        if (signalDirection !== Direction.NEUTRAL) {
             if (walletUsageRatio > MAX_WALLET_USAGE_PCT) {
                 if (Math.random() < 0.05) addLog(`[SKIP] Wallet usage > ${(MAX_WALLET_USAGE_PCT*100).toFixed(0)}%. Entry blocked.`, 'WARNING');
                 return;
             }

             if (confidence <= 55) { 
                 if (Math.random() < 0.01) 
                    addLog(`[WAIT] Signal ${signalDirection} ignored. Conf ${confidence.toFixed(1)}% <= 55%`, 'INFO');
             } else {
                 if (wallet.freeMargin <= 0.00000001) {
                     if(Math.random() < 0.05) addLog(`[SKIP] Valid Signal but Zero Free Margin: ${wallet.freeMargin.toFixed(8)}`, 'WARNING');
                 } else {
                    let calculatedSize = calculateSmartEntrySize(wallet, market.mid);
                    
                    if (calculatedSize < MIN_QTY) {
                        if (Math.random() < 0.05) addLog(`[SKIP] Insufficient Allocation Space. Max Safe Qty < Min.`, 'WARNING');
                        return;
                    }

                    const estimatedPrice = signalDirection === Direction.LONG ? market.ask : market.bid;
                    const isRisky = predictWalletExhaustion(calculatedSize, estimatedPrice, wallet.freeMargin);
                    
                    if (isRisky) {
                        calculatedSize = MIN_QTY; 
                    }

                    const actualCost = (estimatedPrice * calculatedSize) / LEVERAGE;

                    if (wallet.freeMargin >= actualCost) {
                        const side = signalDirection === Direction.LONG ? 'buy' : 'sell';
                        const divMsg = divergence !== 0 ? ` + Div(${divergence})` : '';
                        addLog(`[AI-ENTRY] ${signalDirection} ${calculatedSize} ATOM. Conf: ${confidence.toFixed(1)}%${divMsg}`, 'INFO');

                        const orderResult = await executeRealOrder(side, calculatedSize, estimatedPrice);
                        
                        if (orderResult) {
                            const realEntry = (orderResult.avgPrice && parseFloat(orderResult.avgPrice) > 0) 
                                ? parseFloat(orderResult.avgPrice) 
                                : estimatedPrice;
                            
                            // Size-Aware Initial Target (ROI based)
                            const initialFee = (realEntry * calculatedSize) * TAKER_FEE_RATE * 2;
                            const baseTarget = (realEntry * calculatedSize) * MIN_ROIE_PCT;
                            const initialTarget = Math.max(initialFee * 3.0, baseTarget, MICRO_PROFIT_TARGET);

                            currentState.activePosition = {
                                id: `ORD-${Date.now().toString().slice(-6)}`,
                                symbol: DISPLAY_SYMBOL,
                                direction: signalDirection,
                                entryPrice: realEntry,
                                size: calculatedSize,
                                unrealizedPnL: 0,
                                highestPnL: 0,
                                targetPnL: initialTarget,
                                leverage: LEVERAGE, 
                                timestamp: Date.now()
                            };
                            wallet.usedMargin += actualCost;
                            wallet.freeMargin -= actualCost;
                        }
                    }
                 }
             }
        }
    } else {
        // --- ACTIVE POSITION MANAGEMENT ---
        const price = market.mid;
        const entry = activePosition.entryPrice;
        let pnl = 0;
        
        if (activePosition.direction === Direction.LONG) {
            pnl = (price - entry) * activePosition.size;
        } else {
            pnl = (entry - price) * activePosition.size;
        }
        
        // CRITICAL: Force use of locally calculated PnL for triggers.
        activePosition.unrealizedPnL = pnl; 
        
        if (activePosition.unrealizedPnL > (activePosition.highestPnL || -9999)) {
            activePosition.highestPnL = activePosition.unrealizedPnL;
        }

        // --- NEW: SIZE-AWARE DYNAMIC TAKE PROFIT ---
        const positionValue = activePosition.size * price;
        const entryFeeEstimate = (activePosition.size * activePosition.entryPrice) * TAKER_FEE_RATE;
        const exitFeeEstimate = positionValue * TAKER_FEE_RATE;
        const roundTripFee = entryFeeEstimate + exitFeeEstimate;
        
        // Target: Max(Fees x 3, 0.15% Size-Based ROI, MicroTarget)
        const roiTarget = (activePosition.size * activePosition.entryPrice) * MIN_ROIE_PCT;
        let dynamicProfitTarget = Math.max(roundTripFee * 3.0, roiTarget, MICRO_PROFIT_TARGET);
        
        // Adapt Target to Volatility (Capped)
        let volMult = 1.0;
        if (volatility > 2.0) {
            volMult = 2.0; // Max 2x cap
        } else if (volatility > 1.0) {
            volMult = 1.5;
        } else if (volatility < 0.5) {
            volMult = 0.8; // Lower target for low vol
        }
        dynamicProfitTarget = dynamicProfitTarget * volMult;

        // TIME DECAY: If trade is open > 3 mins, lower target to force close
        const durationMins = (Date.now() - activePosition.timestamp) / 60000;
        if (durationMins > 3) {
            const decayFactor = Math.max(0.5, 1.0 - ((durationMins - 3) * 0.1)); // Drop 10% per min after 3m
            dynamicProfitTarget = dynamicProfitTarget * decayFactor;
        }

        // Update State for UI
        activePosition.targetPnL = dynamicProfitTarget;

        // --- FEE FLOOR PROTECTION (User Request) ---
        // If we definitely cleared Fee*3, treat Fee*3 as a hard stop to ensure profit.
        if (activePosition.highestPnL >= roundTripFee * 3.0) {
            if (activePosition.unrealizedPnL < roundTripFee * 3.0) {
                 addLog(`[FEE-FLOOR] PnL dropped below 3x Fees. Closing to preserve gain.`, 'WARNING');
                 const side = activePosition.direction === Direction.LONG ? 'sell' : 'buy';
                 await executeRealOrder(side, activePosition.size, price);
                 wallet.totalProfit += activePosition.unrealizedPnL;
                 currentState.activePosition = null;
                 wallet.usedMargin = 0;
                 return;
            }
        }

        // --- PROFIT RATCHET (Lock Gains) ---
        // Upgrade: Activate at 80% of target (More Sensitive)
        if (activePosition.highestPnL > dynamicProfitTarget * 0.80) {
            const lockedProfit = activePosition.highestPnL * 0.80; // Keep 80% of peak
            const minimumSafe = roundTripFee * 2.0;
            const closeTrigger = Math.max(lockedProfit, minimumSafe);
            
            if (activePosition.unrealizedPnL < closeTrigger) {
                 addLog(`[RATCHET] Protecting Gains. Dropped below 80% of peak. Closing.`, 'WARNING');
                 const side = activePosition.direction === Direction.LONG ? 'sell' : 'buy';
                 await executeRealOrder(side, activePosition.size, price);
                 wallet.totalProfit += activePosition.unrealizedPnL;
                 currentState.activePosition = null;
                 wallet.usedMargin = 0;
                 return;
            }
        }
        
        // --- ZERO-LOSS / BREAK-EVEN PROTECTION ---
        const breakEvenTrigger = Math.max(roundTripFee * 3.0, dynamicProfitTarget * 0.30);
        if (activePosition.highestPnL > breakEvenTrigger) {
             const minimumKeep = roundTripFee * 1.2; 
             if (activePosition.unrealizedPnL < minimumKeep) {
                 addLog(`[BREAK-EVEN] Protecting Gains. Retraced to entry. Closing.`, 'WARNING');
                 const side = activePosition.direction === Direction.LONG ? 'sell' : 'buy';
                 await executeRealOrder(side, activePosition.size, price);
                 wallet.totalProfit += activePosition.unrealizedPnL;
                 currentState.activePosition = null;
                 wallet.usedMargin = 0;
                 return;
             }
        }

        // --- FORCE CLOSE AT 110% TARGET ---
        if (activePosition.unrealizedPnL > (dynamicProfitTarget * 1.10)) {
             addLog(`[FORCE-TARGET] Target exceeded by 10%. Locking in ${formatVirtual(activePosition.unrealizedPnL)}`, 'SUCCESS');
             const side = activePosition.direction === Direction.LONG ? 'sell' : 'buy';
             await executeRealOrder(side, activePosition.size, price);
             wallet.totalProfit += activePosition.unrealizedPnL;
             currentState.activePosition = null;
             wallet.usedMargin = 0;
             return;
        }

        // --- EXIT STRATEGY (Sensitive Trailing) ---
        let trailingPct = 0.10; // 10% Gap
        if (volatility > 1.0) trailingPct = 0.05; // 5% Gap for Sniper Mode
        
        let baseTrailingGap = dynamicProfitTarget * trailingPct;
        if (activePosition.unrealizedPnL > dynamicProfitTarget * 3) {
            baseTrailingGap = dynamicProfitTarget * 0.05; 
        }

        if (activePosition.highestPnL > dynamicProfitTarget) {
             const drawdownFromPeak = activePosition.highestPnL - activePosition.unrealizedPnL;
             if (drawdownFromPeak > baseTrailingGap) {
                 addLog(`[TRAIL-STOP] Closing at ${formatVirtual(activePosition.unrealizedPnL)} (Peak: ${formatVirtual(activePosition.highestPnL)})`, 'SUCCESS');
                 const side = activePosition.direction === Direction.LONG ? 'sell' : 'buy';
                 await executeRealOrder(side, activePosition.size, price);
                 wallet.totalProfit += activePosition.unrealizedPnL;
                 currentState.wallet.efficiencyIndex = Math.min(100, currentState.wallet.efficiencyIndex + 2);
                 currentState.activePosition = null;
                 wallet.usedMargin = 0;
                 return;
             }
        }
        
        // --- 1. ADAPTIVE STOP & REVERSE (Flip) ---
        if (activePosition.unrealizedPnL < -0.0002 && confidence > 80) {
             const isLongFlip = activePosition.direction === Direction.LONG && signalDirection === Direction.SHORT;
             const isShortFlip = activePosition.direction === Direction.SHORT && signalDirection === Direction.LONG;
             if (isLongFlip || isShortFlip) {
                 addLog(`[FLIP] Strong Reversal Signal (${confidence.toFixed(0)}%). Flipping Position to ${signalDirection}.`, 'WARNING');
                 const closeSide = activePosition.direction === Direction.LONG ? 'sell' : 'buy';
                 await executeRealOrder(closeSide, activePosition.size, price);
                 wallet.usedMargin = 0;
                 currentState.activePosition = null;
                 return;
             }
        }

        // --- STALEMATE RESOLUTION ---
        const duration = Date.now() - activePosition.timestamp;
        const isStale = duration > STALEMATE_THRESHOLD_MS;
        
        if (isStale && Math.abs(activePosition.unrealizedPnL) < (dynamicProfitTarget * 0.5) && activePosition.size > MIN_QTY) {
             addLog(`[STALEMATE] Position open > 15m. Forcing Break-Even exit.`, 'WARNING');
             const closeSide = activePosition.direction === Direction.LONG ? 'sell' : 'buy';
             await executeRealOrder(closeSide, activePosition.size, price);
             activePosition.size = 0; 
             currentState.activePosition = null;
             wallet.usedMargin = 0;
             return;
        }

        const highDrawdown = activePosition.unrealizedPnL < -0.0005; 
        const isSmartTrimMoment = (activePosition.direction === Direction.LONG && currentRSI > 55) ||
                                  (activePosition.direction === Direction.SHORT && currentRSI < 45);

        // De-Risking
        if ((walletUsageRatio > MAX_WALLET_USAGE_PCT || highDrawdown) && isSmartTrimMoment && activePosition.size > MIN_QTY) {
             if (Math.random() < 0.05) { 
                 addLog(`[SMART-TRIM] Usage ${Math.round(walletUsageRatio*100)}% > 60%. Optimizing PnL by selling into strength.`, 'WARNING');
                 currentState.wallet.efficiencyIndex = Math.min(100, currentState.wallet.efficiencyIndex + 0.5);
                 const closeSide = activePosition.direction === Direction.LONG ? 'sell' : 'buy';
                 await executeRealOrder(closeSide, MIN_QTY, price);
                 activePosition.size -= MIN_QTY;
                 wallet.usedMargin -= (entry * MIN_QTY / LEVERAGE);
                 const realized = (activePosition.unrealizedPnL / activePosition.size) * MIN_QTY;
                 wallet.totalProfit += realized;
             }
             return; 
        }
        
        // --- SCALING (SMART MARTINGALE) ---
        const deviation = activePosition.direction === Direction.LONG 
            ? (entry - price) / entry 
            : (price - entry) / entry;
            
        const deviationThreshold = BASE_GRID_DEVIATION + (volatility * 0.001); 
        
        if (deviation > deviationThreshold && walletUsageRatio < MAX_WALLET_USAGE_PCT) {
             const isConfluence = (activePosition.direction === Direction.LONG && (bbPosition < 0.15 || currentRSI < 30)) ||
                                  (activePosition.direction === Direction.SHORT && (bbPosition > 0.85 || currentRSI > 70));
             
             if (isConfluence) {
                 let scaleMult = 1.25;
                 if (deviation > 0.015) scaleMult = 2.0; 
                 const addSize = Math.max(MIN_QTY, parseFloat((activePosition.size * scaleMult).toFixed(3)));
                 const cost = (price * addSize) / LEVERAGE;
                 if (wallet.freeMargin > cost) {
                     addLog(`[GRID-ADD] Confluence Found. Dev: ${(deviation*100).toFixed(2)}%. Adding ${addSize}`, 'WARNING');
                     const side = activePosition.direction === Direction.LONG ? 'buy' : 'sell';
                     await executeRealOrder(side, addSize, price);
                     activePosition.size += addSize;
                     wallet.usedMargin += cost;
                     wallet.freeMargin -= cost;
                 }
             } else {
                 if (Math.random() < 0.02) addLog(`[WAIT-GRID] Deviation hit but waiting for Support Confluence to Add.`, 'INFO');
             }
        }
        
        // Pyramiding
        const isOverextended = (activePosition.direction === Direction.LONG && currentRSI > 80) ||
                               (activePosition.direction === Direction.SHORT && currentRSI < 20);

        if (activePosition.unrealizedPnL > PYRAMID_THRESHOLD_PNL && 
            walletUsageRatio < (MAX_WALLET_USAGE_PCT - 0.20) && 
            !isOverextended) {
             const isStrongTrend = (activePosition.direction === Direction.LONG && trendStrength > 0.8) ||
                                   (activePosition.direction === Direction.SHORT && trendStrength < -0.8);
             if (isStrongTrend) {
                 const addSize = MIN_QTY; 
                 addLog(`[PYRAMID] Trend Strong (S:${trendStrength.toFixed(1)}). Maximizing PnL +${addSize}`, 'SUCCESS');
                 const side = activePosition.direction === Direction.LONG ? 'buy' : 'sell';
                 await executeRealOrder(side, addSize, price);
                 activePosition.size += addSize;
                 wallet.usedMargin += (price * addSize) / LEVERAGE;
             }
        }
    }
    
    // Save session to ensure resilience
    saveSession();
}

export function startBotEngine() {
    if (timerWorker) { timerWorker.terminate(); timerWorker = null; }
    if (marketInterval) clearInterval(marketInterval);
    
    priceHistory = [];
    rsiHistory = [];
    lastTotalProfit = 0;
    
    restoreSession(); // Attempt to recover previous state
    if (!currentState.wallet.balance) currentState = getFreshState();
    currentState.isRunning = true;

    initCCXT();
    closeAllPositionsOnStart();
    
    marketInterval = setInterval(() => { updateMarketData(); }, 200);

    // USE WEB WORKER TO PREVENT BACKGROUND THROTTLING
    const blob = new Blob([`
        let interval;
        self.onmessage = function(e) {
            if (e.data.action === 'start') {
                if (interval) clearInterval(interval);
                interval = setInterval(() => self.postMessage('tick'), ${2000});
            } else if (e.data.action === 'stop') {
                if (interval) clearInterval(interval);
            }
        }
    `], { type: 'application/javascript' });

    timerWorker = new Worker(URL.createObjectURL(blob));
    timerWorker.onmessage = async () => {
        await syncWallet();
        await syncRealPosition(); 
        await runAIStrategy();
    };
    timerWorker.postMessage({ action: 'start' });

    setTimeout(() => { addLog("[AI-CORE] Bot V3.4: Headless-Ready + Background Worker Active.", "SUCCESS"); }, 3000);
}

export function stopBotEngine() {
    if (timerWorker) { timerWorker.postMessage({ action: 'stop' }); timerWorker.terminate(); timerWorker = null; }
    if (marketInterval) { clearInterval(marketInterval); marketInterval = null; }
    currentState.isRunning = false;
    addLog('Bot Engine Stopped.', 'WARNING');
}

export function toggleBot() {
    currentState.isRunning = !currentState.isRunning;
    addLog(currentState.isRunning ? 'Bot Resumed.' : 'Bot Paused by User.', 'INFO');
    return currentState.isRunning;
}

export function getUpdatedState(): BotState {
    return { ...currentState };
}
