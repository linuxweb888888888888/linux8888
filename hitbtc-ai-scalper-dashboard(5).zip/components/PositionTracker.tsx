
import React from 'react';
import { Position, Direction } from '../types';
import { ArrowUpCircle, ArrowDownCircle, Activity, AlertCircle, TrendingUp } from 'lucide-react';

interface PositionTrackerProps {
  position: Position | null;
  currentPrice: number;
}

// Scaling Factor for Display (Matches Backend)
const SCALING_FACTOR = 100_000_000;

const PositionTracker: React.FC<PositionTrackerProps> = ({ position, currentPrice }) => {
  if (!position) {
    return (
      <div className="bg-slate-800 rounded-lg p-6 text-center border border-slate-700 border-dashed h-full flex flex-col justify-center items-center">
        <div className="bg-slate-900 p-4 rounded-full mb-3">
          <Activity className="w-8 h-8 text-slate-600" />
        </div>
        <h3 className="text-slate-300 font-medium">No Active Positions</h3>
        <p className="text-slate-500 text-sm mt-2">AI is scanning for high-value signals...</p>
        <div className="mt-4 flex gap-2">
            <span className="text-xs bg-slate-700 text-slate-400 px-2 py-1 rounded">Scanning Bid: {currentPrice.toFixed(5)}</span>
        </div>
      </div>
    );
  }

  const isProfit = position.unrealizedPnL >= 0;
  const pnlColor = isProfit ? 'text-emerald-400' : 'text-rose-400';
  const pnlBg = isProfit ? 'bg-emerald-500/10' : 'bg-rose-500/10';
  const isLong = position.direction === Direction.LONG;
  
  // Virtual PnL Calculation
  const virtualPnL = position.unrealizedPnL * SCALING_FACTOR;
  const highestVirtualPnL = (position.highestPnL || 0) * SCALING_FACTOR;
  
  const fmtVirtual = (val: number) => `$${Math.abs(val).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  return (
    <div className="bg-slate-800 rounded-lg border border-slate-700 overflow-hidden">
      <div className="bg-slate-900/50 px-4 py-3 border-b border-slate-700 flex justify-between items-center">
        <div className="flex items-center gap-2">
          {isLong ? (
            <ArrowUpCircle className="w-5 h-5 text-emerald-400" />
          ) : (
            <ArrowDownCircle className="w-5 h-5 text-rose-400" />
          )}
          <span className={`font-bold ${isLong ? 'text-emerald-400' : 'text-rose-400'}`}>
            {position.direction} {position.symbol}
          </span>
          <span className="text-xs bg-blue-900/30 text-blue-300 px-2 py-0.5 rounded border border-blue-800">
            {position.leverage}x Cross
          </span>
        </div>
        <div className="text-xs text-slate-500 font-mono">{position.id}</div>
      </div>

      <div className="p-5 grid grid-cols-2 gap-6">
        <div>
          <p className="text-slate-500 text-xs uppercase tracking-wider mb-1">Entry Price</p>
          <p className="text-xl font-mono text-white">{position.entryPrice.toFixed(6)}</p>
        </div>
        <div>
          <p className="text-slate-500 text-xs uppercase tracking-wider mb-1">Mark Price</p>
          <p className="text-xl font-mono text-blue-200">{currentPrice.toFixed(6)}</p>
        </div>
        <div>
          <p className="text-slate-500 text-xs uppercase tracking-wider mb-1">Size (ATOM)</p>
          <p className="text-xl font-mono text-white">{position.size.toFixed(3)}</p>
        </div>
        <div>
           <p className="text-slate-500 text-xs uppercase tracking-wider mb-1">Margin Used</p>
           <p className="text-xl font-mono text-slate-300">{((position.entryPrice * position.size) / position.leverage).toFixed(4)}</p>
        </div>
      </div>

      <div className={`px-5 py-4 border-t border-slate-700 ${pnlBg} flex justify-between items-center`}>
        <div>
          <p className="text-slate-400 text-xs uppercase">Projected PnL (Virtual)</p>
          <div className="flex flex-col">
              <span className={`text-2xl font-bold ${pnlColor} tracking-tight`}>
                {position.unrealizedPnL > 0 ? '+' : '-'}{fmtVirtual(virtualPnL)}
              </span>
              <span className="text-xs text-slate-500 font-mono mt-1">
                  Real: {position.unrealizedPnL > 0 ? '+' : ''}{position.unrealizedPnL.toFixed(7)} USDT
              </span>
          </div>
        </div>
        
        <div className="flex flex-col items-end">
            <div className="text-xs text-slate-500 uppercase mb-1 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" /> Peak Profit
            </div>
            <span className="text-emerald-500/70 font-mono text-sm">
                +{fmtVirtual(highestVirtualPnL)}
            </span>
        </div>
      </div>
      
      {position.unrealizedPnL < -0.0005 && (
          <div className="px-4 py-2 bg-amber-900/20 text-amber-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-3 h-3" />
              <span>Warning: High Virtual Drawdown (-${fmtVirtual(virtualPnL)}). Adding Liquidity...</span>
          </div>
      )}
    </div>
  );
};

export default PositionTracker;
