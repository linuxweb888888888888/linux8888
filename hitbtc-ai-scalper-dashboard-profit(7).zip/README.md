# HitBTC AI Scalper (Node.js Version)

This is a standalone, production-ready Node.js script for the AI Scalping Bot. It connects directly to the HitBTC API to perform live futures trading.

## Strategy Overview

The bot employs a high-frequency scalping strategy based on a combination of technical indicators and adaptive position management:

-   **Signal Generation**: Uses RSI, EMA, and market volatility to find high-probability entry points.
-   **Adaptive Position Sizing**: Starts with a minimum position size and scales based on performance.
-   **Martingale Averaging**: Adds to losing positions at key deviation points to lower the average entry price.
-   **De-Risking**: Actively reduces position size (trims) if wallet usage exceeds a safe threshold (60%).
-   **Fee-Aware Take Profit**: Sets profit targets based on a multiple of the actual trading fees to ensure every closed trade is profitable.

## Setup

1.  **Install Node.js**: Ensure you have Node.js (version 16 or newer) installed on your system.
2.  **Install Dependencies**: Open your terminal in the project directory and run:
    ```bash
    npm install
    ```
3.  **Configure API Keys**:
    -   Rename or copy `apikey.json.example` to `apikey.json`.
    -   Open `apikey.json` and replace the placeholder values with your real HitBTC API key and secret.

    ```json
    {
      "apiKey": "YOUR_API_KEY_HERE",
      "apiSecret": "YOUR_API_SECRET_HERE"
    }
    ```

## Running the Bot

To start the bot, run the following command in your terminal:

```bash
npm start
```

The bot will initialize, close any existing positions for the target symbol, and begin its main trading loop. You will see live status updates directly in your console.

## Disclaimer

**HIGH RISK WARNING:** Trading cryptocurrencies, especially with leverage, is extremely risky and can result in the complete loss of your funds. This script is provided for educational purposes and is not financial advice. Use at your own risk. The authors are not responsible for any financial losses. Always test with small amounts before committing significant capital.
