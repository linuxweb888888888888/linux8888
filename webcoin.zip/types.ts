
export enum BotStatus {
  IDLE = 'IDLE',
  RUNNING = 'RUNNING',
  STOPPED = 'STOPPED',
}

export interface GridConfig {
  mode: 'LIVE' | 'PAPER';
  apiKey: string;
  apiSecret: string;
  symbol: string;
  lowerPrice: number;
  upperPrice: number;
  grids: number;
  leverage: number;
  investment: number;
  type: 'LONG' | 'SHORT' | 'NEUTRAL';
  takeProfitUSD: number;
  feeRate: number;
  useProxy: boolean;
  autoAdjust: boolean; // Enable Auto-Learning/Infinite Grid
}

export interface GridLine {
  id: string;
  price: number;
  type: 'BUY' | 'SELL';
  status: 'OPEN' | 'FILLED';
}

export interface MarketData {
  time: string;
  price: number;
  volume: number;
}

export interface BotStats {
  totalProfit: number;
  currentCyclePnL: number;
  activeOrders: number;
  filledOrders: number;
  uptime: number;
  startPrice: number;
  currentPosition: number;
  avgEntryPrice: number;
  totalFees: number;
  buyFillCount: number;
  sellFillCount: number;
  currentVolatility?: number; // Added for stats
}

export interface AIAnalysisResult {
  recommendation: string;
  suggestedLower: number;
  suggestedUpper: number;
  suggestedGrids: number;
  reasoning: string;
}

// HitBTC API Types

export interface HitBTCTicker {
  symbol: string;
  ask: string;
  bid: string;
  last: string;
  timestamp: string;
}

export interface HitBTCBalance {
  currency: string;
  available: string;
  reserved: string;
  reserved_margin: string;
  cross_margin_reserved?: string;
}

export interface HitBTCPosition {
  id: string;
  symbol: string;
  quantity: string;
  price_entry: string;
  pnl: string;
  margin_mode: string;
  liquidation_price?: string;
}

export interface HitBTCAccount {
  symbol: string;
  type: string;
  currencies: {
    code: string;
    margin_balance: string;
    reserved_orders: string;
    reserved_positions: string;
  }[];
  positions?: HitBTCPosition[];
}
