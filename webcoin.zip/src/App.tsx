
import React, { useState, useEffect } from 'react';
import { getUpdatedState, startBotEngine, stopBotEngine, toggleBot } from './services/botSimulator';
import { BotState, Direction } from './types';
import MetricCard from './components/MetricCard';
import PositionTracker from './components/PositionTracker';
import LogConsole from './components/LogConsole';
import PriceChart from './components/PriceChart';
import { 
  Cpu, 
  Zap, 
  TrendingUp, 
  Wallet, 
  Activity, 
  Server,
  PlayCircle,
  StopCircle,
  BarChart3,
  ShieldAlert,
  MoveHorizontal,
  Layers,
  Lock,
  BrainCircuit
} from 'lucide-react';

const App: React.FC = () => {
  const [botState, setBotState] = useState<BotState | null>(null);

  useEffect(() => {
    startBotEngine();
    const interval = setInterval(() => {
      setBotState(getUpdatedState());
    }, 200); 
    return () => {
        clearInterval(interval);
        stopBotEngine(); 
    };
  }, []);

  if (!botState) return (
    <div className="bg-slate-950 h-screen w-full flex flex-col items-center justify-center text-slate-500 gap-4">
      <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
      <span className="font-mono text-sm">Booting HitBTC AI Scalper v4.4 (Synced)...</span>
    </div>
  );

  const pnlColor = botState.wallet.totalProfit >= 0 ? 'text-emerald-400' : 'text-rose-400';
  const walletUsage = botState.wallet.usedMargin / (botState.wallet.balance || 1);
  let riskColor = 'text-emerald-400';
  let riskLabel = 'LOW';
  
  if (walletUsage > 0.5) { riskColor = 'text-amber-400'; riskLabel = 'MED'; }
  if (walletUsage > 0.75) { riskColor = 'text-rose-400'; riskLabel = 'HIGH'; }

  const fmtMoney = (val: number) => `$${val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  const divVal = botState.signal.features.divergence;
  const regime = botState.signal.marketRegime;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-indigo-500/30">
      
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-lg shadow-lg shadow-indigo-500/20">
              <Cpu className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg tracking-tight">HitBTC AI Scalper v4.4</h1>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                High-Value Simulation (1M USDT)
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-6 mr-4 text-sm">
                <div className="flex flex-col items-end">
                    <span className="text-slate-500 text-xs">Virtual Equity (USDT)</span>
                    <span className="font-mono font-bold text-emerald-400">{fmtMoney(botState.wallet.virtualBalance)}</span>
                </div>
                <div className="flex flex-col items-end">
                    <span className="text-slate-500 text-xs">Real Balance</span>
                    <span className="font-mono text-slate-500">{botState.wallet.balance.toFixed(6)}</span>
                </div>
            </div>
            
            <button 
              onClick={toggleBot}
              className={`flex items-center gap-2 px-4 py-2 rounded-md font-medium text-sm transition-all ${botState.isRunning ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20' : 'bg-emerald-500 text-white hover:bg-emerald-600'}`}
            >
              {botState.isRunning ? <><StopCircle className="w-4 h-4" /> Pause AI</> : <><PlayCircle className="w-4 h-4" /> Resume AI</>}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Top Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <MetricCard 
            title="Projected Portfolio" 
            value={fmtMoney(botState.wallet.virtualBalance)}
            subValue={`Real: ${botState.wallet.balance.toFixed(5)} USDT`}
            icon={<Wallet className="w-5 h-5" />}
            trend={botState.wallet.growthPercentage >= 0 ? 'up' : 'down'}
          />
          <MetricCard 
            title="Signal Confidence" 
            value={`${botState.signal.confidence.toFixed(1)}%`} 
            subValue={`Memory: ${botState.signal.memorySize || 0} Patterns`}
            color={botState.signal.confidence > 75 ? "text-emerald-400" : "text-amber-400"}
            icon={<Zap className="w-5 h-5" />}
          />
           <MetricCard 
            title="Total Virtual PnL" 
            value={`${botState.wallet.virtualTotalProfit > 0 ? '+' : ''}${fmtMoney(botState.wallet.virtualTotalProfit)}`}
            subValue={`Real PnL: ${botState.wallet.totalProfit.toFixed(6)}`}
            color={pnlColor}
            trend={botState.wallet.totalProfit >= 0 ? 'up' : 'down'}
            icon={<TrendingUp className="w-5 h-5" />}
          />
           {/* CHANGED: MARKET PRICE -> MARGIN USAGE */}
           <MetricCard 
            title="Margin Usage" 
            value={`${(walletUsage * 100).toFixed(2)}%`}
            subValue={`Used: ${botState.wallet.usedMargin.toFixed(5)} USDT`}
            color={riskColor}
            icon={<Lock className="w-5 h-5" />}
            trend={walletUsage > 0.5 ? 'up' : 'neutral'}
          />
        </div>

        {/* Main Dashboard Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column: Chart, Trade & Signals */}
          <div className="lg:col-span-2 space-y-6">
             {/* CHART COMPONENT */}
             <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider flex gap-2 items-center">
                         <TrendingUp className="w-4 h-4" /> Real-Time Price Action
                    </h3>
                    <span className="text-xs font-mono text-slate-500">M1 Timeframe (Live)</span>
                </div>
                <PriceChart data={botState.priceHistory} activePosition={botState.activePosition} height={200} />
             </div>

            <div className="flex items-center justify-between mb-2">
              <h2 className="text-slate-300 font-medium flex items-center gap-2">
                <Server className="w-4 h-4" /> Live Position Management
              </h2>
              <div className="flex gap-2">
                 <span className={`text-xs px-2 py-1 rounded border font-bold ${
                    regime === 'TRENDING' ? 'bg-emerald-900/30 border-emerald-600 text-emerald-400' :
                    regime === 'VOLATILE' ? 'bg-rose-900/30 border-rose-600 text-rose-400' :
                    'bg-blue-900/30 border-blue-600 text-blue-400'
                 }`}>
                    REGIME: {regime}
                 </span>
              </div>
            </div>
            
            <PositionTracker 
                position={botState.activePosition} 
                currentPrice={botState.market.mid} 
            />

            {/* AI Signal Analysis Card */}
            <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
               <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                 <BarChart3 className="w-4 h-4" /> Volatility & Technicals (v4.4)
               </h3>
               <div className="space-y-4">
                 <div className="grid grid-cols-2 gap-6">
                     {/* RSI */}
                     <div>
                       <div className="flex justify-between text-xs text-slate-400 mb-1">
                         <span>RSI (14)</span>
                         <span>{botState.signal.features.rsi.toFixed(1)}</span>
                       </div>
                       <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                         <div 
                           className={`h-full transition-all duration-500 ${
                                botState.signal.features.rsi > 70 ? 'bg-rose-500' : 
                                botState.signal.features.rsi < 30 ? 'bg-emerald-500' : 'bg-blue-500'
                           }`}
                           style={{ width: `${botState.signal.features.rsi}%` }}
                         ></div>
                       </div>
                     </div>
                     {/* StochRSI */}
                     <div>
                       <div className="flex justify-between text-xs text-slate-400 mb-1">
                         <span>StochRSI (K)</span>
                         <span>{botState.signal.features.stochK.toFixed(1)}</span>
                       </div>
                       <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                         <div 
                           className={`h-full transition-all duration-500 ${
                                botState.signal.features.stochK > 80 ? 'bg-rose-400' : 
                                botState.signal.features.stochK < 20 ? 'bg-emerald-400' : 'bg-indigo-400'
                           }`}
                           style={{ width: `${botState.signal.features.stochK}%` }}
                         ></div>
                       </div>
                     </div>
                 </div>
                 
                 <div className="grid grid-cols-2 gap-6">
                    {/* Bollinger Position */}
                    <div>
                       <div className="flex justify-between text-xs text-slate-400 mb-1">
                         <span>BB Position</span>
                         <span className={botState.signal.features.bbPosition < 0.1 ? "text-emerald-400" : botState.signal.features.bbPosition > 0.9 ? "text-rose-400" : "text-slate-400"}>
                            {botState.signal.features.bbPosition < 0.1 ? "LOW (Buy)" : botState.signal.features.bbPosition > 0.9 ? "HIGH (Sell)" : "Neutral"}
                         </span>
                       </div>
                       <div className="h-2 bg-slate-700 rounded-full overflow-hidden relative">
                         <div className="absolute w-1 h-full bg-white top-0" style={{ left: `${Math.min(100, Math.max(0, botState.signal.features.bbPosition * 100))}%` }}></div>
                       </div>
                    </div>
                    {/* Imbalance */}
                    <div>
                       <div className="flex justify-between text-xs text-slate-400 mb-1">
                         <span>Order Flow</span>
                         <span className={botState.signal.features.imbalance > 0 ? "text-emerald-400" : "text-rose-400"}>
                            {botState.signal.features.imbalance > 0 ? "BUY" : "SELL"} Pressure
                         </span>
                       </div>
                       <div className="h-2 bg-slate-700 rounded-full overflow-hidden flex">
                         <div className="w-1/2 h-full flex justify-end">
                            <div 
                                className="h-full bg-rose-500 transition-all duration-300" 
                                style={{ width: botState.signal.features.imbalance < 0 ? `${Math.abs(botState.signal.features.imbalance) * 100}%` : '0%' }}
                            ></div>
                         </div>
                         <div className="w-1/2 h-full flex justify-start">
                            <div 
                                className="h-full bg-emerald-500 transition-all duration-300"
                                style={{ width: botState.signal.features.imbalance > 0 ? `${Math.abs(botState.signal.features.imbalance) * 100}%` : '0%' }}
                            ></div>
                         </div>
                       </div>
                    </div>
                 </div>

                 {/* Divergence Detection Indicator */}
                 {divVal !== 0 && (
                    <div className={`flex items-center justify-center p-2 rounded border text-sm font-bold uppercase tracking-wide animate-pulse ${
                        divVal === 1 ? 'bg-emerald-900/30 border-emerald-500 text-emerald-400' : 'bg-rose-900/30 border-rose-500 text-rose-400'
                    }`}>
                        {divVal === 1 ? 'Bullish Divergence Detected (Reversal Up)' : 'Bearish Divergence Detected (Reversal Down)'}
                    </div>
                 )}
               </div>

               <div className="mt-6 pt-4 border-t border-slate-700 flex justify-between items-center">
                  <div className="text-xs text-slate-500">
                    <span className="block">Efficiency Score: {botState.wallet.efficiencyIndex.toFixed(0)}/100</span>
                    <span className="block mt-1">Predicted PnL: +{fmtMoney(botState.signal.predictedPnL)} (Virtual)</span>
                  </div>
                  <div className={`px-3 py-1 rounded font-bold text-sm ${
                    botState.signal.direction === Direction.LONG ? 'bg-emerald-500/20 text-emerald-400' :
                    botState.signal.direction === Direction.SHORT ? 'bg-rose-500/20 text-rose-400' :
                    'bg-slate-700 text-slate-400'
                  }`}>
                    AI SIGNAL: {botState.signal.direction}
                  </div>
               </div>
            </div>
          </div>

          {/* Right Column: Console & Settings */}
          <div className="space-y-6">
             <LogConsole logs={botState.logs} />
             
             <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
                <h3 className="text-xs font-bold text-slate-400 uppercase mb-4">Bot Health</h3>
                <div className="space-y-3">
                   <div className="flex justify-between items-center text-sm">
                      <span className="text-slate-400">API Status</span>
                      <span className="text-emerald-400 flex items-center gap-1">
                        <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                        Connected
                      </span>
                   </div>
                   <div className="flex justify-between items-center text-sm">
                      <span className="text-slate-400">Profit Factor</span>
                      <span className={`${botState.wallet.profitFactor > 1 ? 'text-emerald-400' : 'text-slate-300'}`}>
                          {botState.wallet.profitFactor.toFixed(2)}
                      </span>
                   </div>
                   <div className="flex justify-between items-center text-sm">
                      <span className="text-slate-400">Risk Level</span>
                      <span className={`${riskColor} font-bold flex items-center gap-1`}>
                         {riskLabel === 'HIGH' && <ShieldAlert className="w-3 h-3" />}
                         {riskLabel} ({(walletUsage * 100).toFixed(1)}%)
                      </span>
                   </div>
                   <div className="flex justify-between items-center text-sm">
                      <span className="text-slate-400">Engine</span>
                      <span className="text-indigo-300 flex items-center gap-1">
                          <BrainCircuit className="w-3 h-3" /> v4.4 (Synced)
                      </span>
                   </div>
                </div>
             </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
