
import React, { useState, useEffect } from 'react';
import { getUpdatedState, startBotEngine, stopBotEngine, setBotRunning } from './services/botSimulator';
import { BotState, Direction } from './types';
import MetricCard from './components/MetricCard';
import PositionTracker from './components/PositionTracker';
import LogConsole from './components/LogConsole';
import PriceChart from './components/PriceChart';
import Login from './components/Login';
import SettingsModal from './components/SettingsModal';
import { 
  Cpu, Zap, TrendingUp, Wallet, Server, BarChart3, ShieldAlert, Lock, BrainCircuit, Wifi, LogOut, Play, Square, Settings, AlertTriangle, Layers
} from 'lucide-react';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [botState, setBotState] = useState<BotState | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSetupRequired, setIsSetupRequired] = useState(false);
  const [selectedSymbol, setSelectedSymbol] = useState<string>('BTCUSDT_PERP');

  useEffect(() => {
    const checkCookie = () => {
        const match = document.cookie.match(new RegExp('(^| )hitbtc_bot_auth=([^;]+)'));
        if (match && match[2] === 'valid_session') setIsAuthenticated(true);
    };
    checkCookie();
  }, []);

  useEffect(() => {
      if (isAuthenticated) {
          const hasKeys = localStorage.getItem('hitbtc_api_key') && localStorage.getItem('hitbtc_api_secret');
          if (!hasKeys) setIsSetupRequired(true);
      }
  }, [isAuthenticated]);

  useEffect(() => {
    if (isAuthenticated) {
      startBotEngine();
      const interval = setInterval(() => setBotState(getUpdatedState()), 200); 
      return () => clearInterval(interval);
    }
  }, [isAuthenticated]);

  const handleLogout = () => {
    document.cookie = "hitbtc_bot_auth=; path=/; max-age=0; SameSite=Strict";
    setIsAuthenticated(false);
    setBotState(null);
  };

  if (!isAuthenticated) return <Login onLogin={() => setIsAuthenticated(true)} />;
  if (!botState) return <div className="bg-slate-950 h-screen w-full flex items-center justify-center text-slate-500"><div className="animate-spin border-4 border-indigo-500 border-t-transparent rounded-full w-8 h-8"></div></div>;

  const market = botState.markets[selectedSymbol] || { mid: 0 };
  const signal = botState.signals[selectedSymbol];
  const pnlColor = botState.wallet.totalProfit >= 0 ? 'text-emerald-400' : 'text-rose-400';
  const walletUsage = botState.wallet.usedMargin / (botState.wallet.balance || 1);
  const activePosForChart = botState.activePositions.find(p => p.symbol === selectedSymbol) || null;

  const SYMBOL_LABELS: Record<string, string> = {
      'BTCUSDT_PERP': 'BTC', 'ETHUSDT_PERP': 'ETH', 'SOLUSDT_PERP': 'SOL', 'ATOMUSDT_PERP': 'ATOM', 'MATICUSDT_PERP': 'MATIC'
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-indigo-500/30 relative">
      <SettingsModal isOpen={isSettingsOpen} onClose={() => {
          setIsSettingsOpen(false);
          if (localStorage.getItem('hitbtc_api_key')) setIsSetupRequired(false);
      }} />

      <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg shadow-lg ${botState.system.recoveryMode ? 'bg-amber-600 animate-pulse' : 'bg-indigo-600'}`}>
                {botState.system.recoveryMode ? <ShieldAlert className="w-5 h-5 text-white" /> : <Layers className="w-5 h-5 text-white" />}
            </div>
            <div>
              <h1 className="font-bold text-lg tracking-tight">HitBTC AI V6.5</h1>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span className={`w-2 h-2 rounded-full ${botState.system.recoveryMode ? 'bg-amber-500' : 'bg-emerald-500'}`}></span> 
                {botState.system.recoveryMode ? 'RECOVERY MODE ACTIVE' : 'Multicoin Engine'}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center bg-slate-800 rounded-lg p-1 border border-slate-700 mr-4">
                <button onClick={() => setBotRunning(true)} disabled={isSetupRequired} className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-bold ${botState.isRunning ? 'bg-emerald-600 text-white' : 'text-slate-500'}`}><Play className="w-3 h-3 fill-current" /> RUN</button>
                <button onClick={() => setBotRunning(false)} className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-bold ${!botState.isRunning ? 'bg-rose-600 text-white' : 'text-slate-500'}`}><Square className="w-3 h-3 fill-current" /> STOP</button>
            </div>
            <div className="hidden md:flex flex-col items-end text-sm mr-4">
                <span className="text-slate-500 text-xs uppercase">Equity</span>
                <span className="font-mono font-bold text-emerald-400">${(botState.wallet.virtualBalance / 1_000_000).toFixed(2)}M</span>
            </div>
            <button onClick={() => setIsSettingsOpen(true)} className="p-2 rounded-md hover:bg-slate-800"><Settings className="w-5 h-5" /></button>
            <button onClick={handleLogout} className="p-2 rounded-md hover:bg-slate-800"><LogOut className="w-5 h-5" /></button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <MetricCard title="Total PnL (Virtual)" value={`$${botState.wallet.virtualTotalProfit.toLocaleString()}`} trend={botState.wallet.totalProfit >= 0 ? 'up' : 'down'} color={pnlColor} icon={<TrendingUp className="w-5 h-5" />} />
          <MetricCard title="Active Positions" value={botState.activePositions.length} subValue={botState.system.recoveryMode ? "HEDGING LOSSES" : "Normal Ops"} icon={<Layers className="w-5 h-5" />} />
          <MetricCard title="Margin Usage" value={`${(walletUsage * 100).toFixed(2)}%`} subValue={`Used: ${botState.wallet.usedMargin.toFixed(4)}`} color={walletUsage > 0.5 ? 'text-amber-400' : 'text-emerald-400'} icon={<Lock className="w-5 h-5" />} />
          <MetricCard title="AI Confidence" value={`${signal?.confidence.toFixed(0) || 0}%`} subValue={`${selectedSymbol.split('U')[0]} Signal`} color={signal?.confidence > 75 ? 'text-emerald-400' : 'text-slate-400'} icon={<BrainCircuit className="w-5 h-5" />} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
             {/* SYMBOL SELECTOR */}
             <div className="flex gap-2 overflow-x-auto pb-2">
                 {Object.keys(botState.markets).map(sym => (
                     <button 
                        key={sym}
                        onClick={() => setSelectedSymbol(sym)}
                        className={`px-4 py-2 rounded-lg font-bold text-sm transition-all whitespace-nowrap ${selectedSymbol === sym ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}
                     >
                        {SYMBOL_LABELS[sym] || sym} 
                        <span className={`ml-2 text-xs ${botState.signals[sym]?.direction === 'LONG' ? 'text-emerald-400' : botState.signals[sym]?.direction === 'SHORT' ? 'text-rose-400' : 'text-slate-500'}`}>
                             {botState.signals[sym]?.direction === 'LONG' ? '▲' : botState.signals[sym]?.direction === 'SHORT' ? '▼' : '•'}
                        </span>
                     </button>
                 ))}
             </div>

             <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">{SYMBOL_LABELS[selectedSymbol]} Price Action</h3>
                    <span className="text-xs font-mono text-slate-500">${market.mid.toFixed(4)}</span>
                </div>
                <PriceChart data={botState.priceHistory[selectedSymbol] || []} activePosition={activePosForChart} height={200} />
             </div>

             <div className="space-y-4">
                <h3 className="text-sm font-bold text-slate-400 uppercase flex items-center gap-2"><Server className="w-4 h-4" /> Active Positions ({botState.activePositions.length})</h3>
                {botState.activePositions.length === 0 ? (
                    <div className="bg-slate-800/50 border border-slate-700/50 rounded-lg p-8 text-center text-slate-500 italic">
                        AI Scanning 5 markets for opportunities...
                    </div>
                ) : (
                    botState.activePositions.map(pos => (
                        <PositionTracker key={pos.id} position={pos} currentPrice={botState.markets[pos.symbol]?.mid || pos.entryPrice} />
                    ))
                )}
             </div>
          </div>

          <div className="space-y-6">
             <div className="bg-slate-800 rounded-lg border border-slate-700 p-4">
                <h3 className="text-xs font-bold text-slate-400 uppercase mb-4 flex items-center gap-2"><BarChart3 className="w-4 h-4" /> {SYMBOL_LABELS[selectedSymbol]} Analysis</h3>
                {signal && (
                    <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4 text-xs">
                            <div className="bg-slate-900/50 p-2 rounded">
                                <span className="text-slate-500 block">RSI (7)</span>
                                <span className={`font-mono text-lg ${signal.features.rsi > 70 ? 'text-rose-400' : signal.features.rsi < 30 ? 'text-emerald-400' : 'text-white'}`}>{signal.features.rsi.toFixed(1)}</span>
                            </div>
                            <div className="bg-slate-900/50 p-2 rounded">
                                <span className="text-slate-500 block">Trend (ADX)</span>
                                <span className="font-mono text-lg text-white">{signal.features.adx.toFixed(1)}</span>
                            </div>
                            <div className="bg-slate-900/50 p-2 rounded">
                                <span className="text-slate-500 block">MACD</span>
                                <span className={`font-mono text-lg ${signal.features.macdHist > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>{signal.features.macdHist > 0 ? 'BULL' : 'BEAR'}</span>
                            </div>
                            <div className="bg-slate-900/50 p-2 rounded">
                                <span className="text-slate-500 block">Regime</span>
                                <span className="font-mono text-lg text-blue-300">{signal.marketRegime}</span>
                            </div>
                        </div>
                        <div className={`p-3 rounded border text-center font-bold ${signal.direction === 'LONG' ? 'bg-emerald-900/20 border-emerald-500/30 text-emerald-400' : signal.direction === 'SHORT' ? 'bg-rose-900/20 border-rose-500/30 text-rose-400' : 'bg-slate-700/30 border-slate-600 text-slate-400'}`}>
                            SIGNAL: {signal.direction} ({signal.confidence}%)
                        </div>
                    </div>
                )}
             </div>
             <LogConsole logs={botState.logs} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
