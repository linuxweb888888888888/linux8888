
export enum Direction {
  LONG = 'LONG',
  SHORT = 'SHORT',
  NEUTRAL = 'NEUTRAL'
}

export interface MarketData {
  symbol: string;
  bid: number;
  ask: number;
  mid: number;
  timestamp: number;
}

export interface Position {
  id: string;
  symbol: string;
  direction: Direction;
  entryPrice: number;
  size: number; // Increments of 0.001
  unrealizedPnL: number;
  highestPnL: number; // Track peak profit for trailing stop
  targetPnL?: number; // Dynamic Take Profit Target for visualization
  leverage: number;
  timestamp: number;
  isRecovery?: boolean; // Flag if this trade was opened to offset losses
}

export interface TradePattern {
  rsi: number;
  volatility: number;
  trendStrength: number;
  imbalance: number;
  macdHist: number; // v6.5
  adx: number;      // v6.5
  regime: string;
  result: 'WIN' | 'LOSS';
}

export interface AISignal {
  symbol: string;
  direction: Direction;
  confidence: number; // 0-100
  predictedPnL: number;
  features: {
    rsi: number;
    stochK: number;
    stochD: number;
    bbPosition: number;
    volatility: number;
    trendStrength: number;
    imbalance: number;
    divergence: number;
    macdHist: number;
    adx: number;
  };
  marketRegime: 'RANGING' | 'TRENDING' | 'VOLATILE';
  learningEpoch: number;
  memorySize?: number;
}

export interface Wallet {
  startBalance: number;
  balance: number;
  virtualBalance: number;
  virtualEquity: number;
  usedMargin: number;
  freeMargin: number;
  totalProfit: number;
  virtualTotalProfit: number;
  growthPercentage: number;
  winRate: number;
  profitFactor: number;
  efficiencyIndex: number;
  dailyLoss: number;
}

export interface LogEntry {
  id: number;
  timestamp: string;
  message: string;
  type: 'INFO' | 'WARNING' | 'ERROR' | 'SUCCESS' | 'TRADE' | 'RECOVERY';
}

export interface BotState {
  isRunning: boolean;
  markets: Record<string, MarketData>;
  activePositions: Position[];
  wallet: Wallet;
  signals: Record<string, AISignal>;
  logs: LogEntry[];
  simulationsRun: number;
  priceHistory: Record<string, number[]>;
  system: {
    latency: number;
    isFallbackMode: boolean;
    recoveryMode: boolean; // v6.5 Global Recovery State
  };
}
