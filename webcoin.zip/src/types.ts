
export enum Direction {
  LONG = 'LONG',
  SHORT = 'SHORT',
  NEUTRAL = 'NEUTRAL'
}

export interface MarketData {
  symbol: string;
  bid: number;
  ask: number;
  mid: number;
  timestamp: number;
}

export interface Position {
  id: string;
  symbol: string;
  direction: Direction;
  entryPrice: number;
  size: number; // Increments of 0.001
  unrealizedPnL: number;
  highestPnL: number; // Track peak profit for trailing stop
  targetPnL?: number; // Dynamic Take Profit Target for visualization
  leverage: number;
  timestamp: number;
}

export interface TradePattern {
  rsi: number;
  volatility: number;
  trendStrength: number;
  imbalance: number; // New: Track order flow context
  regime: string;
  result: 'WIN' | 'LOSS';
}

export interface AISignal {
  direction: Direction;
  confidence: number; // 0-100
  predictedPnL: number;
  features: {
    rsi: number;
    stochK: number; // Stochastic RSI K-Line
    stochD: number; // Stochastic RSI D-Line
    bbPosition: number; // 0 = Lower Band, 0.5 = Mid, 1 = Upper Band
    volatility: number;
    trendStrength: number;
    imbalance: number; // -1 (Heavy Sell) to 1 (Heavy Buy)
    divergence: number; // -1 (Bearish), 1 (Bullish), 0 (None)
  };
  marketRegime: 'RANGING' | 'TRENDING' | 'VOLATILE';
  learningEpoch: number;
  memorySize?: number; // New: Track how many patterns learned
}

export interface Wallet {
  startBalance: number; // Initial balance to calculate growth
  balance: number; // Real USDT
  virtualBalance: number; // Scaled 1M Simulation
  virtualEquity: number; // Scaled Equity
  usedMargin: number;
  freeMargin: number;
  totalProfit: number; // Real Historical PnL
  virtualTotalProfit: number; // Scaled Historical PnL
  growthPercentage: number; // % Increase from start
  winRate: number;
  profitFactor: number; // Gross Wins / Gross Losses
  efficiencyIndex: number; // 0-100 Score of how well capital is being used
}

export interface LogEntry {
  id: number;
  timestamp: string;
  message: string;
  type: 'INFO' | 'WARNING' | 'ERROR' | 'SUCCESS' | 'TRADE';
}

export interface BotState {
  isRunning: boolean;
  market: MarketData;
  activePosition: Position | null;
  wallet: Wallet;
  signal: AISignal;
  logs: LogEntry[];
  simulationsRun: number;
  priceHistory: number[];
  system: {
      latency: number;
      isFallbackMode: boolean;
  };
}