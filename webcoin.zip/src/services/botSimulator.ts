
import { GoogleGenAI, Type } from "@google/genai";
import { BotState, Direction, LogEntry, Position, MarketData, TradePattern, AISignal } from '../types';

// --- Constants ---
const SYMBOLS = ['BTCUSDT_PERP', 'ETHUSDT_PERP', 'SOLUSDT_PERP', 'ATOMUSDT_PERP', 'MATICUSDT_PERP'];
const DISPLAY_SYMBOLS: Record<string, string> = {
    'BTCUSDT_PERP': 'BTC/USDT',
    'ETHUSDT_PERP': 'ETH/USDT',
    'SOLUSDT_PERP': 'SOL/USDT',
    'ATOMUSDT_PERP': 'ATOM/USDT',
    'MATICUSDT_PERP': 'MATIC/USDT'
};

// Min Order Quantities
const MIN_QTYS: Record<string, number> = {
    'BTCUSDT_PERP': 0.001,
    'ETHUSDT_PERP': 0.01,
    'SOLUSDT_PERP': 0.1,
    'ATOMUSDT_PERP': 0.1,
    'MATICUSDT_PERP': 1.0
};
const MIN_QTY = 0.001;

const TAKER_FEE_RATE = 0.0009;
const LEVERAGE = 20;
const RSI_PERIOD = 7; 
const EMA_PERIOD = 20; 
const SLOW_EMA_PERIOD = 100;
const BB_PERIOD = 14; 
const BB_MULTIPLIER = 2; 
const SCALING_FACTOR = 100_000_000; 
const MAX_WALLET_USAGE_PCT = 0.85; 
const BASKET_PROFIT_TARGET_ROI = 0.01; // 1% Basket Target
const MAX_DAILY_LOSS_PCT = 0.05; // 5% Daily Stop

// --- API Credentials ---
let API_KEY = localStorage.getItem('hitbtc_api_key') || '';
let API_SECRET = localStorage.getItem('hitbtc_api_secret') || '';

// --- GEMINI AI SETUP ---
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
let latestGeminiResults: Record<string, { direction: Direction, confidence: number, reasoning: string, timestamp: number }> = {};
const geminiQueue: string[] = [];
let lastGeminiCallTime = 0;
const GEMINI_MIN_DELAY = 4000; // 4s delay to prevent 429s

// --- PROXY CONFIGURATION ---
const GET_PROXIES = [
    (url: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
    (url: string) => `https://corsproxy.io/?${encodeURIComponent(url)}`,
    (url: string) => `https://thingproxy.freeboard.io/fetch/${url}`
];

const POST_PROXIES = [
    (url: string) => `https://corsproxy.io/?${encodeURIComponent(url)}`, 
    (url: string) => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(url)}` 
];

// --- State Management ---
interface SymbolState {
    priceHistory: number[];
    rsiHistory: number[];
    // v6.5: Specific memory per symbol
    patternMemory: TradePattern[];
    lastTrade: { entry: number, direction: Direction, features: any } | null;
}

let symbolStates: Record<string, SymbolState> = {};

// Initialize states
SYMBOLS.forEach(s => {
    symbolStates[s] = { priceHistory: [], rsiHistory: [], patternMemory: [], lastTrade: null };
});

let ccxtExchange: any = null;
let lastTotalProfit = 0; 
let consecutiveWins = 0;
let consecutiveLosses = 0;
let dailyLossCurrent = 0;
let lastDayReset = Date.now();
let timerWorker: Worker | null = null;
let marketInterval: ReturnType<typeof setInterval> | null = null;
let isFetchingMarket = false;

function getFreshState(): BotState {
    const markets: Record<string, MarketData> = {};
    const signals: Record<string, AISignal> = {};
    const priceHistory: Record<string, number[]> = {};
    
    SYMBOLS.forEach(s => {
        markets[s] = { symbol: DISPLAY_SYMBOLS[s], bid: 0, ask: 0, mid: 0, timestamp: Date.now() };
        signals[s] = {
            symbol: s,
            direction: Direction.NEUTRAL, confidence: 0, predictedPnL: 0, 
            features: { rsi: 50, stochK: 50, stochD: 50, bbPosition: 0.5, volatility: 0, trendStrength: 0, imbalance: 0, divergence: 0, macdHist: 0, adx: 0 },
            marketRegime: 'RANGING', learningEpoch: 0, memorySize: 0
        };
        priceHistory[s] = [];
    });

    return {
        isRunning: false,
        markets,
        activePositions: [],
        wallet: { startBalance: 0, balance: 0, virtualBalance: 0, virtualEquity: 0, usedMargin: 0, freeMargin: 0, totalProfit: 0, virtualTotalProfit: 0, growthPercentage: 0.0, winRate: 100.0, profitFactor: 0.0, efficiencyIndex: 90.0, dailyLoss: 0 },
        signals,
        logs: [],
        simulationsRun: 0,
        priceHistory,
        system: { latency: 0, isFallbackMode: false, recoveryMode: false }
    };
}

let currentState: BotState = getFreshState();

// --- HELPERS ---

async function fetchWithRotation(targetUrl: string, options: RequestInit = {}, isPost = false): Promise<Response> {
    let lastError;
    const proxies = isPost ? POST_PROXIES : GET_PROXIES;
    const startIndex = Math.floor(Math.random() * proxies.length);
    const rotatedProxies = [...proxies.slice(startIndex), ...proxies.slice(0, startIndex)];

    for (const proxyGen of rotatedProxies) {
        try {
            const proxyUrl = proxyGen(targetUrl);
            const start = Date.now();
            const response = await fetch(proxyUrl, { ...options, timeout: 10000 } as any);
            currentState.system.latency = Date.now() - start;
            if (response.status === 403 || response.status === 429) throw new Error(`Rate Limited`);
            return response;
        } catch (e) { lastError = e; }
    }
    throw lastError || new Error('All proxies failed');
}

function pushPrice(symbol: string, price: number) {
    if (!symbolStates[symbol]) return;
    const hist = symbolStates[symbol].priceHistory;
    hist.push(price);
    if (hist.length > 150) hist.shift();
    currentState.priceHistory[symbol] = [...hist];
}

function addLog(msg: string, type: LogEntry['type']) {
  const entry: LogEntry = {
    id: Date.now() + Math.random(),
    timestamp: new Date().toLocaleTimeString(),
    message: msg,
    type: type
  };
  currentState.logs = [entry, ...currentState.logs].slice(0, 100);
}

// --- INDICATORS ---
function calculateRSI(prices: number[]): number {
  if (prices.length < RSI_PERIOD + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = prices.length - RSI_PERIOD; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff >= 0) gains += diff; else losses -= diff;
  }
  if (losses === 0) return 100;
  return 100 - (100 / (1 + (gains / losses)));
}

function calculateStochRSI(rsis: number[]) {
    if (rsis.length < 14) return { k: 50, d: 50 };
    const periodRSIs = rsis.slice(-14);
    const minRSI = Math.min(...periodRSIs);
    const maxRSI = Math.max(...periodRSIs);
    let stoch = 50;
    if (maxRSI - minRSI !== 0) stoch = ((periodRSIs[periodRSIs.length - 1] - minRSI) / (maxRSI - minRSI)) * 100;
    return { k: stoch, d: stoch * 0.9 + 5 }; 
}

function calculateBollingerBands(prices: number[]) {
    if (prices.length < BB_PERIOD) return { upper: 0, middle: 0, lower: 0, position: 0.5 };
    const slice = prices.slice(-BB_PERIOD);
    const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
    const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / slice.length;
    const stdDev = Math.sqrt(variance);
    const upper = mean + (BB_MULTIPLIER * stdDev);
    const lower = mean - (BB_MULTIPLIER * stdDev);
    const current = prices[prices.length - 1];
    let position = 0.5;
    if (upper - lower !== 0) position = (current - lower) / (upper - lower);
    return { upper, middle: mean, lower, position };
}

function calculateEMA(prices: number[], period: number): number {
    if (prices.length < period) return prices[prices.length - 1];
    const k = 2 / (period + 1);
    let ema = prices[0];
    for (let i = 1; i < prices.length; i++) ema = (prices[i] * k) + (ema * (1 - k));
    return ema;
}

function calculateMACD(prices: number[]) {
    if (prices.length < 26) return { macd: 0, signal: 0, histogram: 0 };
    const kFast = 2/13, kSlow = 2/27, kSig = 2/10;
    let emaFast = prices[0], emaSlow = prices[0];
    const macdLine: number[] = [];
    for (let i = 1; i < prices.length; i++) {
        emaFast = (prices[i] * kFast) + (emaFast * (1 - kFast));
        emaSlow = (prices[i] * kSlow) + (emaSlow * (1 - kSlow));
        if (i >= 26) macdLine.push(emaFast - emaSlow);
    }
    if (macdLine.length < 9) return { macd: 0, signal: 0, histogram: 0 };
    let signalLine = macdLine[0];
    for (let i = 1; i < macdLine.length; i++) signalLine = (macdLine[i] * kSig) + (signalLine * (1 - kSig));
    const currentMACD = macdLine[macdLine.length - 1];
    return { macd: currentMACD, signal: signalLine, histogram: currentMACD - signalLine };
}

function calculateADX(prices: number[]): number {
    if (prices.length < 14) return 0;
    const changes = [];
    for (let i = 1; i < prices.length; i++) changes.push(Math.abs(prices[i] - prices[i-1]));
    const avgChange = changes.reduce((a,b)=>a+b,0) / changes.length;
    const totalRange = Math.max(...prices) - Math.min(...prices);
    return Math.min(100, (avgChange / (totalRange || 1)) * 1000);
}

function calculateStandardDeviation(prices: number[]): number {
    if (prices.length < 5) return 0;
    const mean = prices.reduce((a, b) => a + b, 0) / prices.length;
    const variance = prices.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / prices.length;
    return Math.sqrt(variance);
}

function detectMarketRegime(volatility: number, trendStrength: number): 'RANGING' | 'TRENDING' | 'VOLATILE' {
    if (volatility > 2.0) return 'VOLATILE';
    if (Math.abs(trendStrength) > 1.0) return 'TRENDING';
    return 'RANGING';
}

function matchPattern(symbol: string, current: TradePattern): number {
    const memory = symbolStates[symbol].patternMemory;
    if (memory.length === 0) return 0;
    let bestMatchScore = -999;
    for(const mem of memory) {
        const distRsi = Math.abs(current.rsi - mem.rsi);
        const distTrend = Math.abs(current.trendStrength - mem.trendStrength);
        const distVol = Math.abs(current.volatility - mem.volatility);
        const distMacd = Math.abs(current.macdHist - mem.macdHist) * 1000;
        
        const similarity = 100 - (distRsi + (distTrend * 10) + (distVol * 10) + (distMacd * 5)); 
        if (similarity > 75) { 
            if (mem.result === 'WIN') bestMatchScore = Math.max(bestMatchScore, 1); 
            if (mem.result === 'LOSS') bestMatchScore = Math.max(bestMatchScore, -1); 
        }
    }
    return bestMatchScore === -999 ? 0 : bestMatchScore;
}

// --- STATE SAVING ---
function saveSession() {
    try {
        const sessionData = {
            timestamp: Date.now(),
            isRunning: currentState.isRunning, 
            wallet: currentState.wallet,
            activePositions: currentState.activePositions,
            efficiencyIndex: currentState.wallet.efficiencyIndex,
            consecutiveWins, consecutiveLosses,
            dailyLossCurrent, lastDayReset,
            // Serialize memories
            memories: Object.keys(symbolStates).reduce((acc, key) => ({ ...acc, [key]: symbolStates[key].patternMemory }), {})
        };
        localStorage.setItem('hitbtc_bot_session_v65', JSON.stringify(sessionData));
    } catch(e) {}
}

function restoreSession() {
    try {
        const raw = localStorage.getItem('hitbtc_bot_session_v65');
        if (raw) {
            const data = JSON.parse(raw);
            if (Date.now() - data.timestamp < 48 * 60 * 60 * 1000) { 
                currentState.isRunning = data.isRunning ?? false;
                currentState.wallet = { ...currentState.wallet, ...data.wallet };
                currentState.wallet.efficiencyIndex = data.efficiencyIndex || 90;
                consecutiveWins = data.consecutiveWins || 0;
                consecutiveLosses = data.consecutiveLosses || 0;
                dailyLossCurrent = data.dailyLossCurrent || 0;
                lastDayReset = data.lastDayReset || Date.now();
                if(data.activePositions) currentState.activePositions = data.activePositions; 
                
                if (data.memories) {
                    Object.keys(data.memories).forEach(k => {
                        if (symbolStates[k]) symbolStates[k].patternMemory = data.memories[k];
                    });
                }
                addLog('[SESSION] V6.5 Hedge & Recover State Restored.', 'SUCCESS');
            }
        }
    } catch(e) {}
}

function formatVirtual(value: number): string {
    return `$${(value * SCALING_FACTOR).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

// --- EXECUTION & API ---
async function initCCXT() {
  if (!API_KEY || !API_SECRET) return;
  try {
    // @ts-ignore
    if (window.ccxt && window.ccxt.hitbtc) {
      // @ts-ignore
      ccxtExchange = new window.ccxt.hitbtc({
        apiKey: API_KEY,
        secret: API_SECRET,
        enableRateLimit: true,
        options: { defaultType: 'swap' } 
      });
      addLog('CCXT HitBTC initialized.', 'INFO');
    }
  } catch (e: any) { addLog(`CCXT Error: ${e.message}`, 'ERROR'); }
}

async function executeRealOrder(symbol: string, side: 'buy' | 'sell', amount: number, price?: number) {
    if (!API_KEY || !API_SECRET) return null;
    const scaledAmount = formatVirtual(amount * (price || 100)); 
    addLog(`Order: ${side.toUpperCase()} ${amount} ${DISPLAY_SYMBOLS[symbol] || symbol} (~${scaledAmount})`, 'WARNING');
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const body = new URLSearchParams();
        body.append('symbol', symbol); 
        body.append('side', side);
        body.append('quantity', amount.toString()); 
        body.append('type', 'market');
        body.append('margin_mode', 'cross');
        
        const targetUrl = "https://api.hitbtc.com/api/3/futures/order";
        const response = await fetchWithRotation(targetUrl, {
            method: 'POST',
            headers: { 'Authorization': `Basic ${auth}`, 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body
        }, true);

        if (response.ok) {
             const data = await response.json();
             addLog(`ORDER SUCCESS: ${data.id}`, 'SUCCESS');
             return data;
        } else {
            throw new Error(`API Status ${response.status}`);
        }
    } catch (error: any) {
        addLog(`Order Failed: ${error.message}. Simulated execution.`, 'WARNING');
        return { id: `SIM-${Date.now()}`, avgPrice: price ? price.toString() : '0', quantity: amount.toString() }; 
    }
}

async function syncWallet() {
    if (!API_KEY || !API_SECRET) return;
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const response = await fetchWithRotation("https://api.hitbtc.com/api/3/futures/balance", { headers: { 'Authorization': `Basic ${auth}` } });
        if (response.ok) {
            const data = await response.json();
            const usdt = Array.isArray(data) ? data.find((a: any) => a.currency === 'USDT') : null;
            if (usdt) {
                const balance = parseFloat(usdt.cross_margin_reserved || usdt.reserved_margin || '0');
                const available = parseFloat(usdt.available || '0');
                currentState.wallet.balance = balance > 0 ? balance : available;
                currentState.wallet.freeMargin = available;
                currentState.wallet.usedMargin = currentState.wallet.balance - available;
                currentState.wallet.virtualBalance = currentState.wallet.balance * SCALING_FACTOR;
                
                let totalUnrealized = 0;
                currentState.activePositions.forEach(p => totalUnrealized += p.unrealizedPnL);
                
                currentState.wallet.virtualEquity = (currentState.wallet.balance + totalUnrealized) * SCALING_FACTOR;
                currentState.wallet.virtualTotalProfit = currentState.wallet.totalProfit * SCALING_FACTOR;
                
                if (currentState.wallet.startBalance <= 0 && currentState.wallet.balance > 0) currentState.wallet.startBalance = currentState.wallet.balance;
            }
        }
    } catch (e) {}
}

async function updateMarketData() {
  if (!API_KEY || !API_SECRET || isFetchingMarket) return;
  isFetchingMarket = true;

  try {
      let tickers: any = {};
      if (ccxtExchange) {
           tickers = await ccxtExchange.fetchTickers(SYMBOLS);
      } else {
           const response = await fetchWithRotation("https://api.hitbtc.com/api/3/public/ticker");
           if (response.ok) tickers = await response.json();
      }

      SYMBOLS.forEach(sym => {
          let t = tickers[sym];
          if (!t && tickers[sym.replace('_', '')]) t = tickers[sym.replace('_', '')];
          
          if (t) {
              const bid = parseFloat(t.bid || t.last);
              const ask = parseFloat(t.ask || t.last);
              const mid = (bid + ask) / 2;
              
              currentState.markets[sym] = {
                  symbol: DISPLAY_SYMBOLS[sym] || sym,
                  bid, ask, mid, timestamp: Date.now()
              };
              pushPrice(sym, mid);
          }
      });
  } catch (e) {
      // Fallback
  }
  isFetchingMarket = false;
}

// --- AI QUEUE SYSTEM ---
async function processGeminiQueue() {
    if (geminiQueue.length === 0) return;
    if (Date.now() - lastGeminiCallTime < GEMINI_MIN_DELAY) return; // Rate limit

    const symbol = geminiQueue.shift();
    if (!symbol) return;

    try {
        lastGeminiCallTime = Date.now();
        const features = currentState.signals[symbol].features;
        const prompt = `
        Analyze crypto ${symbol} for scalping.
        Price Data: RSI=${features.rsi}, BB=${features.bbPosition}, MACD=${features.macdHist}, ADX=${features.adx}.
        Market is ${currentState.signals[symbol].marketRegime}.
        Return JSON: { "direction": "LONG"|"SHORT"|"NEUTRAL", "confidence": 0-100, "reasoning": "short string" }
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        direction: { type: Type.STRING, enum: ["LONG", "SHORT", "NEUTRAL"] },
                        confidence: { type: Type.NUMBER },
                        reasoning: { type: Type.STRING }
                    }
                }
            }
        });

        const result = JSON.parse(response.text || '{}');
        if (result && result.direction) {
            latestGeminiResults[symbol] = {
                direction: result.direction as Direction,
                confidence: result.confidence,
                reasoning: result.reasoning,
                timestamp: Date.now()
            };
        }
    } catch (e) {}
}

// --- CORE STRATEGY ---
async function runMulticoinStrategy() {
    if (!currentState.isRunning || !API_KEY) return;

    const { wallet } = currentState;
    let totalUsedMargin = 0;
    let basketUnrealizedPnL = 0;
    let profitablePositions = 0;

    // 1. Update Positions & Basket Stats
    currentState.activePositions = currentState.activePositions.filter(pos => pos.size > 0); // Clean closed
    for (const pos of currentState.activePositions) {
        const mkt = currentState.markets[pos.symbol];
        if (mkt) {
            const exitPrice = pos.direction === Direction.LONG ? mkt.bid : mkt.ask;
            const pnl = pos.direction === Direction.LONG ? (exitPrice - pos.entryPrice) * pos.size : (pos.entryPrice - exitPrice) * pos.size;
            pos.unrealizedPnL = pnl;
            basketUnrealizedPnL += pnl;
            if (pnl > 0) profitablePositions++;
            
            const margin = (pos.size * pos.entryPrice) / LEVERAGE;
            totalUsedMargin += margin;
            
            if (pos.unrealizedPnL > (pos.highestPnL || -9999)) pos.highestPnL = pos.unrealizedPnL;
        }
    }
    
    wallet.usedMargin = totalUsedMargin;
    wallet.freeMargin = wallet.balance - wallet.usedMargin;

    // 2. Basket Logic: Hedge & Recover
    const basketTarget = wallet.balance * BASKET_PROFIT_TARGET_ROI;
    const drawdownLimit = -(wallet.balance * 0.02); // 2% Drawdown trigger
    
    // Global Take Profit
    if (basketUnrealizedPnL > basketTarget && currentState.activePositions.length > 1) {
         addLog(`[BASKET] Target Hit (+${formatVirtual(basketUnrealizedPnL)}). Flashing All.`, 'SUCCESS');
         for (const pos of currentState.activePositions) {
             const mkt = currentState.markets[pos.symbol];
             await executeRealOrder(pos.symbol, pos.direction === Direction.LONG ? 'sell' : 'buy', pos.size, mkt.mid);
             
             // Learning
             const mem: TradePattern = { 
                 ...symbolStates[pos.symbol].lastTrade?.features, 
                 result: pos.unrealizedPnL > 0 ? 'WIN' : 'LOSS' 
             };
             if (symbolStates[pos.symbol].patternMemory.length > 50) symbolStates[pos.symbol].patternMemory.shift();
             symbolStates[pos.symbol].patternMemory.push(mem);
             
             pos.size = 0; 
         }
         wallet.totalProfit += basketUnrealizedPnL * 0.95; 
         currentState.activePositions = [];
         wallet.usedMargin = 0;
         currentState.system.recoveryMode = false;
         return; 
    }

    // Recovery Mode Trigger
    if (basketUnrealizedPnL < drawdownLimit && !currentState.system.recoveryMode) {
        currentState.system.recoveryMode = true;
        addLog(`[RECOVERY] Portfolio in Drawdown. Activating Hedge Logic.`, 'WARNING');
    } else if (basketUnrealizedPnL > 0 && currentState.system.recoveryMode) {
        currentState.system.recoveryMode = false;
        addLog(`[RECOVERY] Portfolio Recovered. Resuming Normal Ops.`, 'SUCCESS');
    }

    // 3. Individual Position Management
    for (const pos of currentState.activePositions) {
        if (pos.size === 0) continue;
        const mkt = currentState.markets[pos.symbol];
        const fees = (pos.size * pos.entryPrice * TAKER_FEE_RATE) + (pos.size * mkt.mid * TAKER_FEE_RATE);
        const netPnL = pos.unrealizedPnL - fees;
        
        // In Recovery Mode: Tighten stops on winners to fund losers
        let trailingGap = 0.25;
        if (currentState.system.recoveryMode && netPnL > 0) trailingGap = 0.10; // Aggressive banking

        const target = pos.targetPnL || (fees * 3);
        let shouldClose = false;
        let reason = '';

        // Trailing Stop
        if (pos.highestPnL > target && pos.unrealizedPnL < pos.highestPnL * (1 - trailingGap)) { shouldClose = true; reason = 'Trailing Stop'; }
        
        // Stop Loss (Wider if hedging)
        const maxLoss = currentState.system.recoveryMode ? -0.08 : -0.05;
        if (pos.unrealizedPnL < maxLoss * (pos.size * pos.entryPrice / LEVERAGE)) { shouldClose = true; reason = 'Stop Loss'; }

        if (shouldClose) {
            addLog(`[EXIT] ${pos.symbol} ${reason}`, pos.unrealizedPnL > 0 ? 'SUCCESS' : 'WARNING');
            await executeRealOrder(pos.symbol, pos.direction === Direction.LONG ? 'sell' : 'buy', pos.size, mkt.mid);
            wallet.totalProfit += netPnL;
            
            // Update Memory
            const mem: TradePattern = { 
                ...symbolStates[pos.symbol].lastTrade?.features, 
                result: pos.unrealizedPnL > 0 ? 'WIN' : 'LOSS' 
            };
            symbolStates[pos.symbol].patternMemory.push(mem);
            pos.size = 0; 
        }
    }

    // 4. Scan & Enter
    for (const sym of SYMBOLS) {
        const hist = symbolStates[sym].priceHistory;
        const mkt = currentState.markets[sym];
        if (hist.length < 50 || !mkt) continue;
        
        const rsi = calculateRSI(hist);
        const { k, d } = calculateStochRSI(symbolStates[sym].rsiHistory);
        const bb = calculateBollingerBands(hist);
        const { histogram } = calculateMACD(hist);
        const adx = calculateADX(hist);
        const ema = calculateEMA(hist, EMA_PERIOD);
        const slowEma = calculateEMA(hist, SLOW_EMA_PERIOD);
        
        symbolStates[sym].rsiHistory.push(rsi);
        if (symbolStates[sym].rsiHistory.length > 50) symbolStates[sym].rsiHistory.shift();

        const vol = (calculateStandardDeviation(hist.slice(-20)) / mkt.mid) * 1000;
        const trend = ((mkt.mid - ema) / ema) * 1000;
        const regime = detectMarketRegime(vol, trend);
        
        // Update Signal State
        currentState.signals[sym] = {
            symbol: sym,
            direction: Direction.NEUTRAL, confidence: 0, predictedPnL: 0,
            features: { rsi, stochK: k, stochD: d, bbPosition: bb.position, volatility: vol, trendStrength: trend, imbalance: 0, divergence: 0, macdHist: histogram, adx },
            marketRegime: regime, learningEpoch: 0
        };

        // Queue Gemini
        if (!geminiQueue.includes(sym)) geminiQueue.push(sym);

        // --- ENTRY LOGIC ---
        if (!currentState.activePositions.find(p => p.symbol === sym && p.size > 0)) {
             if (wallet.usedMargin / wallet.balance > MAX_WALLET_USAGE_PCT) continue;

             let direction = Direction.NEUTRAL;
             let conf = 0;
             
             // 1. Gemini Opinion
             const gem = latestGeminiResults[sym];
             if (gem && (Date.now() - gem.timestamp < 30000) && gem.confidence > 70) {
                 direction = gem.direction;
                 conf = gem.confidence;
             } else {
                 // 2. Technical Fallback
                 const isOS = k < 20 && rsi < 35;
                 const isOB = k > 80 && rsi > 65;
                 const isBull = histogram > 0;
                 const isBear = histogram < 0;
                 
                 if (regime === 'RANGING') {
                     if (bb.position < 0.1 && isOS && isBull) { direction = Direction.LONG; conf = 70; }
                     if (bb.position > 0.9 && isOB && isBear) { direction = Direction.SHORT; conf = 70; }
                 } else if (regime === 'TRENDING') {
                     const isUptrend = mkt.mid > slowEma;
                     if (isUptrend && isOS && isBull && adx > 20) { direction = Direction.LONG; conf = 75; }
                     if (!isUptrend && isOB && isBear && adx > 20) { direction = Direction.SHORT; conf = 75; }
                 }
             }
             
             // 3. Memory Boost
             const currentPat: TradePattern = { rsi, volatility: vol, trendStrength: trend, imbalance: 0, macdHist: histogram, adx, regime, result: 'WIN' };
             const memScore = matchPattern(sym, currentPat);
             if (memScore > 0) conf += 10;
             if (memScore < 0) conf -= 20;

             // 4. RECOVERY LOGIC ("Make profit where others lose")
             if (currentState.system.recoveryMode) {
                 // If in drawdown, we only take HIGH confidence trades
                 if (conf < 85) continue;
                 
                 // Check Correlation/Divergence: 
                 // If basket is Short and losing (Market pumping), Look for Longs on laggards.
                 // Simple heuristic: If basketPnL is negative, increase size on high confidence setups to recover faster.
                 addLog(`[HEDGE] Opening ${sym} to recover basket drawdown.`, 'RECOVERY');
                 conf += 5; 
             }

             currentState.signals[sym].direction = direction;
             currentState.signals[sym].confidence = conf;

             if (direction !== Direction.NEUTRAL && conf >= 75) {
                 const minQty = MIN_QTYS[sym] || MIN_QTY;
                 let size = minQty;
                 if (conf > 85) size *= 1.5;
                 // Martingale-lite for recovery
                 if (currentState.system.recoveryMode && conf > 90) size *= 1.4; 

                 const cost = (size * mkt.mid) / LEVERAGE;
                 if (wallet.freeMargin > cost * 1.1) {
                     addLog(`[ENTRY] ${sym} ${direction} (${conf}%)`, 'TRADE');
                     const res = await executeRealOrder(sym, direction === Direction.LONG ? 'buy' : 'sell', size, mkt.mid);
                     if (res) {
                         currentState.activePositions.push({
                             id: `ORD-${Date.now()}`,
                             symbol: sym, direction, entryPrice: mkt.mid, size, unrealizedPnL: 0, highestPnL: 0, leverage: LEVERAGE, timestamp: Date.now(),
                             targetPnL: (size * mkt.mid * 0.005),
                             isRecovery: currentState.system.recoveryMode
                         });
                         symbolStates[sym].lastTrade = { entry: mkt.mid, direction, features: currentPat };
                     }
                 }
             }
        }
    }
    
    processGeminiQueue();
    saveSession();
}

export function startBotEngine() {
    if (timerWorker) { timerWorker.terminate(); timerWorker = null; }
    if (marketInterval) clearInterval(marketInterval);
    
    restoreSession(); 
    if (!currentState.wallet.balance) currentState = getFreshState();
    if (!localStorage.getItem('hitbtc_bot_session_v65')) currentState.isRunning = true; 

    if (!API_KEY) {
        addLog('API Keys Missing. Configure in Settings.', 'ERROR');
        currentState.isRunning = false;
        return;
    }

    initCCXT();
    marketInterval = setInterval(() => { updateMarketData(); }, 1000); 

    const blob = new Blob([`
        let interval;
        self.onmessage = function(e) {
            if (e.data.action === 'start') {
                if (interval) clearInterval(interval);
                interval = setInterval(() => self.postMessage('tick'), 500); 
            } else if (e.data.action === 'stop') {
                if (interval) clearInterval(interval);
            }
        }
    `], { type: 'application/javascript' });

    timerWorker = new Worker(URL.createObjectURL(blob));
    timerWorker.onmessage = async () => {
        if (!API_KEY) return; 
        await syncWallet();
        await runMulticoinStrategy();
    };
    timerWorker.postMessage({ action: 'start' });

    setTimeout(() => { addLog("[AI-CORE] v6.5 Hedge & Recover Engine Active.", "INFO"); }, 500);
}

export function stopBotEngine() {
    if (timerWorker) { timerWorker.postMessage({ action: 'stop' }); timerWorker.terminate(); timerWorker = null; }
    if (marketInterval) { clearInterval(marketInterval); marketInterval = null; }
    currentState.isRunning = false;
    saveSession(); 
}

export function setBotRunning(running: boolean) {
    currentState.isRunning = running;
    addLog(running ? 'ENGINE STARTED.' : 'ENGINE STOPPED.', running ? 'SUCCESS' : 'WARNING');
    saveSession();
}

export function getUpdatedState(): BotState {
    return { ...currentState };
}
