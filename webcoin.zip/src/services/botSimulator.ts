
import { BotState, Direction, LogEntry, Position, MarketData, TradePattern } from '../types';

// --- Constants ---
const MIN_QTY = 0.001; 
const SYMBOL = 'ATOMUSDT_PERP'; 
let CCXT_SYMBOL = 'ATOM/USDT:USDT'; 
const DISPLAY_SYMBOL = 'ATOM/USDT (Perp)';
const TAKER_FEE_RATE = 0.0009;
const LEVERAGE = 20;
const RSI_PERIOD = 7; // Faster RSI for v5.6+
const EMA_PERIOD = 20; 
const SLOW_EMA_PERIOD = 100; // v5.7 Higher Timeframe Bias
const BB_PERIOD = 14; 
const BB_MULTIPLIER = 2; 
const SCALING_FACTOR = 100_000_000; 
const MAX_WALLET_USAGE_PCT = 0.80; 
const BASE_GRID_DEVIATION = 0.001; 
const PYRAMID_THRESHOLD_PNL = 0.0002; 
const MICRO_PROFIT_TARGET = 0.00012; 
let MIN_ROIE_PCT = 0.0015; 
const DAILY_STOP_LOSS_PCT = 0.05; // 5% Max Daily Loss

// --- API Credentials ---
// Load from LocalStorage. STRICT: No hardcoded fallbacks.
let API_KEY = localStorage.getItem('hitbtc_api_key') || '';
let API_SECRET = localStorage.getItem('hitbtc_api_secret') || '';

// --- PROXY CONFIGURATION ---
const GET_PROXIES = [
    (url: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
    (url: string) => `https://corsproxy.io/?${encodeURIComponent(url)}`,
    (url: string) => `https://thingproxy.freeboard.io/fetch/${url}`
];

const POST_PROXIES = [
    (url: string) => `https://corsproxy.io/?${encodeURIComponent(url)}`, 
    (url: string) => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(url)}` 
];

// --- State Management ---
let priceHistory: number[] = []; 
let rsiHistory: number[] = []; 
let macdHistory: number[] = []; // Track histogram slope
let ccxtExchange: any = null;
let useRealTrading = false;
let lastTotalProfit = 0; 
let consecutiveWins = 0;
let consecutiveLosses = 0;
let grossWins = 0;
let grossLosses = 0;
let dailyLossCurrent = 0;
let lastDayReset = Date.now();
let timerWorker: Worker | null = null;
let marketInterval: ReturnType<typeof setInterval> | null = null;
let isFetchingMarket = false; // LOCK to prevent request stacking

// --- LEARNING MEMORY ---
let patternMemory: TradePattern[] = [];
let pnlVelocity: number[] = [];
let pnlVarianceHistory: number[] = [];

function getFreshState(): BotState {
    return {
        isRunning: false, // Default to false, will restore from session
        market: { symbol: DISPLAY_SYMBOL, bid: 0, ask: 0, mid: 0, timestamp: Date.now() },
        activePosition: null,
        wallet: { startBalance: 0, balance: 0, virtualBalance: 0, virtualEquity: 0, usedMargin: 0, freeMargin: 0, totalProfit: 0, virtualTotalProfit: 0, growthPercentage: 0.0, winRate: 100.0, profitFactor: 0.0, efficiencyIndex: 90.0, dailyLoss: 0 },
        signal: { direction: Direction.NEUTRAL, confidence: 0, predictedPnL: 0, features: { rsi: 50, stochK: 50, stochD: 50, bbPosition: 0.5, volatility: 0, trendStrength: 0, imbalance: 0, divergence: 0, macdHist: 0, adx: 0 }, marketRegime: 'RANGING', learningEpoch: 0, memorySize: 0 },
        logs: [],
        simulationsRun: 0,
        priceHistory: [],
        system: { latency: 0, isFallbackMode: false }
    };
}

let currentState: BotState = getFreshState();

// --- HELPERS ---

async function fetchWithRotation(targetUrl: string, options: RequestInit = {}, isPost = false): Promise<Response> {
    let lastError;
    const proxies = isPost ? POST_PROXIES : GET_PROXIES;
    const startIndex = Math.floor(Math.random() * proxies.length);
    const rotatedProxies = [...proxies.slice(startIndex), ...proxies.slice(0, startIndex)];

    for (const proxyGen of rotatedProxies) {
        try {
            const proxyUrl = proxyGen(targetUrl);
            const start = Date.now();
            const response = await fetch(proxyUrl, { ...options, timeout: 15000 } as any);
            currentState.system.latency = Date.now() - start;

            if (response.status === 403 || response.status === 429) {
                throw new Error(`Proxy Rate Limited (${response.status})`);
            }
            return response;
        } catch (e) {
            lastError = e;
        }
    }
    throw lastError || new Error('All proxies failed');
}

function pushPrice(price: number) {
    priceHistory.push(price);
    if (priceHistory.length > 150) priceHistory.shift(); 
}

function addLog(msg: string, type: LogEntry['type']) {
  const entry: LogEntry = {
    id: Date.now() + Math.random(),
    timestamp: new Date().toLocaleTimeString(),
    message: msg,
    type: type
  };
  currentState.logs = [entry, ...currentState.logs].slice(0, 100);
}

// --- INDICATORS ---
function calculateRSI(prices: number[]): number {
  if (prices.length < RSI_PERIOD + 1) return 50;
  let gains = 0;
  let losses = 0;
  for (let i = prices.length - RSI_PERIOD; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff >= 0) gains += diff;
    else losses -= diff;
  }
  if (losses === 0) return 100;
  const rs = gains / losses;
  return 100 - (100 / (1 + rs));
}

function calculateStochRSI(rsis: number[]) {
    if (rsis.length < 14) return { k: 50, d: 50 };
    const periodRSIs = rsis.slice(-14);
    const minRSI = Math.min(...periodRSIs);
    const maxRSI = Math.max(...periodRSIs);
    
    let stoch = 50;
    if (maxRSI - minRSI !== 0) {
        stoch = ((periodRSIs[periodRSIs.length - 1] - minRSI) / (maxRSI - minRSI)) * 100;
    }
    return { k: stoch, d: stoch * 0.9 + 5 }; 
}

function calculateBollingerBands(prices: number[]) {
    if (prices.length < BB_PERIOD) return { upper: 0, middle: 0, lower: 0, position: 0.5 };
    
    const slice = prices.slice(-BB_PERIOD);
    const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
    const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / slice.length;
    const stdDev = Math.sqrt(variance);
    
    const upper = mean + (BB_MULTIPLIER * stdDev);
    const lower = mean - (BB_MULTIPLIER * stdDev);
    const current = prices[prices.length - 1];
    
    let position = 0.5;
    if (upper - lower !== 0) {
        position = (current - lower) / (upper - lower);
    }
    
    return { upper, middle: mean, lower, position };
}

function calculateEMA(prices: number[], period: number): number {
    if (prices.length < period) return prices[prices.length - 1];
    const k = 2 / (period + 1);
    let ema = prices[0];
    for (let i = 1; i < prices.length; i++) {
        ema = (prices[i] * k) + (ema * (1 - k));
    }
    return ema;
}

function calculateMACD(prices: number[]) {
    const fastPeriod = 12;
    const slowPeriod = 26;
    const signalPeriod = 9;
    
    if (prices.length < slowPeriod) return { macd: 0, signal: 0, histogram: 0 };

    const kFast = 2 / (fastPeriod + 1);
    const kSlow = 2 / (slowPeriod + 1);
    
    let emaFast = prices[0];
    let emaSlow = prices[0];
    const macdLine: number[] = [];

    for (let i = 1; i < prices.length; i++) {
        emaFast = (prices[i] * kFast) + (emaFast * (1 - kFast));
        emaSlow = (prices[i] * kSlow) + (emaSlow * (1 - kSlow));
        if (i >= slowPeriod) {
            macdLine.push(emaFast - emaSlow);
        }
    }

    if (macdLine.length < signalPeriod) return { macd: 0, signal: 0, histogram: 0 };

    const kSignal = 2 / (signalPeriod + 1);
    let signalLine = macdLine[0];
    for (let i = 1; i < macdLine.length; i++) {
        signalLine = (macdLine[i] * kSignal) + (signalLine * (1 - kSignal));
    }

    const currentMACD = macdLine[macdLine.length - 1];
    const histogram = currentMACD - signalLine;

    return { macd: currentMACD, signal: signalLine, histogram };
}

// v5.7: Simple ADX Approximation (Trend Strength)
function calculateADX(prices: number[]): number {
    if (prices.length < 14) return 0;
    // Real ADX is complex, using simplified Volatility/Trend ratio for speed
    const changes = [];
    for (let i = 1; i < prices.length; i++) changes.push(Math.abs(prices[i] - prices[i-1]));
    const avgChange = changes.reduce((a,b)=>a+b,0) / changes.length;
    const totalRange = Math.max(...prices) - Math.min(...prices);
    // Normalize to 0-100
    const adx = Math.min(100, (avgChange / (totalRange || 1)) * 1000);
    return adx;
}

function calculateStandardDeviation(prices: number[]): number {
    if (prices.length < 5) return 0;
    const mean = prices.reduce((a, b) => a + b, 0) / prices.length;
    const variance = prices.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / prices.length;
    return Math.sqrt(variance);
}

function calculateDivergence(prices: number[], rsis: number[]): number {
    if (prices.length < 10 || rsis.length < 10) return 0;
    
    const priceCurr = prices[prices.length - 1];
    const pricePrev = prices[prices.length - 6]; 
    const rsiCurr = rsis[rsis.length - 1];
    const rsiPrev = rsis[rsis.length - 6];

    if (priceCurr < pricePrev && rsiCurr > rsiPrev + 2) return 1;
    if (priceCurr > pricePrev && rsiCurr < rsiPrev - 2) return -1;

    return 0;
}

function detectMarketRegime(volatility: number, trendStrength: number): 'RANGING' | 'TRENDING' | 'VOLATILE' {
    if (volatility > 2.0) return 'VOLATILE';
    if (Math.abs(trendStrength) > 1.0) return 'TRENDING';
    return 'RANGING';
}

// --- INITIALIZATION & UTILS ---
function saveSession() {
    try {
        const sessionData = {
            timestamp: Date.now(),
            isRunning: currentState.isRunning, 
            wallet: currentState.wallet,
            activePosition: currentState.activePosition,
            efficiencyIndex: currentState.wallet.efficiencyIndex,
            consecutiveWins, consecutiveLosses, grossWins, grossLosses,
            dailyLossCurrent, lastDayReset,
            patternMemory, pnlVelocity, pnlVarianceHistory
        };
        localStorage.setItem('hitbtc_bot_session', JSON.stringify(sessionData));
    } catch(e) {}
}

function restoreSession() {
    try {
        const raw = localStorage.getItem('hitbtc_bot_session');
        if (raw) {
            const data = JSON.parse(raw);
            if (Date.now() - data.timestamp < 48 * 60 * 60 * 1000) { 
                currentState.isRunning = data.isRunning ?? false;
                currentState.wallet = { ...currentState.wallet, ...data.wallet };
                currentState.wallet.efficiencyIndex = data.efficiencyIndex || 90;
                consecutiveWins = data.consecutiveWins || 0;
                consecutiveLosses = data.consecutiveLosses || 0;
                grossWins = data.grossWins || 0;
                grossLosses = data.grossLosses || 0;
                dailyLossCurrent = data.dailyLossCurrent || 0;
                lastDayReset = data.lastDayReset || Date.now();
                
                if(data.activePosition) currentState.activePosition = data.activePosition; 
                
                if (data.patternMemory) patternMemory = data.patternMemory;
                if (data.pnlVelocity) pnlVelocity = data.pnlVelocity;
                if (data.pnlVarianceHistory) pnlVarianceHistory = data.pnlVarianceHistory;

                addLog('[SESSION] Previous state restored.', 'SUCCESS');
                if (currentState.isRunning) addLog('[RESUME] Bot Auto-Resumed from session.', 'INFO');
            }
        }
    } catch(e) {}
}

function formatVirtual(value: number): string {
    return `$${(value * SCALING_FACTOR).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function calculateSmartEntrySize(wallet: BotState['wallet'], marketPrice: number, patternMatchScore: number, predictedPnL: number): number {
    let base = MIN_QTY;
    if (wallet.efficiencyIndex > 85) base += MIN_QTY; 
    
    const pnlVariance = calculateStandardDeviation(pnlVarianceHistory);
    if (pnlVariance > 0.0005) base = MIN_QTY; 
    else if (predictedPnL > 1000 && pnlVariance < 0.0001) base *= 1.5;

    if (patternMatchScore > 0) {
        base *= 1.2; 
        base = Math.ceil(base * 1000) / 1000;
    }

    if (wallet.totalProfit > 0) {
        const profitRiskAmount = wallet.totalProfit * 0.15; 
        const extraQty = profitRiskAmount / (marketPrice / LEVERAGE); 
        base += extraQty;
    }
    base = Math.min(base, MIN_QTY * 20); 
    if (consecutiveLosses > 1 || wallet.efficiencyIndex < 60) base = MIN_QTY;
    
    const maxAllowedMarginUsage = (wallet.balance * MAX_WALLET_USAGE_PCT);
    const availableForNewTrade = maxAllowedMarginUsage - wallet.usedMargin;
    let maxSafeQty = 0;
    if (availableForNewTrade > 0) {
        maxSafeQty = (availableForNewTrade * LEVERAGE) / marketPrice;
    }
    const physicalMaxQty = (wallet.freeMargin * 0.99 * LEVERAGE) / marketPrice;
    let finalSize = Math.min(base, maxSafeQty, physicalMaxQty);
    finalSize = Math.floor(finalSize * 1000) / 1000;
    return finalSize;
}

function matchPattern(current: TradePattern): number {
    if (patternMemory.length === 0) return 0;
    let bestMatchScore = -999;
    for(const mem of patternMemory) {
        const distRsi = Math.abs(current.rsi - mem.rsi);
        const distTrend = Math.abs(current.trendStrength - mem.trendStrength);
        const distVol = Math.abs(current.volatility - mem.volatility);
        const distImb = Math.abs(current.imbalance - mem.imbalance);
        
        const similarity = 100 - (distRsi + (distTrend * 10) + (distVol * 10) + (distImb * 20)); 
        if (similarity > 70) { 
            if (mem.result === 'WIN') bestMatchScore = Math.max(bestMatchScore, 1); 
            if (mem.result === 'LOSS') bestMatchScore = Math.max(bestMatchScore, -1); 
        }
    }
    return bestMatchScore === -999 ? 0 : bestMatchScore;
}

// --- EXECUTION ENGINE ---

async function initCCXT() {
  if (!API_KEY || !API_SECRET) {
      addLog('[SYSTEM] API Keys Missing. Skipping CCXT init.', 'WARNING');
      return;
  }
  try {
    // @ts-ignore
    if (window.ccxt && window.ccxt.hitbtc) {
      // @ts-ignore
      ccxtExchange = new window.ccxt.hitbtc({
        apiKey: API_KEY,
        secret: API_SECRET,
        enableRateLimit: true,
        options: { defaultType: 'swap' } 
      });
      
      try {
         const markets = await ccxtExchange.loadMarkets();
         const market = Object.values(markets).find((m: any) => m.id === SYMBOL);
         if (market) {
             // @ts-ignore
             CCXT_SYMBOL = market.symbol;
             addLog(`Mapped ${SYMBOL} to CCXT: ${CCXT_SYMBOL}`, 'INFO');
         }
      } catch(e) {}
      addLog('CCXT HitBTC instance initialized.', 'INFO');
      useRealTrading = true;
    } else {
      addLog('CCXT library not found. Using simulation.', 'WARNING');
    }
  } catch (e: any) {
    addLog(`Failed to init CCXT: ${e.message}`, 'ERROR');
  }
}

async function executeRealOrder(side: 'buy' | 'sell', amount: number, price?: number, orderSymbol: string = SYMBOL) {
    if (!API_KEY || !API_SECRET) {
        addLog('[ERROR] Cannot Place Order: Missing API Keys.', 'ERROR');
        return null;
    }
    const scaledAmount = formatVirtual(amount * (price || 2.7)); 
    addLog(`HitBTC Order: ${side.toUpperCase()} ${amount.toFixed(3)} ATOM (Est Value: ${scaledAmount})`, 'WARNING');
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const body = new URLSearchParams();
        body.append('symbol', orderSymbol); 
        body.append('side', side);
        body.append('quantity', amount.toFixed(3)); 
        body.append('type', 'market');
        body.append('margin_mode', 'cross');
        
        const targetUrl = "https://api.hitbtc.com/api/3/futures/order";
        
        const response = await fetchWithRotation(targetUrl, {
            method: 'POST',
            headers: {
                'Authorization': `Basic ${auth}`,
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: body
        }, true); // isPost = true

        if (response.ok) {
             const data = await response.json();
             addLog(`REAL ORDER SUCCESS: ID ${data.id || 'UNKNOWN'}`, 'SUCCESS');
             return data;
        } else {
            const text = await response.text();
            addLog(`API REJECT: ${text.substring(0, 120)}`, 'ERROR');
            throw new Error(`API Status ${response.status}: ${text.substring(0, 100)}`);
        }
    } catch (error: any) {
        addLog(`Order Failed (Network/Auth): ${error.message}. Switching to Simulation for this order.`, 'WARNING');
        return {
            id: `SIM-${Date.now()}`,
            avgPrice: price ? price.toString() : '0',
            quantity: amount.toString()
        }; 
    }
}

async function closeAllPositionsOnStart() {
    if (!API_KEY || !API_SECRET) return;
    addLog('Checking for existing positions to manage...', 'INFO');
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const targetUrl = "https://api.hitbtc.com/api/3/futures/position";
        
        const response = await fetchWithRotation(targetUrl, {
            headers: { 'Authorization': `Basic ${auth}` }
        });

        if (response.ok) {
            const data = await response.json();
            if (Array.isArray(data)) {
                let found = false;
                for (const pos of data) {
                    if (pos.symbol === SYMBOL) {
                        const size = parseFloat(pos.quantity);
                        const pnl = parseFloat(pos.pnl || 0);
                        const entry = parseFloat(pos.price_entry || pos.price || 0);

                        if (size !== 0) {
                            found = true;
                            const estimatedValue = Math.abs(size) * entry;
                            const roundTripFee = estimatedValue * TAKER_FEE_RATE * 2;
                            const netPnL = pnl - roundTripFee;

                            if (netPnL > 0) {
                                const closeSide = size > 0 ? 'sell' : 'buy';
                                const absSize = Math.abs(size);
                                addLog(`Closing existing ${pos.symbol} (${size}) in REAL PROFIT. Starting fresh.`, 'SUCCESS');
                                await executeRealOrder(closeSide, absSize, undefined, pos.symbol);
                            } else {
                                addLog(`Adopting existing ${pos.symbol} position (${size}). PnL not in profit. Attempting recovery.`, 'WARNING');
                                currentState.activePosition = {
                                    id: `ADOPTED-${Date.now()}`,
                                    symbol: SYMBOL,
                                    direction: size > 0 ? Direction.LONG : Direction.SHORT,
                                    entryPrice: entry,
                                    size: Math.abs(size),
                                    unrealizedPnL: pnl,
                                    highestPnL: pnl,
                                    targetPnL: Math.abs(size) * entry * MIN_ROIE_PCT,
                                    leverage: LEVERAGE,
                                    timestamp: Date.now()
                                };
                                const marginUsed = (Math.abs(size) * entry) / LEVERAGE;
                                currentState.wallet.usedMargin += marginUsed;
                                currentState.wallet.freeMargin -= marginUsed;
                            }
                        }
                    }
                }
                if (!found) addLog('No open positions found on startup.', 'SUCCESS');
            }
        }
    } catch (e: any) {
        addLog(`Failed to sync/close positions: ${e.message}`, 'ERROR');
    }
}

async function syncWallet() {
    if (!API_KEY || !API_SECRET) return;
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const targetUrl = "https://api.hitbtc.com/api/3/futures/balance";
        
        const response = await fetchWithRotation(targetUrl, {
            headers: { 'Authorization': `Basic ${auth}` }
        });

        if (response.ok) {
            const data = await response.json();
            let usdt = null; // Fix: Use 'usdt' to match potential usages causing errors
            if (Array.isArray(data)) usdt = data.find((a: any) => a.currency === 'USDT');
            if (usdt) {
                const rawBalance = usdt.cross_margin_reserved || usdt.reserved_margin || '0';
                const rawAvailable = usdt.available || 0;
                const realWalletBalance = parseFloat(rawBalance);
                const apiAvailable = parseFloat(usdt.available || '0');
                // Strict map: If API available is 0 but reserved > 0, assume reserved is the balance we can use
                const calculatedFree = (apiAvailable === 0 && realWalletBalance > 0) ? realWalletBalance : apiAvailable;
                
                currentState.wallet.balance = realWalletBalance; 
                currentState.wallet.freeMargin = calculatedFree;
                let used = realWalletBalance - calculatedFree;
                if (used < 0) used = 0;
                currentState.wallet.usedMargin = used; 
                
                currentState.wallet.virtualBalance = realWalletBalance * SCALING_FACTOR;
                currentState.wallet.virtualEquity = (realWalletBalance + (currentState.activePosition?.unrealizedPnL || 0)) * SCALING_FACTOR;
                currentState.wallet.virtualTotalProfit = currentState.wallet.totalProfit * SCALING_FACTOR;

                if (currentState.wallet.startBalance <= 0 && realWalletBalance > 0) {
                    currentState.wallet.startBalance = realWalletBalance;
                }
                // SIMULATION FALLBACK ONLY IF EXPLICITLY ENABLED OR DEV MODE
                if (realWalletBalance <= 0.0001 && realWalletBalance === 0 && useRealTrading === false) {
                    currentState.wallet.balance = 50.00;
                    currentState.wallet.virtualBalance = 50.00 * SCALING_FACTOR; 
                    currentState.wallet.freeMargin = 50.00 - currentState.wallet.usedMargin;
                }
            }
        }
    } catch (e) {}
}

async function syncRealPosition() {
    if (!API_KEY || !API_SECRET) return;
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const targetUrl = "https://api.hitbtc.com/api/3/futures/account";
        
        const response = await fetchWithRotation(targetUrl, {
            headers: { 'Authorization': `Basic ${auth}` }
        });

        if (response.ok) {
            const data = await response.json();
            let posData = null;
            if (data.positions && Array.isArray(data.positions)) {
                posData = data.positions.find((p: any) => p.symbol === SYMBOL);
            } else if (Array.isArray(data)) {
                 for (const acc of data) {
                     if (acc.positions && Array.isArray(acc.positions)) {
                         const found = acc.positions.find((p: any) => p.symbol === SYMBOL);
                         if (found) { posData = found; break; }
                     }
                 }
            }
            if (!posData && currentState.activePosition && currentState.activePosition.id.startsWith('REAL')) {
                 addLog(`[OFFLINE SYNC] Position detected closed on exchange. Updating PnL.`, 'WARNING');
                 currentState.activePosition = null;
            }
            if (posData) {
                 const rawEntryPrice = posData.price_entry || posData.price;
                 const size = parseFloat(posData.quantity || posData.size || 0);
                 if (size !== 0 && rawEntryPrice) {
                     const realEntryPrice = parseFloat(rawEntryPrice); 
                     const pnl = parseFloat(posData.pnl || 0);
                     let previousHighest = pnl;
                     const baseTarget = Math.abs(size) * realEntryPrice * MIN_ROIE_PCT;
                     let preservedTarget = baseTarget;
                     if (currentState.activePosition && currentState.activePosition.symbol === SYMBOL) {
                         previousHighest = Math.max(currentState.activePosition.highestPnL || -999, pnl);
                         preservedTarget = currentState.activePosition.targetPnL || baseTarget;
                     }
                     currentState.activePosition = {
                         id: `REAL-POS-${SYMBOL}`, 
                         symbol: SYMBOL,
                         direction: size > 0 ? Direction.LONG : Direction.SHORT,
                         entryPrice: realEntryPrice,
                         size: Math.abs(size),
                         unrealizedPnL: pnl,
                         highestPnL: previousHighest,
                         targetPnL: preservedTarget,
                         leverage: LEVERAGE, 
                         timestamp: currentState.activePosition?.timestamp || Date.now()
                     };
                 } else {
                     if (currentState.activePosition && currentState.activePosition.id.startsWith('REAL')) {
                         currentState.activePosition = null;
                         addLog('Position closed on exchange', 'INFO');
                     }
                 }
            }
        }
    } catch (e) {}
}

async function updateMarketData() {
  if (!API_KEY || !API_SECRET) return; // Stop fetch if no keys
  if (isFetchingMarket) return; // Prevent stacking requests
  isFetchingMarket = true;

  let success = false;
  if (ccxtExchange) {
      try {
          const ticker = await ccxtExchange.fetchTicker(CCXT_SYMBOL); 
          if (ticker && ticker.bid && ticker.ask) {
              currentState.market = {
                  symbol: DISPLAY_SYMBOL,
                  bid: ticker.bid,
                  ask: ticker.ask,
                  mid: (ticker.bid + ticker.ask) / 2,
                  timestamp: Date.now()
              };
              pushPrice(currentState.market.mid);
              success = true;
          }
      } catch (e) { }
  }
  if (!success) {
      try {
        const targetUrl = `https://api.hitbtc.com/api/3/public/ticker/${SYMBOL}`;
        const response = await fetchWithRotation(targetUrl);

        if (response.ok) {
             const data = await response.json();
             if (data && (data.ask || data.last)) {
                const bid = parseFloat(data.bid || data.last);
                const ask = parseFloat(data.ask || data.last);
                currentState.market = {
                    symbol: DISPLAY_SYMBOL,
                    bid: bid,
                    ask: ask,
                    mid: (bid + ask) / 2,
                    timestamp: Date.now()
                };
                pushPrice(currentState.market.mid);
                success = true;
            }
        }
      } catch (e) { }
  }
  // Strict Fallback: Only if stale > 10s
  if (!success && Date.now() - currentState.market.timestamp > 10000) {
    // Fallback logic removed to enforce REAL prices. 
    // If API fails for 10s, we just wait. No fake candles.
    addLog('[MARKET] Data stale. Waiting for API...', 'WARNING');
  }
  
  const ema = calculateEMA(priceHistory, EMA_PERIOD);
  const mid = currentState.market.mid;
  const divergence = (mid - ema) / ema;
  currentState.signal.features.imbalance = Math.max(-1, Math.min(1, divergence * 500));
  
  isFetchingMarket = false; // Unlock
}

async function runAIStrategy() {
    if (!currentState.isRunning) return;
    if (!API_KEY || !API_SECRET) return; // Stop strategy if no keys

    const { market, activePosition, wallet } = currentState;
    
    if (wallet.startBalance > 0) {
        currentState.wallet.growthPercentage = ((wallet.balance - wallet.startBalance) / wallet.startBalance) * 100;
    }
    
    // FAST TICK SIMULATION with REAL PRICES
    if (activePosition) {
        // Use Bid/Ask for real exit simulation (Slippage Simulation)
        const exitPrice = activePosition.direction === Direction.LONG ? market.bid : market.ask;
        const pnl = activePosition.direction === Direction.LONG 
            ? (exitPrice - activePosition.entryPrice) * activePosition.size 
            : (activePosition.entryPrice - exitPrice) * activePosition.size;
        
        activePosition.unrealizedPnL = pnl; 
        
        // Interpolation for smooth graph if API is slow (drift logic)
        if (Date.now() - market.timestamp > 500) {
             const drift = (Math.random() - 0.5) * (market.mid * 0.0001);
             activePosition.unrealizedPnL += (drift * activePosition.size);
        }
    }

    // PROFIT FACTOR & STATS
    if (wallet.totalProfit > lastTotalProfit) {
        const gain = wallet.totalProfit - lastTotalProfit;
        grossWins += gain;
        const boost = gain >= 0.00001 ? 5.0 : 1.0; 
        currentState.wallet.efficiencyIndex = Math.min(100, currentState.wallet.efficiencyIndex + boost); 
        consecutiveWins++;
        consecutiveLosses = 0;
        if (consecutiveWins % 3 === 0) addLog(`[STREAK] ${consecutiveWins} Wins! Efficiency Boosted.`, 'SUCCESS');
        lastTotalProfit = wallet.totalProfit;
    } else if (wallet.totalProfit < lastTotalProfit) {
        const loss = lastTotalProfit - wallet.totalProfit;
        grossLosses += loss;
        currentState.wallet.efficiencyIndex = Math.max(40, currentState.wallet.efficiencyIndex - 2.5);
        consecutiveLosses++;
        consecutiveWins = 0;
        if (consecutiveLosses >= 2) addLog(`[DRAWDOWN] ${consecutiveLosses} Consecutive Losses. Defensive Mode.`, 'WARNING');
        lastTotalProfit = wallet.totalProfit;
    }
    
    if (grossLosses > 0) currentState.wallet.profitFactor = grossWins / grossLosses;
    else currentState.wallet.profitFactor = grossWins > 0 ? 999 : 0;

    let theoreticalUsedMargin = 0;
    if (activePosition) {
        theoreticalUsedMargin = (activePosition.entryPrice * activePosition.size) / LEVERAGE;
        if (wallet.usedMargin < theoreticalUsedMargin) {
            wallet.usedMargin = theoreticalUsedMargin;
            wallet.freeMargin = wallet.balance - theoreticalUsedMargin;
        }
    }
    const walletUsageRatio = wallet.usedMargin / (wallet.balance || 0.000001);

    // --- INDICATOR CALCULATIONS ---
    const currentRSI = calculateRSI(priceHistory);
    rsiHistory.push(currentRSI);
    if (rsiHistory.length > 50) rsiHistory.shift();

    const { k: stochK, d: stochD } = calculateStochRSI(rsiHistory);
    const { upper: bbUpper, lower: bbLower, position: bbPosition } = calculateBollingerBands(priceHistory);
    const currentEMA = calculateEMA(priceHistory, EMA_PERIOD);
    const slowEMA = calculateEMA(priceHistory, SLOW_EMA_PERIOD); // v5.7 Trend Bias
    const { macd, signal: macdSignal, histogram: macdHist } = calculateMACD(priceHistory);
    macdHistory.push(macdHist);
    if (macdHistory.length > 10) macdHistory.shift();

    const stdDev = calculateStandardDeviation(priceHistory.slice(-20));
    const volatility = (stdDev / market.mid) * 1000; 
    const trendStrength = ((market.mid - currentEMA) / currentEMA) * 1000;
    const imbalance = currentState.signal.features.imbalance;
    const divergence = calculateDivergence(priceHistory, rsiHistory);
    const marketRegime = detectMarketRegime(volatility, trendStrength);
    const adx = calculateADX(priceHistory); // v5.7 ADX

    currentState.signal.marketRegime = marketRegime;
    currentState.signal.features = {
        rsi: parseFloat(currentRSI.toFixed(2)),
        stochK: parseFloat(stochK.toFixed(1)),
        stochD: parseFloat(stochD.toFixed(1)),
        bbPosition: parseFloat(bbPosition.toFixed(2)),
        volatility: parseFloat(volatility.toFixed(4)),
        trendStrength: parseFloat(trendStrength.toFixed(2)),
        imbalance: parseFloat(imbalance.toFixed(2)),
        divergence: divergence,
        macdHist: parseFloat(macdHist.toFixed(6)),
        adx: parseFloat(adx.toFixed(1))
    };

    let signalDirection = Direction.NEUTRAL;
    let rawConfidence = 0;
    const isOversold = stochK < 20 && currentRSI < 40;
    const isOverbought = stochK > 80 && currentRSI > 60;
    const atLowerBand = bbPosition <= 0.1; 
    const atUpperBand = bbPosition >= 0.9; 

    // v5.7: Momentum Filters (Strict)
    const macdSlope = macdHistory.length > 1 ? macdHist - macdHistory[macdHistory.length-2] : 0;
    const isBullishMomentum = macdSlope > 0;
    const isBearishMomentum = macdSlope < 0;

    // v5.7: Higher Timeframe Bias
    const isUptrend = market.mid > slowEMA;
    const isDowntrend = market.mid < slowEMA;

    if (marketRegime === 'RANGING') {
        // In Range: BB Reversals are valid BUT require momentum turn
        if (atLowerBand && isOversold && isBullishMomentum) { signalDirection = Direction.LONG; rawConfidence = 80; } 
        else if (atUpperBand && isOverbought && isBearishMomentum) { signalDirection = Direction.SHORT; rawConfidence = 80; }
    } else if (marketRegime === 'TRENDING') {
        // In Trend: Follow trend, ignore OB/OS unless divergence
        if (trendStrength > 0.5 && stochK < 60 && isBullishMomentum) { signalDirection = Direction.LONG; rawConfidence = 75; } 
        else if (trendStrength < -0.5 && stochK > 40 && isBearishMomentum) { signalDirection = Direction.SHORT; rawConfidence = 75; }
        
        // ADX Filter: If strong trend, block counter-trend trades
        if (adx > 25) {
            if (signalDirection === Direction.LONG && trendStrength < -0.5) rawConfidence = 0; // Don't buy strong downtrend
            if (signalDirection === Direction.SHORT && trendStrength > 0.5) rawConfidence = 0; // Don't short strong uptrend
        }
    } else {
        // Volatile: Rely on Divergence
        if (divergence === 1 && isBullishMomentum) { signalDirection = Direction.LONG; rawConfidence = 65; }
        if (divergence === -1 && isBearishMomentum) { signalDirection = Direction.SHORT; rawConfidence = 65; }
    }

    // Confidence Boosters/Penalties
    if (signalDirection === Direction.LONG) {
        if (imbalance > 0) rawConfidence += 10;
        if (divergence === 1) rawConfidence += 15;
        if (isDowntrend && currentRSI > 25) rawConfidence -= 20; // Fighting trend penalty
    } else if (signalDirection === Direction.SHORT) {
        if (imbalance < 0) rawConfidence += 10;
        if (divergence === -1) rawConfidence += 15;
        if (isUptrend && currentRSI < 75) rawConfidence -= 20; // Fighting trend penalty
    }

    if (signalDirection === Direction.LONG && market.mid < currentEMA && rawConfidence < 90) {
        rawConfidence -= 10; 
    }
    if (signalDirection === Direction.SHORT && market.mid > currentEMA && rawConfidence < 90) {
        rawConfidence -= 10;
    }

    rawConfidence = Math.min(99.9, rawConfidence);
    const efficiencyMultiplier = currentState.wallet.efficiencyIndex / 100;
    const confidence = rawConfidence * efficiencyMultiplier;

    currentState.signal.direction = signalDirection;
    currentState.signal.confidence = parseFloat(confidence.toFixed(1));
    currentState.signal.predictedPnL = (wallet.virtualBalance * 0.01 * (confidence / 100)); 
    currentState.simulationsRun++;
    currentState.priceHistory = [...priceHistory]; 

    // --- TRADING LOGIC ---
    if (!activePosition) {
        if (signalDirection !== Direction.NEUTRAL) {
             if (walletUsageRatio > MAX_WALLET_USAGE_PCT) {
                 if (Math.random() < 0.05) addLog(`[SKIP] Wallet usage > ${(MAX_WALLET_USAGE_PCT*100).toFixed(0)}%. Entry blocked.`, 'WARNING');
                 return;
             }
             const stopLossDist = market.mid * 0.005;
             const targetDist = market.mid * 0.005;
             const winProb = confidence / 100;
             const ev = (winProb * targetDist) - ((1-winProb) * stopLossDist);
             if (ev <= 0) {
                 if (Math.random() < 0.05) addLog(`[EV-SKIP] Expected Value negative.`, 'INFO');
                 return;
             }

             let requiredConfidence = 55;
             
             if (confidence > requiredConfidence) {
                 if (wallet.freeMargin <= 0.00000001) {
                     if(Math.random() < 0.05) addLog(`[SKIP] Valid Signal but Zero Free Margin.`, 'WARNING');
                 } else {
                    let calculatedSize = MIN_QTY;
                    if (wallet.efficiencyIndex > 85) calculatedSize += MIN_QTY;
                    if (currentState.signal.predictedPnL > 1000) calculatedSize *= 1.5;

                    calculatedSize = Math.max(MIN_QTY, calculatedSize);
                    
                    const estimatedPrice = signalDirection === Direction.LONG ? market.ask : market.bid;
                    const actualCost = (estimatedPrice * calculatedSize) / LEVERAGE;

                    if (wallet.freeMargin >= actualCost) {
                        const side = signalDirection === Direction.LONG ? 'buy' : 'sell';
                        const divMsg = divergence !== 0 ? ` + Div(${divergence})` : '';
                        addLog(`[AI-ENTRY] ${signalDirection} ${calculatedSize.toFixed(3)} ATOM. Conf: ${confidence.toFixed(1)}%${divMsg}`, 'INFO');
                        const orderResult = await executeRealOrder(side, calculatedSize, estimatedPrice);
                        
                        if (orderResult) {
                            const realEntry = (orderResult.avgPrice && parseFloat(orderResult.avgPrice) > 0) ? parseFloat(orderResult.avgPrice) : estimatedPrice;
                            const initialFee = (realEntry * calculatedSize) * TAKER_FEE_RATE * 2;
                            const baseTarget = (realEntry * calculatedSize) * MIN_ROIE_PCT;
                            const initialTarget = Math.max(initialFee * 3.0, baseTarget, MICRO_PROFIT_TARGET);
                            currentState.activePosition = {
                                id: `ORD-${Date.now().toString().slice(-6)}`,
                                symbol: DISPLAY_SYMBOL,
                                direction: signalDirection,
                                entryPrice: realEntry,
                                size: calculatedSize,
                                unrealizedPnL: 0,
                                highestPnL: 0,
                                targetPnL: initialTarget,
                                leverage: LEVERAGE, 
                                timestamp: Date.now()
                            };
                            wallet.usedMargin += actualCost;
                            wallet.freeMargin -= actualCost;
                        }
                    }
                 }
             }
        }
    } else {
        const price = market.mid;
        const entry = activePosition.entryPrice;
        const pnl = activePosition.unrealizedPnL; 
        
        if (activePosition.unrealizedPnL > (activePosition.highestPnL || -9999)) activePosition.highestPnL = activePosition.unrealizedPnL;

        const positionValue = activePosition.size * price;
        const entryFeeEstimate = (activePosition.size * activePosition.entryPrice) * TAKER_FEE_RATE;
        const exitFeeEstimate = positionValue * TAKER_FEE_RATE;
        const roundTripFee = entryFeeEstimate + exitFeeEstimate;
        const netPnL = activePosition.unrealizedPnL - roundTripFee; 

        const roiTarget = (activePosition.size * activePosition.entryPrice) * MIN_ROIE_PCT;
        let dynamicProfitTarget = Math.max(roundTripFee * 3.0, roiTarget, MICRO_PROFIT_TARGET); 
        
        if (wallet.efficiencyIndex > 95) dynamicProfitTarget *= 1.20;
        else if (wallet.efficiencyIndex < 80) dynamicProfitTarget *= 0.90;
        if (marketRegime === 'TRENDING') dynamicProfitTarget *= 1.50;
        
        let volMult = 1.0;
        if (volatility > 2.0) volMult = 2.0; 
        else if (volatility > 1.0) volMult = 1.5;
        activePosition.targetPnL = dynamicProfitTarget;

        if (activePosition.highestPnL >= roundTripFee * 3.0) {
            if (activePosition.unrealizedPnL < roundTripFee * 2.8) { 
                 addLog(`[FEE-FLOOR] PnL dropped below 2.8x Fees. Closing.`, 'WARNING');
                 const side = activePosition.direction === Direction.LONG ? 'sell' : 'buy';
                 await executeRealOrder(side, activePosition.size, price);
                 wallet.totalProfit += netPnL; 
                 currentState.activePosition = null;
                 wallet.usedMargin = 0;
                 return;
            }
        }

        if (activePosition.unrealizedPnL > (dynamicProfitTarget * 1.10)) {
             // v5.6 Flash Close logic is implicitly here by 200ms check
             addLog(`[FORCE-TARGET] Target exceeded by 10%. Locking in.`, 'SUCCESS');
             await executeRealOrder(activePosition.direction === Direction.LONG ? 'sell' : 'buy', activePosition.size, price);
             wallet.totalProfit += netPnL;
             currentState.activePosition = null;
             wallet.usedMargin = 0;
             return;
        }
        
        if (activePosition.highestPnL > dynamicProfitTarget * 0.95) {
            const lockedProfit = activePosition.highestPnL * 0.90; 
            const minimumSafe = roundTripFee * 2.0;
            if (activePosition.unrealizedPnL < Math.max(lockedProfit, minimumSafe)) {
                 addLog(`[RATCHET] Protecting Gains. Closing.`, 'WARNING');
                 await executeRealOrder(activePosition.direction === Direction.LONG ? 'sell' : 'buy', activePosition.size, price);
                 wallet.totalProfit += netPnL;
                 currentState.activePosition = null;
                 wallet.usedMargin = 0;
                 return;
            }
        }
        
        // v5.6: Scalper Time Limit (3 mins)
        // v5.7: Aggressive Break-Even. If time > 3 min and PnL > Fees, exit to free capital.
        const isStale = (Date.now() - activePosition.timestamp) > (3 * 60 * 1000);
        if (isStale && netPnL > 0 && activePosition.size > MIN_QTY) {
             addLog(`[STALEMATE] Aggressive Break-Even Exit (Profitable).`, 'WARNING');
             await executeRealOrder(activePosition.direction === Direction.LONG ? 'sell' : 'buy', activePosition.size, price);
             currentState.activePosition = null;
             wallet.usedMargin = 0;
             return;
        }

        const highDrawdown = activePosition.unrealizedPnL < -0.0005; 
        if ((walletUsageRatio > MAX_WALLET_USAGE_PCT || highDrawdown) && activePosition.size > MIN_QTY * 2) {
             let canTrim = false;
             if (wallet.totalProfit > Math.abs(pnl) * 0.5) canTrim = true; 
             if (canTrim) {
                 addLog('Smart De-Risking (Profit Funded)', 'WARNING'); 
                 await executeRealOrder(activePosition.direction === Direction.LONG ? 'sell' : 'buy', MIN_QTY, price);
                 const portionGross = (pnl / activePosition.size) * MIN_QTY;
                 const portionFees = (market.mid * MIN_QTY * TAKER_FEE_RATE) + (entry * MIN_QTY * TAKER_FEE_RATE);
                 const trimNetPnL = portionGross - portionFees;
                 wallet.totalProfit += trimNetPnL;
                 activePosition.size -= MIN_QTY; 
             }
        }
        
        if (activePosition && walletUsageRatio < MAX_WALLET_USAGE_PCT) {
             if (activePosition.unrealizedPnL > PYRAMID_THRESHOLD_PNL) { 
                 const isTrendAligned = activePosition.direction === Direction.LONG ? trendStrength > 0.5 : trendStrength < -0.5;
                 if (isTrendAligned) {
                     addLog(`[PYRAMID] Adding to winner.`, 'TRADE');
                     await executeRealOrder(activePosition.direction === Direction.LONG ? 'buy' : 'sell', MIN_QTY, price);
                     activePosition.size += MIN_QTY;
                 }
             }
             const priceDeviation = Math.abs((price - activePosition.entryPrice) / activePosition.entryPrice);
             let requiredDeviation = BASE_GRID_DEVIATION; 
             if (volatility > 1.0) requiredDeviation *= 1.5;

             if (priceDeviation > requiredDeviation && pnl < 0) { 
                 // v5.7: Grid requires RSI to be oversold AND turning to add
                 const rsiSlope = rsiHistory.length > 1 ? currentRSI - rsiHistory[rsiHistory.length - 2] : 0;
                 const isRsiTurning = activePosition.direction === Direction.LONG ? rsiSlope > 0 : rsiSlope < 0;
                 const isOversoldGrid = activePosition.direction === Direction.LONG ? currentRSI < 35 : currentRSI > 65;
                 
                 if (isRsiTurning && isOversoldGrid) { 
                      let addSize = Math.max(MIN_QTY, activePosition.size * 0.5);
                      addSize = Math.min(addSize, MIN_QTY * 20); 
                      addSize = Math.floor(addSize * 1000) / 1000;
                      const cost = (market.mid * addSize) / LEVERAGE;
                      if (wallet.freeMargin > cost * 1.1) {
                          addLog(`Smart Grid Averaging (${addSize})`, 'TRADE'); 
                          await executeRealOrder(activePosition.direction === Direction.LONG ? 'buy' : 'sell', addSize, price); 
                          const oldVal = activePosition.entryPrice * activePosition.size;
                          const newVal = price * addSize;
                          activePosition.size += addSize;
                          activePosition.entryPrice = (oldVal + newVal) / activePosition.size;
                          wallet.usedMargin += cost;
                      }
                 } 
             }
        }
    }
    saveSession();
}

export function startBotEngine() {
    if (timerWorker) { timerWorker.terminate(); timerWorker = null; }
    if (marketInterval) clearInterval(marketInterval);
    
    priceHistory = []; rsiHistory = []; lastTotalProfit = 0; consecutiveWins = 0; consecutiveLosses = 0;
    
    restoreSession(); 
    if (!currentState.wallet.balance) currentState = getFreshState();
    if (!localStorage.getItem('hitbtc_bot_session')) {
        currentState.isRunning = true; 
    }

    // API KEY CHECK
    if (!API_KEY || !API_SECRET) {
        addLog('[SYSTEM] API Keys Missing. Please configure in Settings to start.', 'ERROR');
        currentState.isRunning = false;
        return; // STOP STARTUP
    }

    initCCXT();
    closeAllPositionsOnStart();
    
    marketInterval = setInterval(() => { updateMarketData(); }, 200);

    const blob = new Blob([`
        let interval;
        self.onmessage = function(e) {
            if (e.data.action === 'start') {
                if (interval) clearInterval(interval);
                // FAST TICK: 200ms interval to match price updates
                interval = setInterval(() => self.postMessage('tick'), 200); 
            } else if (e.data.action === 'stop') {
                if (interval) clearInterval(interval);
            }
        }
    `], { type: 'application/javascript' });

    timerWorker = new Worker(URL.createObjectURL(blob));
    timerWorker.onmessage = async () => {
        // Block execution loop if keys are missing (Double Check)
        if (!API_KEY || !API_SECRET) return; 
        await syncWallet();
        await syncRealPosition();
        await runAIStrategy();
    };
    timerWorker.postMessage({ action: 'start' });

    setTimeout(() => { addLog("[AI-CORE] Bot v5.7 Loaded. Profit Maximizer Engine Active (MACD+ADX).", "INFO"); }, 500);
}

export function stopBotEngine() {
    if (timerWorker) { timerWorker.postMessage({ action: 'stop' }); timerWorker.terminate(); timerWorker = null; }
    if (marketInterval) { clearInterval(marketInterval); marketInterval = null; }
    currentState.isRunning = false;
    saveSession(); 
}

export function setBotRunning(running: boolean) {
    if (running && (!API_KEY || !API_SECRET)) {
        addLog('[ERROR] Cannot Start: API Keys Missing.', 'ERROR');
        return;
    }
    currentState.isRunning = running;
    addLog(running ? 'ENGINE STARTED by User.' : 'ENGINE STOPPED by User.', running ? 'SUCCESS' : 'WARNING');
    saveSession();
}

export function getUpdatedState(): BotState {
    return { ...currentState };
}