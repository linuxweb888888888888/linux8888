
import { BotState, Direction, LogEntry, Position, MarketData, TradePattern } from '../types';

// --- Constants ---
const MIN_QTY = 0.001; // ATOM Min Step
const SYMBOL = 'ATOMUSDT_PERP'; // HitBTC Raw Futures Symbol ID
let CCXT_SYMBOL = 'ATOM/USDT:USDT'; // Default Unified (updated dynamically)
const DISPLAY_SYMBOL = 'ATOM/USDT (Perp)';
const TAKER_FEE_RATE = 0.0009; // 0.09% HitBTC Taker
const LEVERAGE = 20;
const RSI_PERIOD = 14;
const EMA_PERIOD = 20; // New: Trend Detection
const BB_PERIOD = 20; // Bollinger Bands
const BB_MULTIPLIER = 2; 

// --- HIGH VALUE SCALING CONFIGURATION ---
const SCALING_FACTOR = 100_000_000; 
const REAL_WALLET_CAP = 0.01; 
let MIN_ROIE_PCT = 0.0015; // Made Mutable for Learning (v4.3)
const MICRO_PROFIT_TARGET = 0.00012; // STRICT 12,000 Virtual USDT Target

// --- AGGRESSIVE SCALING CONFIG (v4.3) ---
const MAX_WALLET_USAGE_PCT = 0.80; // 80% Allocation
const BASE_GRID_DEVIATION = 0.001; // Tighter 0.1% grid for high freq
const PYRAMID_THRESHOLD_PNL = 0.0002; // Pyramid sooner (0.02% move)
const STALEMATE_THRESHOLD_MS = 15 * 60 * 1000; 

// --- LEARNING MEMORY (v4.7) ---
let patternMemory: TradePattern[] = [];
let rsiBuyThreshold = 35;
let rsiSellThreshold = 65;
let trendFilterWeight = 1.0; 
let pnlVelocity: number[] = []; // Track last 5 trade PnLs
let pnlVarianceHistory: number[] = []; // v4.7: Track PnL volatility
let lastTradeTime = Date.now(); 

// --- API Credentials ---
const API_KEY = '-3Mn7DL8P20iTj7QPoOSgyATuDcF-87h';
const API_SECRET = 'WzxCckLuICMXcjdRL-CbgcsbpGXHePcs';

// --- PROXY CONFIGURATION ---
const POST_PROXIES = [
    (url: string) => `https://corsproxy.io/?${encodeURIComponent(url)}`,
    (url: string) => `https://thingproxy.freeboard.io/fetch/${url}`,
];

const GET_PROXIES = [
    (url: string) => `https://corsproxy.io/?${encodeURIComponent(url)}`,
    (url: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
    (url: string) => `https://thingproxy.freeboard.io/fetch/${url}`,
];

// --- State Management ---
let priceHistory: number[] = []; 
let rsiHistory: number[] = []; 
let ccxtExchange: any = null;
let useRealTrading = false;
let lastTotalProfit = 0; 
let consecutiveWins = 0;
let consecutiveLosses = 0;
let grossWins = 0;
let grossLosses = 0;
let lastTradeCondition: TradePattern | null = null; 

// WEB WORKER TIMER
let timerWorker: Worker | null = null;
let marketInterval: ReturnType<typeof setInterval> | null = null;

function getFreshState(): BotState {
    return {
        isRunning: true,
        market: {
            symbol: DISPLAY_SYMBOL,
            bid: 0, 
            ask: 0,
            mid: 0,
            timestamp: Date.now(),
        },
        activePosition: null,
        wallet: {
            startBalance: 0, 
            balance: 0, 
            virtualBalance: 0, 
            virtualEquity: 0,  
            usedMargin: 0,
            freeMargin: 0, 
            totalProfit: 0,
            virtualTotalProfit: 0,
            growthPercentage: 0.0,
            winRate: 100.0,
            profitFactor: 0.0,
            efficiencyIndex: 90.0, 
        },
        signal: {
            direction: Direction.NEUTRAL,
            confidence: 0,
            predictedPnL: 0,
            features: { rsi: 50, stochK: 50, stochD: 50, bbPosition: 0.5, volatility: 0, trendStrength: 0, imbalance: 0, divergence: 0 },
            marketRegime: 'RANGING',
            learningEpoch: 0,
            memorySize: 0
        },
        logs: [],
        simulationsRun: 0,
        priceHistory: []
    };
}

let currentState: BotState = getFreshState();

// --- Helper Functions ---

async function fetchWithRotation(targetUrl: string, options: RequestInit = {}, method: 'GET' | 'POST' = 'GET'): Promise<Response> {
    let lastError;
    const proxyList = method === 'POST' ? POST_PROXIES : GET_PROXIES;

    for (const proxyGen of proxyList) {
        try {
            const proxyUrl = proxyGen(targetUrl);
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 5000); 
            
            const response = await fetch(proxyUrl, { 
                ...options, 
                signal: controller.signal 
            });
            clearTimeout(timeoutId);

            if (response.status === 403 || response.status === 429) throw new Error(`Proxy Rate Limited (${response.status})`);
            if (!response.ok && response.status >= 500) throw new Error(`Proxy Server Error (${response.status})`);
            return response;
        } catch (e: any) {
            lastError = e;
        }
    }
    throw lastError || new Error('All proxies failed');
}

function pushPrice(price: number) {
    priceHistory.push(price);
    if (priceHistory.length > 100) priceHistory.shift();
}

function calculateRSI(prices: number[]): number {
  if (prices.length < RSI_PERIOD + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = prices.length - RSI_PERIOD; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff >= 0) gains += diff; else losses -= diff;
  }
  if (losses === 0) return 100;
  const rs = gains / losses;
  return 100 - (100 / (1 + rs));
}

function calculateStochRSI(rsis: number[]) {
    if (rsis.length < 14) return { k: 50, d: 50 };
    const periodRSIs = rsis.slice(-14);
    const minRSI = Math.min(...periodRSIs);
    const maxRSI = Math.max(...periodRSIs);
    let stoch = 50;
    if (maxRSI - minRSI !== 0) stoch = ((periodRSIs[periodRSIs.length - 1] - minRSI) / (maxRSI - minRSI)) * 100;
    return { k: stoch, d: stoch * 0.9 + 5 }; 
}

function calculateBollingerBands(prices: number[]) {
    if (prices.length < BB_PERIOD) return { upper: 0, middle: 0, lower: 0, position: 0.5 };
    const slice = prices.slice(-BB_PERIOD);
    const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
    const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / slice.length;
    const stdDev = Math.sqrt(variance);
    const upper = mean + (BB_MULTIPLIER * stdDev);
    const lower = mean - (BB_MULTIPLIER * stdDev);
    const current = prices[prices.length - 1];
    let position = 0.5;
    if (upper - lower !== 0) position = (current - lower) / (upper - lower);
    return { upper, middle: mean, lower, position };
}

function calculateEMA(prices: number[], period: number): number {
    if (prices.length < period) return prices[prices.length - 1];
    const k = 2 / (period + 1);
    let ema = prices[0];
    for (let i = 1; i < prices.length; i++) {
        ema = (prices[i] * k) + (ema * (1 - k));
    }
    return ema;
}

function calculateStandardDeviation(prices: number[]): number {
    if (prices.length < 5) return 0;
    const mean = prices.reduce((a, b) => a + b, 0) / prices.length;
    const variance = prices.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / prices.length;
    return Math.sqrt(variance);
}

function calculateDivergence(prices: number[], rsis: number[]): number {
    if (prices.length < 10 || rsis.length < 10) return 0;
    const priceCurr = prices[prices.length - 1];
    const pricePrev = prices[prices.length - 6]; 
    const rsiCurr = rsis[rsis.length - 1];
    const rsiPrev = rsis[rsis.length - 6];
    if (priceCurr < pricePrev && rsiCurr > rsiPrev + 2) return 1;
    if (priceCurr > pricePrev && rsiCurr < rsiPrev - 2) return -1;
    return 0;
}

function detectMarketRegime(volatility: number, trendStrength: number): 'RANGING' | 'TRENDING' | 'VOLATILE' {
    if (volatility > 2.0) return 'VOLATILE';
    if (Math.abs(trendStrength) > 1.0) return 'TRENDING';
    return 'RANGING';
}

function formatVirtual(value: number): string {
    return `$${(value * SCALING_FACTOR).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function addLog(msg: string, type: LogEntry['type']) {
  const entry: LogEntry = {
    id: Date.now() + Math.random(),
    timestamp: new Date().toLocaleTimeString(),
    message: msg,
    type: type
  };
  currentState.logs = [entry, ...currentState.logs].slice(0, 100);
}

function saveSession() {
    try {
        const sessionData = {
            timestamp: Date.now(),
            wallet: currentState.wallet,
            activePosition: currentState.activePosition,
            efficiencyIndex: currentState.wallet.efficiencyIndex,
            consecutiveWins, consecutiveLosses, grossWins, grossLosses,
            patternMemory, MIN_ROIE_PCT, pnlVelocity, lastTradeTime
        };
        localStorage.setItem('hitbtc_bot_session_v4', JSON.stringify(sessionData));
    } catch(e) {}
}

function restoreSession() {
    try {
        const raw = localStorage.getItem('hitbtc_bot_session_v4');
        if (raw) {
            const data = JSON.parse(raw);
            if (Date.now() - data.timestamp < 48 * 60 * 60 * 1000) {
                currentState.wallet = { ...currentState.wallet, ...data.wallet };
                currentState.wallet.efficiencyIndex = data.efficiencyIndex || 90;
                consecutiveWins = data.consecutiveWins || 0;
                consecutiveLosses = data.consecutiveLosses || 0;
                grossWins = data.grossWins || 0;
                grossLosses = data.grossLosses || 0;
                patternMemory = data.patternMemory || [];
                MIN_ROIE_PCT = data.MIN_ROIE_PCT || 0.0015;
                pnlVelocity = data.pnlVelocity || [];
                lastTradeTime = data.lastTradeTime || Date.now();
                if(data.activePosition) currentState.activePosition = data.activePosition; 
                addLog(`[SESSION] Restored. Memory: ${patternMemory.length} patterns.`, 'SUCCESS');
            }
        }
    } catch(e) {}
}

// v4.4 Pattern Matching with Imbalance
function matchPattern(current: TradePattern): number {
    if (patternMemory.length === 0) return 0;
    let bestMatchScore = -999;
    for(const mem of patternMemory) {
        const distRsi = Math.abs(current.rsi - mem.rsi);
        const distTrend = Math.abs(current.trendStrength - mem.trendStrength);
        const distVol = Math.abs(current.volatility - mem.volatility);
        const distImb = Math.abs(current.imbalance - mem.imbalance); 
        const similarity = 100 - (distRsi + (distTrend * 10) + (distVol * 10) + (distImb * 20)); 
        if (similarity > 70) { 
            if (mem.result === 'WIN') bestMatchScore = Math.max(bestMatchScore, 1); 
            if (mem.result === 'LOSS') bestMatchScore = Math.max(bestMatchScore, -1); 
        }
    }
    return bestMatchScore === -999 ? 0 : bestMatchScore;
}

function predictWalletExhaustion(currentSize: number, price: number, availableMargin: number): boolean {
    if (currentSize <= MIN_QTY + 0.0001) return false;
    let futureUsed = 0;
    let nextSize = currentSize;
    const steps = availableMargin < 1 ? 1 : 3;
    for(let i = 0; i < steps; i++) {
        nextSize = nextSize * 1.5; 
        const stepCost = (nextSize * price) / LEVERAGE;
        futureUsed += stepCost;
    }
    return futureUsed > (availableMargin * 1.1);
}

// v4.7 PREDICTIVE SIZING & PNL STABILITY
function calculateSmartEntrySize(wallet: BotState['wallet'], marketPrice: number, patternMatchScore: number, predictedPnL: number): number {
    let base = MIN_QTY;
    
    // Efficiency Bonus
    if (wallet.efficiencyIndex > 85) base += MIN_QTY; 
    if (wallet.efficiencyIndex > 95) base += MIN_QTY;
    
    // v4.7 PnL Stability Check
    const pnlVariance = calculateStandardDeviation(pnlVarianceHistory);
    if (pnlVariance > 0.0005) {
        base = MIN_QTY; // Reduce size if PnL is volatile (Keep "Projected PnL at low value")
    } else if (predictedPnL > 1000 && pnlVariance < 0.0001) {
        base *= 1.5; // Boost size if prediction is high and variance is low (Stable Growth)
    }

    // Streak Bonus
    if (consecutiveWins > 1) base += MIN_QTY; 
    
    // Pattern Bonus (v4.4)
    if (patternMatchScore > 0) {
        base *= 1.2; 
        base = Math.ceil(base * 1000) / 1000;
    }

    // Profit Risking
    if (wallet.totalProfit > 0) {
        const profitRiskAmount = wallet.totalProfit * 0.15; 
        const extraQty = profitRiskAmount / (marketPrice / LEVERAGE); 
        base += extraQty;
    }
    base = Math.min(base, MIN_QTY * 20); 
    
    // Penalties
    if (consecutiveLosses > 1 || wallet.efficiencyIndex < 60) base = MIN_QTY;
    
    const maxAllowedMarginUsage = (wallet.balance * MAX_WALLET_USAGE_PCT);
    const availableForNewTrade = maxAllowedMarginUsage - wallet.usedMargin;
    let maxSafeQty = 0;
    if (availableForNewTrade > 0) {
        maxSafeQty = (availableForNewTrade * LEVERAGE) / marketPrice;
    }
    const physicalMaxQty = (wallet.freeMargin * 0.99 * LEVERAGE) / marketPrice;
    let finalSize = Math.min(base, maxSafeQty, physicalMaxQty);
    finalSize = Math.floor(finalSize * 1000) / 1000;
    return finalSize;
}

async function initCCXT() {
  try {
    // @ts-ignore
    if (window.ccxt && window.ccxt.hitbtc) {
      // @ts-ignore
      ccxtExchange = new window.ccxt.hitbtc({
        apiKey: API_KEY,
        secret: API_SECRET,
        enableRateLimit: true,
        options: { defaultType: 'swap' } 
      });
      try {
         const markets = await ccxtExchange.loadMarkets();
         const market = Object.values(markets).find((m: any) => m.id === SYMBOL);
         if (market) {
             // @ts-ignore
             CCXT_SYMBOL = market.symbol;
             addLog(`Mapped ${SYMBOL} to CCXT: ${CCXT_SYMBOL}`, 'INFO');
         }
      } catch(e) {}
      addLog('CCXT HitBTC instance initialized.', 'INFO');
      useRealTrading = true;
    } else {
      addLog('CCXT library not found. Using simulation.', 'WARNING');
    }
  } catch (e: any) {
    addLog(`Failed to init CCXT: ${e.message}`, 'ERROR');
  }
}

async function executeRealOrder(side: 'buy' | 'sell', amount: number, price?: number, orderSymbol: string = SYMBOL) {
    const scaledAmount = formatVirtual(amount * (price || 2.7)); 
    addLog(`HitBTC Order: ${side.toUpperCase()} ${amount.toFixed(3)} ATOM (Est Value: ${scaledAmount})`, 'WARNING');
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const body = new URLSearchParams();
        body.append('symbol', orderSymbol); 
        body.append('side', side);
        body.append('quantity', amount.toFixed(3)); 
        body.append('type', 'market');
        body.append('margin_mode', 'cross');
        
        const targetUrl = "https://api.hitbtc.com/api/3/futures/order";
        const response = await fetchWithRotation(targetUrl, {
            method: 'POST',
            headers: {
                'Authorization': `Basic ${auth}`,
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: body
        }, 'POST');

        if (response.ok) {
             const data = await response.json();
             addLog(`REAL ORDER SUCCESS: ID ${data.id || 'UNKNOWN'}`, 'SUCCESS');
             return data;
        } else {
            const text = await response.text();
            addLog(`API REJECT: ${text.substring(0, 120)}`, 'ERROR');
            throw new Error(`API Status ${response.status}: ${text.substring(0, 100)}`);
        }
    } catch (error: any) {
        addLog(`Order Failed (Network/Auth): ${error.message}. Switching to Paper Trade.`, 'ERROR');
        return { avgPrice: price, quantity: amount, side: side, simulated: true }; 
    }
}

async function closeAllPositionsOnStart() {
    if (!useRealTrading) return;
    addLog('Checking for existing positions to manage...', 'INFO');
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const targetUrl = "https://api.hitbtc.com/api/3/futures/position";
        const response = await fetchWithRotation(targetUrl, { headers: { 'Authorization': `Basic ${auth}` } }, 'GET');

        if (response.ok) {
            const data = await response.json();
            if (Array.isArray(data)) {
                let found = false;
                for (const pos of data) {
                    if (pos.symbol === SYMBOL) {
                        const size = parseFloat(pos.quantity);
                        const pnl = parseFloat(pos.pnl || 0);
                        const entry = parseFloat(pos.price_entry || pos.price || 0);

                        if (size !== 0) {
                            found = true;
                            const estimatedValue = Math.abs(size) * entry;
                            const roundTripFee = estimatedValue * TAKER_FEE_RATE * 2;
                            const netPnL = pnl - roundTripFee;

                            if (netPnL > 0) {
                                const closeSide = size > 0 ? 'sell' : 'buy';
                                const absSize = Math.abs(size);
                                addLog(`Closing existing ${pos.symbol} (${size}) in REAL PROFIT. Starting fresh.`, 'SUCCESS');
                                await executeRealOrder(closeSide, absSize, undefined, pos.symbol);
                            } else {
                                addLog(`Adopting existing ${pos.symbol} position (${size}). PnL not in profit. Attempting recovery.`, 'WARNING');
                                currentState.activePosition = {
                                    id: `ADOPTED-${Date.now()}`,
                                    symbol: SYMBOL,
                                    direction: size > 0 ? Direction.LONG : Direction.SHORT,
                                    entryPrice: entry,
                                    size: Math.abs(size),
                                    unrealizedPnL: pnl,
                                    highestPnL: pnl, 
                                    targetPnL: Math.abs(size) * entry * MIN_ROIE_PCT,
                                    leverage: LEVERAGE,
                                    timestamp: Date.now()
                                };
                                const marginUsed = (Math.abs(size) * entry) / LEVERAGE;
                                currentState.wallet.usedMargin += marginUsed;
                                currentState.wallet.freeMargin -= marginUsed;
                            }
                        }
                    }
                }
                if (!found) addLog('No open positions found on startup.', 'SUCCESS');
            }
        }
    } catch (e: any) {
        addLog(`Failed to sync/close positions: ${e.message}`, 'ERROR');
    }
}

async function syncWallet() {
    if (!useRealTrading) return;
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const targetUrl = "https://api.hitbtc.com/api/3/futures/balance";
        const response = await fetchWithRotation(targetUrl, { headers: { 'Authorization': `Basic ${auth}` } }, 'GET');

        if (response.ok) {
            const data = await response.json();
            let usdtAcc = null;
            if (Array.isArray(data)) usdtAcc = data.find((a: any) => a.currency === 'USDT');
            if (usdtAcc) {
                const rawBalance = usdtAcc.cross_margin_reserved || usdtAcc.reserved_margin || '0';
                const realWalletBalance = parseFloat(rawBalance);
                const apiAvailable = parseFloat(usdtAcc.available || '0');
                const calculatedFree = (apiAvailable === 0 && realWalletBalance > 0) ? realWalletBalance : apiAvailable;
                
                currentState.wallet.balance = realWalletBalance; 
                currentState.wallet.freeMargin = calculatedFree;
                let used = realWalletBalance - calculatedFree;
                if (used < 0) used = 0;
                currentState.wallet.usedMargin = used; 
                
                currentState.wallet.virtualBalance = realWalletBalance * SCALING_FACTOR;
                currentState.wallet.virtualEquity = (realWalletBalance + (currentState.activePosition?.unrealizedPnL || 0)) * SCALING_FACTOR;
                currentState.wallet.virtualTotalProfit = currentState.wallet.totalProfit * SCALING_FACTOR;

                if (currentState.wallet.startBalance <= 0 && realWalletBalance > 0) currentState.wallet.startBalance = realWalletBalance;
                if (realWalletBalance <= 0.0001 && realWalletBalance === 0) {
                    currentState.wallet.balance = 50.00;
                    currentState.wallet.virtualBalance = 50.00 * SCALING_FACTOR; 
                    currentState.wallet.freeMargin = 50.00 - currentState.wallet.usedMargin;
                }
            }
        }
    } catch (e) {}
}

async function syncRealPosition() {
    if (!useRealTrading) return;
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const targetUrl = "https://api.hitbtc.com/api/3/futures/account";
        const response = await fetchWithRotation(targetUrl, { headers: { 'Authorization': `Basic ${auth}` } }, 'GET');

        if (response.ok) {
            const data = await response.json();
            let posData = null;
            if (data.positions && Array.isArray(data.positions)) posData = data.positions.find((p: any) => p.symbol === SYMBOL);
            else if (Array.isArray(data)) {
                 for (const acc of data) {
                     if (acc.positions && Array.isArray(acc.positions)) {
                         const found = acc.positions.find((p: any) => p.symbol === SYMBOL);
                         if (found) { posData = found; break; }
                     }
                 }
            }
            if (!posData && currentState.activePosition && currentState.activePosition.id.startsWith('REAL')) {
                 addLog(`[OFFLINE SYNC] Position detected closed on exchange. Updating PnL.`, 'WARNING');
                 currentState.activePosition = null;
            }
            if (posData) {
                 const rawEntryPrice = posData.price_entry || posData.price;
                 const size = parseFloat(posData.quantity || posData.size || 0);
                 if (size !== 0 && rawEntryPrice) {
                     const realEntryPrice = parseFloat(rawEntryPrice); 
                     const pnl = parseFloat(posData.pnl || 0);
                     let previousHighest = pnl;
                     const baseTarget = Math.abs(size) * realEntryPrice * MIN_ROIE_PCT;
                     let preservedTarget = baseTarget;
                     if (currentState.activePosition && currentState.activePosition.symbol === SYMBOL) {
                         previousHighest = Math.max(currentState.activePosition.highestPnL || -999, pnl);
                         preservedTarget = currentState.activePosition.targetPnL || baseTarget;
                     }
                     currentState.activePosition = {
                         id: `REAL-POS-${SYMBOL}`, 
                         symbol: SYMBOL,
                         direction: size > 0 ? Direction.LONG : Direction.SHORT,
                         entryPrice: realEntryPrice,
                         size: Math.abs(size),
                         unrealizedPnL: pnl,
                         highestPnL: previousHighest,
                         targetPnL: preservedTarget,
                         leverage: LEVERAGE, 
                         timestamp: currentState.activePosition?.timestamp || Date.now()
                     };
                 } else {
                     if (currentState.activePosition && currentState.activePosition.id.startsWith('REAL')) {
                         currentState.activePosition = null;
                         addLog('Position closed on exchange', 'INFO');
                     }
                 }
            }
        }
    } catch (e) {}
}

async function updateMarketData() {
  let success = false;
  if (ccxtExchange) {
      try {
          const ticker = await ccxtExchange.fetchTicker(CCXT_SYMBOL); 
          if (ticker && ticker.bid && ticker.ask) {
              currentState.market = {
                  symbol: DISPLAY_SYMBOL,
                  bid: ticker.bid,
                  ask: ticker.ask,
                  mid: (ticker.bid + ticker.ask) / 2,
                  timestamp: Date.now()
              };
              pushPrice(currentState.market.mid);
              success = true;
          }
      } catch (e) { }
  }
  if (!success) {
      try {
        const targetUrl = `https://api.hitbtc.com/api/3/public/ticker/${SYMBOL}`;
        const response = await fetchWithRotation(targetUrl, {}, 'GET');
        if (response.ok) {
             const data = await response.json();
             if (data && (data.ask || data.last)) {
                const bid = parseFloat(data.bid || data.last);
                const ask = parseFloat(data.ask || data.last);
                currentState.market = {
                    symbol: DISPLAY_SYMBOL,
                    bid: bid,
                    ask: ask,
                    mid: (bid + ask) / 2,
                    timestamp: Date.now()
                };
                pushPrice(currentState.market.mid);
                success = true;
            }
        }
      } catch (e) { }
  }
  // Micro-Tick Simulation
  if (!success) {
    const prevMid = currentState.market.mid || 2.74; 
    const volatility = prevMid * 0.0002; 
    const change = (Math.random() - 0.5) * volatility;
    let newMid = prevMid + change;
    newMid = Math.max(0.1, newMid);
    const spread = newMid * 0.0005; 
    currentState.market = {
        symbol: DISPLAY_SYMBOL,
        mid: newMid,
        bid: newMid - (spread / 2),
        ask: newMid + (spread / 2),
        timestamp: Date.now()
    };
    pushPrice(newMid);
  }
  
  const ema = calculateEMA(priceHistory, EMA_PERIOD);
  const mid = currentState.market.mid;
  // SAFETY: Prevent division by zero if EMA is 0
  const trendStrength = ema !== 0 ? ((mid - ema) / ema) * 1000 : 0;
  const divergence = ema !== 0 ? (mid - ema) / ema : 0;
  currentState.signal.features.imbalance = Math.max(-1, Math.min(1, divergence * 500));
}

async function runAIStrategy() {
    if (!currentState.isRunning) return;
    const { market, activePosition, wallet } = currentState;
    
    currentState.signal.memorySize = patternMemory.length;
    
    if (wallet.startBalance > 0) currentState.wallet.growthPercentage = ((wallet.balance - wallet.startBalance) / wallet.startBalance) * 100;
    
    // PROFIT FACTOR & STATS
    if (wallet.totalProfit > lastTotalProfit) {
        const gain = wallet.totalProfit - lastTotalProfit;
        grossWins += gain;
        const boost = gain >= 0.00001 ? 5.0 : 1.0; 
        currentState.wallet.efficiencyIndex = Math.min(100, currentState.wallet.efficiencyIndex + boost); 
        consecutiveWins++;
        consecutiveLosses = 0;
        
        pnlVelocity.unshift(gain);
        if (pnlVelocity.length > 5) pnlVelocity.pop();
        
        // v4.7 PnL Stability: Track variance of wins
        pnlVarianceHistory.push(gain);
        if (pnlVarianceHistory.length > 10) pnlVarianceHistory.shift();

        if (lastTradeCondition) {
             if (patternMemory.length > 50) patternMemory.shift();
             lastTradeCondition.result = 'WIN';
             patternMemory.push(lastTradeCondition);
             lastTradeCondition = null;
             addLog(`[LEARNING] Stored Winning Pattern. Memory: ${patternMemory.length}`, 'SUCCESS');
        }

        if (consecutiveWins > 3) {
             MIN_ROIE_PCT = Math.min(0.0030, MIN_ROIE_PCT * 1.05); 
             addLog(`[ADAPT] Increasing ROI Targets to ${(MIN_ROIE_PCT*100).toFixed(3)}%`, 'SUCCESS');
        }

        if (consecutiveWins % 3 === 0) addLog(`[STREAK] ${consecutiveWins} Wins! Efficiency Boosted.`, 'SUCCESS');
        lastTotalProfit = wallet.totalProfit;
    } else if (wallet.totalProfit < lastTotalProfit) {
        const loss = lastTotalProfit - wallet.totalProfit;
        grossLosses += loss;
        currentState.wallet.efficiencyIndex = Math.max(40, currentState.wallet.efficiencyIndex - 2.5);
        consecutiveLosses++;
        consecutiveWins = 0;
        
        pnlVelocity.unshift(-loss);
        if (pnlVelocity.length > 5) pnlVelocity.pop();
        
        // v4.7 PnL Stability: Track variance
        pnlVarianceHistory.push(loss); 
        if (pnlVarianceHistory.length > 10) pnlVarianceHistory.shift();

        if (lastTradeCondition) {
             if (patternMemory.length > 50) patternMemory.shift();
             lastTradeCondition.result = 'LOSS';
             patternMemory.push(lastTradeCondition);
             lastTradeCondition = null;
        }
        
        if (consecutiveLosses >= 1) {
             MIN_ROIE_PCT = Math.max(0.0010, MIN_ROIE_PCT * 0.95); 
             addLog(`[ADAPT] Lowering ROI Targets to ${(MIN_ROIE_PCT*100).toFixed(3)}%`, 'WARNING');
        }

        if (consecutiveLosses >= 2) addLog(`[DRAWDOWN] ${consecutiveLosses} Consecutive Losses. Defensive Mode.`, 'WARNING');
        lastTotalProfit = wallet.totalProfit;
    }
    
    if (grossLosses > 0) currentState.wallet.profitFactor = grossWins / grossLosses;
    else currentState.wallet.profitFactor = grossWins > 0 ? 999 : 0;

    const avgVelocity = pnlVelocity.length > 0 ? pnlVelocity.reduce((a,b) => a+b, 0) / pnlVelocity.length : 0;

    let theoreticalUsedMargin = 0;
    if (activePosition) {
        theoreticalUsedMargin = (activePosition.entryPrice * activePosition.size) / LEVERAGE;
        if (wallet.usedMargin < theoreticalUsedMargin) {
            wallet.usedMargin = theoreticalUsedMargin;
            wallet.freeMargin = wallet.balance - theoreticalUsedMargin;
        }
    }
    const walletUsageRatio = wallet.usedMargin / (wallet.balance || 0.000001);

    // --- INDICATOR CALCULATIONS ---
    const currentRSI = calculateRSI(priceHistory);
    rsiHistory.push(currentRSI);
    if (rsiHistory.length > 50) rsiHistory.shift();

    const { k: stochK, d: stochD } = calculateStochRSI(rsiHistory);
    const { upper: bbUpper, lower: bbLower, position: bbPosition } = calculateBollingerBands(priceHistory);
    const currentEMA = calculateEMA(priceHistory, EMA_PERIOD);
    const stdDev = calculateStandardDeviation(priceHistory.slice(-20));
    const volatility = (stdDev / market.mid) * 1000; 
    // EMA SAFETY CHECK
    const trendStrength = currentEMA !== 0 ? ((market.mid - currentEMA) / currentEMA) * 1000 : 0;
    const imbalance = currentState.signal.features.imbalance;
    const divergence = calculateDivergence(priceHistory, rsiHistory);
    const marketRegime = detectMarketRegime(volatility, trendStrength);
    currentState.signal.marketRegime = marketRegime;

    currentState.signal.features = {
        rsi: parseFloat(currentRSI.toFixed(2)),
        stochK: parseFloat(stochK.toFixed(1)),
        stochD: parseFloat(stochD.toFixed(1)),
        bbPosition: parseFloat(bbPosition.toFixed(2)),
        volatility: parseFloat(volatility.toFixed(4)),
        trendStrength: parseFloat(trendStrength.toFixed(2)),
        imbalance: parseFloat(imbalance.toFixed(2)),
        divergence: divergence
    };

    let signalDirection = Direction.NEUTRAL;
    let rawConfidence = 0;
    const isOversold = stochK < 20 && currentRSI < 40;
    const isOverbought = stochK > 80 && currentRSI > 60;
    const atLowerBand = bbPosition <= 0.1; 
    const atUpperBand = bbPosition >= 0.9; 

    if (marketRegime === 'RANGING') {
        if (atLowerBand && isOversold) { signalDirection = Direction.LONG; rawConfidence = 80; } 
        else if (atUpperBand && isOverbought) { signalDirection = Direction.SHORT; rawConfidence = 80; }
    } else if (marketRegime === 'TRENDING') {
        if (trendStrength > 0.5 && stochK < 60) { signalDirection = Direction.LONG; rawConfidence = 75; } 
        else if (trendStrength < -0.5 && stochK > 40) { signalDirection = Direction.SHORT; rawConfidence = 75; }
        if (atLowerBand && trendStrength < -1.0) rawConfidence -= 30; 
    } else {
        if (divergence === 1) { signalDirection = Direction.LONG; rawConfidence = 65; }
        if (divergence === -1) { signalDirection = Direction.SHORT; rawConfidence = 65; }
    }

    if (signalDirection === Direction.LONG) {
        if (imbalance > 0) rawConfidence += 10;
        if (divergence === 1) rawConfidence += 15;
    } else if (signalDirection === Direction.SHORT) {
        if (imbalance < 0) rawConfidence += 10;
        if (divergence === -1) rawConfidence += 15;
    }

    // v4.4 PATTERN RECOGNITION BOOST
    const currentPattern: TradePattern = { 
        rsi: currentRSI, volatility, trendStrength, imbalance, regime: marketRegime, result: 'WIN' 
    };
    const matchScore = matchPattern(currentPattern);
    if (matchScore === 1) rawConfidence += 15;
    else if (matchScore === -1) rawConfidence -= 30;

    // TREND FILTER (v4.5 Relaxed)
    if (signalDirection === Direction.LONG && market.mid < currentEMA && rawConfidence < 90) rawConfidence -= 10;
    if (signalDirection === Direction.SHORT && market.mid > currentEMA && rawConfidence < 90) rawConfidence -= 10;

    rawConfidence = Math.min(99.9, rawConfidence);
    const efficiencyMultiplier = currentState.wallet.efficiencyIndex / 100;
    const confidence = rawConfidence * efficiencyMultiplier;

    currentState.signal.direction = signalDirection;
    currentState.signal.confidence = parseFloat(confidence.toFixed(1));
    // v4.7 PREDICTED PNL
    currentState.signal.predictedPnL = (wallet.virtualBalance * 0.01 * (confidence / 100)); 
    currentState.simulationsRun++;
    currentState.priceHistory = [...priceHistory];

    // v4.5 IDLE BREAKER
    const idleTimeMinutes = (Date.now() - lastTradeTime) / 60000;
    let requiredConfidence = 55;
    if (idleTimeMinutes > 3) {
        const discount = Math.min(15, Math.floor(idleTimeMinutes - 3) * 2);
        requiredConfidence -= discount;
        if (idleTimeMinutes > 5 && Math.random() < 0.01) addLog(`[IDLE-BREAKER] Lowering Conf Threshold to ${requiredConfidence}%`, 'INFO');
    }

    if (!activePosition) {
        if (signalDirection !== Direction.NEUTRAL) {
             if (walletUsageRatio > MAX_WALLET_USAGE_PCT) {
                 if (Math.random() < 0.05) addLog(`[SKIP] Wallet usage > ${(MAX_WALLET_USAGE_PCT*100).toFixed(0)}%. Entry blocked.`, 'WARNING');
                 return;
             }
             if (confidence <= requiredConfidence) { } else {
                 if (wallet.freeMargin <= 0.00000001) {
                     if(Math.random() < 0.05) addLog(`[SKIP] Valid Signal but Zero Free Margin.`, 'WARNING');
                 } else {
                    // v4.7 SMART SIZING WITH PNL STABILITY
                    let calculatedSize = calculateSmartEntrySize(wallet, market.mid, matchScore, currentState.signal.predictedPnL);
                    
                    if (calculatedSize < MIN_QTY) return;
                    const estimatedPrice = signalDirection === Direction.LONG ? market.ask : market.bid;
                    const isRisky = predictWalletExhaustion(calculatedSize, estimatedPrice, wallet.freeMargin);
                    if (isRisky) calculatedSize = MIN_QTY; 
                    const actualCost = (estimatedPrice * calculatedSize) / LEVERAGE;

                    if (wallet.freeMargin >= actualCost) {
                        const side = signalDirection === Direction.LONG ? 'buy' : 'sell';
                        const divMsg = divergence !== 0 ? ` + Div(${divergence})` : '';
                        addLog(`[AI-ENTRY] ${signalDirection} ${calculatedSize} ATOM. Conf: ${confidence.toFixed(1)}%${divMsg}`, 'INFO');
                        const orderResult = await executeRealOrder(side, calculatedSize, estimatedPrice);
                        if (orderResult) {
                            const realEntry = (orderResult.avgPrice && parseFloat(orderResult.avgPrice) > 0) ? parseFloat(orderResult.avgPrice) : estimatedPrice;
                            const initialFee = (realEntry * calculatedSize) * TAKER_FEE_RATE * 2;
                            const baseTarget = (realEntry * calculatedSize) * MIN_ROIE_PCT;
                            const initialTarget = Math.max(initialFee * 3.0, baseTarget, MICRO_PROFIT_TARGET);
                            currentState.activePosition = {
                                id: `ORD-${Date.now().toString().slice(-6)}`,
                                symbol: DISPLAY_SYMBOL,
                                direction: signalDirection,
                                entryPrice: realEntry,
                                size: calculatedSize,
                                unrealizedPnL: 0,
                                highestPnL: 0,
                                targetPnL: initialTarget,
                                leverage: LEVERAGE, 
                                timestamp: Date.now()
                            };
                            lastTradeCondition = currentPattern; 
                            lastTradeTime = Date.now();
                            wallet.usedMargin += actualCost;
                            wallet.freeMargin -= actualCost;
                        }
                    }
                 }
             }
        }
    } else {
        lastTradeTime = Date.now();
        const price = market.mid;
        const entry = activePosition.entryPrice;
        let pnl = activePosition.direction === Direction.LONG ? (price - entry) * activePosition.size : (entry - price) * activePosition.size;
        
        activePosition.unrealizedPnL = pnl; 
        if (activePosition.unrealizedPnL > (activePosition.highestPnL || -9999)) activePosition.highestPnL = activePosition.unrealizedPnL;

        const positionValue = activePosition.size * price;
        const entryFeeEstimate = (activePosition.size * activePosition.entryPrice) * TAKER_FEE_RATE;
        const exitFeeEstimate = positionValue * TAKER_FEE_RATE;
        const roundTripFee = entryFeeEstimate + exitFeeEstimate;
        const netPnL = pnl - roundTripFee; 

        const roiTarget = (activePosition.size * activePosition.entryPrice) * MIN_ROIE_PCT;
        let dynamicProfitTarget = Math.max(roundTripFee * 3.0, roiTarget, MICRO_PROFIT_TARGET);
        
        // v4.4 VELOCITY ADJUSTMENT
        if (avgVelocity > 0.0005) dynamicProfitTarget *= 1.15; 
        else if (avgVelocity < 0) dynamicProfitTarget *= 0.9;
        
        let volMult = 1.0;
        if (volatility > 2.0) volMult = 2.0; 
        else if (volatility > 1.0) volMult = 1.5;
        else if (volatility < 0.5) volMult = 0.8; 
        dynamicProfitTarget *= volMult;

        const durationMins = (Date.now() - activePosition.timestamp) / 60000;
        if (durationMins > 3) {
            const decayFactor = Math.max(0.5, 1.0 - ((durationMins - 3) * 0.1)); 
            dynamicProfitTarget *= decayFactor;
        }
        activePosition.targetPnL = dynamicProfitTarget;

        // FEE FLOOR PROTECTION (2.8x)
        if (activePosition.highestPnL >= roundTripFee * 3.0) {
            if (pnl < roundTripFee * 2.8) { 
                 addLog(`[FEE-FLOOR] PnL dropped below 2.8x Fees. Closing.`, 'WARNING');
                 const side = activePosition.direction === Direction.LONG ? 'sell' : 'buy';
                 await executeRealOrder(side, activePosition.size, price);
                 wallet.totalProfit += netPnL; 
                 currentState.activePosition = null;
                 wallet.usedMargin = 0;
                 return;
            }
        }

        // Take Profit
        if (activePosition.unrealizedPnL > (dynamicProfitTarget * 1.10)) {
             addLog(`[FORCE-TARGET] Target exceeded by 10%. Locking in.`, 'SUCCESS');
             await executeRealOrder(activePosition.direction === Direction.LONG ? 'sell' : 'buy', activePosition.size, price);
             wallet.totalProfit += netPnL;
             currentState.activePosition = null;
             wallet.usedMargin = 0;
             return;
        }
        
        // Ratchet (90%)
        if (activePosition.highestPnL > dynamicProfitTarget * 0.95) {
            const lockedProfit = activePosition.highestPnL * 0.80; 
            const minimumSafe = roundTripFee * 2.0;
            if (activePosition.unrealizedPnL < Math.max(lockedProfit, minimumSafe)) {
                 addLog(`[RATCHET] Protecting Gains. Closing.`, 'WARNING');
                 await executeRealOrder(activePosition.direction === Direction.LONG ? 'sell' : 'buy', activePosition.size, price);
                 wallet.totalProfit += netPnL;
                 currentState.activePosition = null;
                 wallet.usedMargin = 0;
                 return;
            }
        }

        // Trailing Stop (20%)
        let trailingPct = 0.20; 
        if (volatility > 1.0) trailingPct = 0.10; 
        if (avgVelocity > 0.001) trailingPct = 0.30; 

        let baseTrailingGap = dynamicProfitTarget * trailingPct;
        if (activePosition.highestPnL > dynamicProfitTarget) {
             const drawdownFromPeak = activePosition.highestPnL - activePosition.unrealizedPnL;
             if (drawdownFromPeak > baseTrailingGap) {
                 addLog(`[TRAIL-STOP] Closing at peak drawdown.`, 'SUCCESS');
                 await executeRealOrder(activePosition.direction === Direction.LONG ? 'sell' : 'buy', activePosition.size, price);
                 wallet.totalProfit += netPnL;
                 currentState.wallet.efficiencyIndex = Math.min(100, currentState.wallet.efficiencyIndex + 2);
                 currentState.activePosition = null;
                 wallet.usedMargin = 0;
                 return;
             }
        }
        
        // Stalemate (PROFIT ONLY)
        const isStale = (Date.now() - activePosition.timestamp) > STALEMATE_THRESHOLD_MS;
        if (isStale && Math.abs(pnl) < (dynamicProfitTarget * 0.5) && activePosition.size > MIN_QTY) {
             if (netPnL > 0) {
                 addLog(`[STALEMATE] Forcing Break-Even exit (Profitable).`, 'WARNING');
                 await executeRealOrder(activePosition.direction === Direction.LONG ? 'sell' : 'buy', activePosition.size, price);
                 activePosition.size = 0; 
                 currentState.activePosition = null;
                 wallet.usedMargin = 0;
                 return;
             }
        }

        // De-Risking (High Usage/Drawdown)
        const highDrawdown = activePosition.unrealizedPnL < -0.0005; 
        // v4.8 SAFETY: Strict check for MIN_QTY
        if ((walletUsageRatio > MAX_WALLET_USAGE_PCT || highDrawdown) && activePosition.size > MIN_QTY * 2) {
             if (Math.random() < 0.05) { 
                 addLog(`[SMART-TRIM] De-Risking.`, 'WARNING');
                 currentState.wallet.efficiencyIndex = Math.min(100, currentState.wallet.efficiencyIndex + 0.5);
                 await executeRealOrder(activePosition.direction === Direction.LONG ? 'sell' : 'buy', MIN_QTY, price);
                 activePosition.size -= MIN_QTY;
                 wallet.usedMargin -= (activePosition.entryPrice * MIN_QTY / LEVERAGE);
                 
                 // v4.7.2 NET PNL FIX
                 const portionGrossPnL = (activePosition.unrealizedPnL / activePosition.size) * MIN_QTY;
                 const portionExitFee = (price * MIN_QTY * TAKER_FEE_RATE);
                 const portionEntryFee = (activePosition.entryPrice * MIN_QTY * TAKER_FEE_RATE);
                 const portionNetPnL = portionGrossPnL - (portionExitFee + portionEntryFee);
                 wallet.totalProfit += portionNetPnL;
             }
             return; 
        }
        
        // PnL CHURNING
        // v4.8 SAFETY: Strict check for size
        if (activePosition.size > MIN_QTY * 5 && walletUsageRatio > 0.40 && netPnL > MIN_QTY * price * 0.001) {
             if (Math.random() < 0.2) { 
                  addLog(`[CHURN] Banking Micro-Profit (Fees Covered).`, 'SUCCESS');
                  await executeRealOrder(activePosition.direction === Direction.LONG ? 'sell' : 'buy', MIN_QTY, price);
                  
                  const portionGrossPnL = (activePosition.unrealizedPnL / activePosition.size) * MIN_QTY;
                  const portionFees = (price * MIN_QTY * TAKER_FEE_RATE) + (activePosition.entryPrice * MIN_QTY * TAKER_FEE_RATE);
                  wallet.totalProfit += (portionGrossPnL - portionFees);
                  
                  activePosition.size -= MIN_QTY;
             }
        }

        // AGGRESSIVE SCALING
        if (activePosition && walletUsageRatio < MAX_WALLET_USAGE_PCT) {
             if (pnl > PYRAMID_THRESHOLD_PNL) {
                  const isTrendAligned = activePosition.direction === Direction.LONG ? trendStrength > 0.5 : trendStrength < -0.5;
                  if (isTrendAligned) {
                      addLog(`[PYRAMID] Adding to winner.`, 'TRADE');
                      await executeRealOrder(activePosition.direction === Direction.LONG ? 'buy' : 'sell', MIN_QTY, price);
                      activePosition.size += MIN_QTY;
                      wallet.usedMargin += (price * MIN_QTY / LEVERAGE);
                  }
             }
             const deviation = Math.abs((price - entry) / entry);
             if (deviation > BASE_GRID_DEVIATION && pnl < 0) {
                  const rsiSafe = activePosition.direction === Direction.LONG ? currentRSI < 40 : currentRSI > 60;
                  if (rsiSafe) {
                       addLog(`[GRID] Averaging down (0.1% dev).`, 'WARNING');
                       await executeRealOrder(activePosition.direction === Direction.LONG ? 'buy' : 'sell', MIN_QTY, price);
                       activePosition.size += MIN_QTY;
                       activePosition.entryPrice = ((activePosition.entryPrice * (activePosition.size - MIN_QTY)) + (price * MIN_QTY)) / activePosition.size;
                       wallet.usedMargin += (price * MIN_QTY / LEVERAGE);
                  }
             }
        }
    }
    saveSession();
}

export function startBotEngine() {
    if (timerWorker) { timerWorker.terminate(); timerWorker = null; }
    if (marketInterval) clearInterval(marketInterval);
    priceHistory = []; rsiHistory = []; lastTotalProfit = 0; consecutiveWins = 0; consecutiveLosses = 0;
    restoreSession(); 
    if (!currentState.wallet.balance) currentState = getFreshState();
    currentState.isRunning = true;
    initCCXT();
    closeAllPositionsOnStart();
    marketInterval = setInterval(() => { updateMarketData(); }, 200);
    const blob = new Blob([`
        let interval;
        self.onmessage = function(e) {
            if (e.data.action === 'start') {
                if (interval) clearInterval(interval);
                interval = setInterval(() => self.postMessage('tick'), 2000);
            } else if (e.data.action === 'stop') {
                if (interval) clearInterval(interval);
            }
        }
    `], { type: 'application/javascript' });
    timerWorker = new Worker(URL.createObjectURL(blob));
    timerWorker.onmessage = async () => {
        await syncWallet(); await syncRealPosition(); await runAIStrategy();
    };
    timerWorker.postMessage({ action: 'start' });
    setTimeout(() => { addLog("[AI-CORE] Bot v4.8 Loaded. Churning Safety & EMA Fixes Active.", "SUCCESS"); }, 3000);
}

export function stopBotEngine() {
    if (timerWorker) { timerWorker.postMessage({ action: 'stop' }); timerWorker.terminate(); timerWorker = null; }
    if (marketInterval) { clearInterval(marketInterval); marketInterval = null; }
    currentState.isRunning = false;
    addLog('Bot Engine Stopped.', 'WARNING');
}

export function toggleBot() {
    currentState.isRunning = !currentState.isRunning;
    addLog(currentState.isRunning ? 'Bot Resumed.' : 'Bot Paused by User.', 'INFO');
    return currentState.isRunning;
}

export function getUpdatedState(): BotState { return { ...currentState }; }
