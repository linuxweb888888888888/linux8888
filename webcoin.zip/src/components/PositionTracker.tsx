
import React, { useState, useEffect } from 'react';
import { Position, Direction } from '../types';
import { ArrowUpCircle, ArrowDownCircle, Activity, AlertCircle, TrendingUp, Clock, Target, DollarSign, Scale, Lock } from 'lucide-react';

interface PositionTrackerProps {
  position: Position | null;
  currentPrice: number;
}

const SCALING_FACTOR = 100_000_000;

const PositionTracker: React.FC<PositionTrackerProps> = ({ position, currentPrice }) => {
  const [elapsed, setElapsed] = useState<string>('00:00');
  const [rtPnL, setRtPnL] = useState<number>(0);

  useEffect(() => {
    if (!position) return;
    const interval = setInterval(() => {
        const diff = Math.floor((Date.now() - position.timestamp) / 1000);
        const mins = Math.floor(diff / 60).toString().padStart(2, '0');
        const secs = (diff % 60).toString().padStart(2, '0');
        setElapsed(`${mins}:${secs}`);
    }, 1000);
    return () => clearInterval(interval);
  }, [position]);

  useEffect(() => {
      if (!position) { setRtPnL(0); return; }
      let calculatedPnL = 0;
      if (position.direction === Direction.LONG) {
          calculatedPnL = (currentPrice - position.entryPrice) * position.size;
      } else {
          calculatedPnL = (position.entryPrice - currentPrice) * position.size;
      }
      setRtPnL(calculatedPnL);
  }, [currentPrice, position]);

  if (!position) {
    return (
      <div className="bg-slate-800 rounded-lg p-6 text-center border border-slate-700 border-dashed h-full flex flex-col justify-center items-center">
        <div className="bg-slate-900 p-4 rounded-full mb-3">
          <Activity className="w-8 h-8 text-slate-600" />
        </div>
        <h3 className="text-slate-300 font-medium">No Active Positions</h3>
        <p className="text-slate-500 text-sm mt-2">AI is scanning for high-value signals...</p>
        <div className="mt-4 flex gap-2">
            <span className="text-xs bg-slate-700 text-slate-400 px-2 py-1 rounded">Scanning Bid: {currentPrice.toFixed(5)}</span>
        </div>
      </div>
    );
  }

  const isProfit = rtPnL >= 0;
  const pnlColor = isProfit ? 'text-emerald-400' : 'text-rose-400';
  const pnlBg = isProfit ? 'bg-emerald-500/10' : 'bg-rose-500/10';
  const isLong = position.direction === Direction.LONG;
  
  const virtualPnL = rtPnL * SCALING_FACTOR;
  const highestVirtualPnL = (position.highestPnL || 0) * SCALING_FACTOR;
  
  const targetPnL = position.targetPnL || 0.00012;
  const virtualTargetPnL = targetPnL * SCALING_FACTOR;
  
  // Progress Calculation
  const progressPercent = Math.min(100, Math.max(0, (rtPnL / targetPnL) * 100));
  const realDistanceToTarget = Math.max(0, targetPnL - rtPnL);

  const fmtVirtual = (val: number) => `$${Math.abs(val).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  // Margin Calculation
  const positionMargin = (position.size * position.entryPrice) / position.leverage;

  return (
    <div className="bg-slate-800 rounded-lg border border-slate-700 overflow-hidden">
      <div className="bg-slate-900/50 px-4 py-3 border-b border-slate-700 flex justify-between items-center">
        <div className="flex items-center gap-2">
          {isLong ? (
            <ArrowUpCircle className="w-5 h-5 text-emerald-400" />
          ) : (
            <ArrowDownCircle className="w-5 h-5 text-rose-400" />
          )}
          <span className={`font-bold ${isLong ? 'text-emerald-400' : 'text-rose-400'}`}>
            {position.direction} {position.symbol}
          </span>
          <span className="text-xs bg-blue-900/30 text-blue-300 px-2 py-0.5 rounded border border-blue-800">
            {position.leverage}x Cross
          </span>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
            <Clock className="w-3 h-3" /> {elapsed}
        </div>
      </div>

      {/* EXPANDED GRID TO SHOW SIZE AND MARGIN */}
      <div className="p-5 grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        <div>
          <p className="text-slate-500 text-[10px] uppercase tracking-wider mb-1 flex items-center gap-1">
            <Target className="w-3 h-3" /> Entry Price
          </p>
          <p className="text-lg font-mono text-white">{position.entryPrice.toFixed(5)}</p>
        </div>
        <div>
          <p className="text-slate-500 text-[10px] uppercase tracking-wider mb-1 flex items-center gap-1">
             <Activity className="w-3 h-3" /> Mark Price
          </p>
          <p className="text-lg font-mono text-blue-200">{currentPrice.toFixed(5)}</p>
        </div>
        <div>
          <p className="text-slate-500 text-[10px] uppercase tracking-wider mb-1 flex items-center gap-1">
             <Scale className="w-3 h-3" /> Size (ATOM)
          </p>
          <p className="text-lg font-mono text-indigo-200">{position.size.toFixed(3)}</p>
        </div>
        <div>
          <p className="text-slate-500 text-[10px] uppercase tracking-wider mb-1 flex items-center gap-1">
             <Lock className="w-3 h-3" /> Margin Used
          </p>
          <p className="text-lg font-mono text-amber-200">{positionMargin.toFixed(5)}</p>
        </div>
      </div>

      {/* --- BAR 1: VIRTUAL TARGET --- */}
      <div className="px-5 pb-2 pt-0">
         <div className="flex justify-between items-end mb-1">
            <span className="text-xs text-slate-400 flex items-center gap-1">
                <Target className="w-3 h-3" /> TP Target (Virtual)
            </span>
            <span className="text-xs font-mono text-slate-300">
               {progressPercent.toFixed(0)}% ({isProfit ? '+' : ''}{fmtVirtual(virtualPnL)})
            </span>
         </div>
         <div className="h-2 bg-slate-700 rounded-full overflow-hidden relative">
             <div className="absolute top-0 bottom-0 w-0.5 bg-slate-500/50 left-0"></div>
             <div 
                className={`h-full transition-all duration-500 ease-out ${
                    progressPercent >= 100 ? 'bg-emerald-400 animate-pulse' : 'bg-blue-500'
                }`}
                style={{ width: `${progressPercent}%` }}
             ></div>
         </div>
      </div>

      {/* --- BAR 2: REAL REALIZED PNL (HIGHLIGHTED) --- */}
      <div className="px-5 pb-5 pt-4 mt-2 border-t border-slate-700 bg-slate-900/30">
         <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 flex items-center gap-1">
               <DollarSign className="w-3 h-3 text-indigo-400" /> Real USDT Progress
            </span>
            <span className="text-[10px] font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                Target: {targetPnL.toFixed(6)}
            </span>
         </div>
         
         {/* Thicker Bar for Visibility */}
         <div className="relative h-6 bg-slate-800 rounded border border-slate-600/50 overflow-hidden">
            {/* Zero Line */}
            <div className="absolute left-0 top-0 bottom-0 w-px bg-white/20 z-20"></div>
            
            {/* Progress Fill */}
            <div 
               className={`h-full transition-all duration-200 ${isProfit ? 'bg-emerald-600/80' : 'bg-rose-600/80'}`}
               style={{ width: `${progressPercent}%` }}
            ></div>
            
            {/* Center Text Overlay (Always Visible) */}
            <div className="absolute inset-0 flex items-center justify-between px-3 z-30">
                <span className="text-[10px] font-mono text-white drop-shadow-md font-bold">
                   {rtPnL > 0 ? '+' : ''}{rtPnL.toFixed(7)} USDT
                </span>
                <span className="text-[9px] font-mono text-slate-300 drop-shadow-md">
                   {realDistanceToTarget.toFixed(7)} Left
                </span>
            </div>
         </div>
      </div>

      <div className={`px-5 py-4 border-t border-slate-700 ${pnlBg} flex justify-between items-center`}>
        <div>
          <p className="text-slate-400 text-xs uppercase">Projected PnL (Virtual)</p>
          <div className="flex flex-col">
              <span className={`text-2xl font-bold ${pnlColor} tracking-tight`}>
                {rtPnL > 0 ? '+' : '-'}{fmtVirtual(virtualPnL)}
              </span>
          </div>
        </div>
        
        <div className="flex flex-col items-end">
            <div className="text-xs text-slate-500 uppercase mb-1 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" /> Peak Profit
            </div>
            <span className="text-emerald-500/70 font-mono text-sm">
                +{fmtVirtual(highestVirtualPnL)}
            </span>
        </div>
      </div>
    </div>
  );
};

export default PositionTracker;