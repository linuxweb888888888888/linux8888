
import React from 'react';
import { Position, Direction } from '../types';

interface PriceChartProps {
  data: number[];
  activePosition: Position | null;
  height?: number;
  color?: string;
}

const PriceChart: React.FC<PriceChartProps> = ({ data, activePosition, height = 160, color = '#6366f1' }) => {
  if (!data || data.length < 2) {
    return (
      <div className="flex items-center justify-center bg-slate-900/50 rounded-lg border border-slate-800" style={{ height }}>
        <span className="text-slate-500 text-xs animate-pulse">Gathering Market Data...</span>
      </div>
    );
  }

  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 0.0001;
  const padding = range * 0.1; // 10% padding
  const plotMin = min - padding;
  const plotMax = max + padding;
  const plotRange = plotMax - plotMin;

  // SVG Coordinate Mapper
  const getX = (index: number) => (index / (data.length - 1)) * 100;
  const getY = (val: number) => 100 - ((val - plotMin) / plotRange) * 100;

  // Build Path
  const pathD = data.map((price, i) => {
    const x = getX(i);
    const y = getY(price);
    return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
  }).join(' ');

  // Build Area (Gradient fill under line)
  const areaD = `${pathD} L 100 100 L 0 100 Z`;

  // Entry Price Line
  let entryLineY = null;
  if (activePosition) {
      entryLineY = getY(activePosition.entryPrice);
      // Clamp to view
      entryLineY = Math.max(0, Math.min(100, entryLineY));
  }

  const currentPrice = data[data.length - 1];
  const isLong = activePosition?.direction === Direction.LONG;
  const lineColor = activePosition ? (isLong ? '#34d399' : '#fb7185') : color;

  return (
    <div className="w-full bg-slate-900/30 rounded-lg border border-slate-800 overflow-hidden relative" style={{ height }}>
       <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full">
           {/* Gradient Fill */}
           <defs>
               <linearGradient id="chartGradient" x1="0" x2="0" y1="0" y2="1">
                   <stop offset="0%" stopColor={lineColor} stopOpacity="0.2" />
                   <stop offset="100%" stopColor={lineColor} stopOpacity="0" />
               </linearGradient>
           </defs>
           
           {/* Area */}
           <path d={areaD} fill="url(#chartGradient)" stroke="none" />
           
           {/* Entry Price Line */}
           {activePosition && (
               <line x1="0" y1={entryLineY || 0} x2="100" y2={entryLineY || 0} stroke={isLong ? '#059669' : '#e11d48'} strokeWidth="0.5" strokeDasharray="2,2" opacity="0.8" />
           )}

           {/* Main Price Line */}
           <path d={pathD} fill="none" stroke={lineColor} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
           
           {/* Live Dot */}
           <circle cx="100" cy={getY(currentPrice)} r="1.5" fill="#fff" className="animate-pulse" />
       </svg>

       {/* Overlay Labels */}
       <div className="absolute top-2 left-2 bg-slate-900/80 px-2 py-1 rounded text-[10px] font-mono text-slate-400 border border-slate-800">
           High: {max.toFixed(5)}
       </div>
       <div className="absolute bottom-2 left-2 bg-slate-900/80 px-2 py-1 rounded text-[10px] font-mono text-slate-400 border border-slate-800">
           Low: {min.toFixed(5)}
       </div>
       {activePosition && (
           <div className={`absolute right-2 px-2 py-1 rounded text-[10px] font-bold border ${isLong ? 'bg-emerald-900/50 border-emerald-500/30 text-emerald-400' : 'bg-rose-900/50 border-rose-500/30 text-rose-400'}`} style={{ top: `${entryLineY}%`, transform: 'translateY(-50%)' }}>
               ENTRY
           </div>
       )}
    </div>
  );
};

export default PriceChart;
