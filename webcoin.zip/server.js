
const express = require('express');
const path = require('path');
const headless = require('./headless');

const app = express();
const PORT = process.env.PORT || 3000;

// Start the Headless Bot Logic
headless.start();

app.use(express.static(path.join(__dirname, 'build')));
app.use(express.json());

// --- API ENDPOINTS FOR REMOTE CONTROL ---

// Login / Auth Check (Simulated)
app.post('/api/login', (req, res) => {
    const { password } = req.body;
    if (password === 'admin') {
        res.cookie('hitbtc_bot_auth', 'valid_session', { maxAge: 2592000000, httpOnly: false }); // Accessible to client logic
        res.json({ success: true });
    } else {
        res.status(401).json({ success: false, error: 'Invalid Key' });
    }
});

// Get Full Bot State
app.get('/api/state', (req, res) => {
    const state = headless.getState();
    res.json(state);
});

// Fallback to React App
app.get('*', (req, res) => {
    // If build exists, serve it, otherwise show message
    res.sendFile(path.join(__dirname, 'build', 'index.html'), (err) => {
        if (err) res.send('HitBTC Bot Server is Running. (React App not built. Run "npm start" for dev or "npm run build" for prod)');
    });
});

app.listen(PORT, () => {
    console.log(`=================================================`);
    console.log(`  HitBTC AI Scalper Bot v5.3 (Server Active)`);
    console.log(`  Dashboard: http://localhost:${PORT}`);
    console.log(`  API:       http://localhost:${PORT}/api/state`);
    console.log(`=================================================`);
});
