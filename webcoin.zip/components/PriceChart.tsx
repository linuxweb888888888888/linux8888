
import React, { useMemo } from 'react';
import {
  ComposedChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Area
} from 'recharts';
import { Loader2 } from 'lucide-react';
import { MarketData, GridLine } from '../types';

interface PriceChartProps {
  data: MarketData[];
  gridLines: GridLine[];
  currentPrice: number;
  avgEntryPrice: number;
  currentBid: number;
  currentAsk: number;
  isLoading?: boolean;
}

const PriceChart: React.FC<PriceChartProps> = ({ 
  data, 
  gridLines, 
  currentPrice, 
  avgEntryPrice,
  currentBid,
  currentAsk,
  isLoading = false
}) => {
  // Calculate domain to ensure Bid/Ask and Price are always visible
  const { minDomain, maxDomain } = useMemo(() => {
    const prices = data.map(d => d.price);
    const validValues = [...prices, currentBid, currentAsk].filter(v => v > 0);
    
    if (validValues.length === 0) return { minDomain: 'auto', maxDomain: 'auto' };

    const min = Math.min(...validValues);
    const max = Math.max(...validValues);
    const padding = (max - min) * 0.2 || max * 0.001; // 20% padding or fallback

    return {
      minDomain: min - padding,
      maxDomain: max + padding
    };
  }, [data, currentBid, currentAsk]);

  const spread = currentAsk - currentBid;

  return (
    <div className="h-[400px] w-full bg-gray-850 rounded-xl border border-gray-800 p-4 shadow-lg relative">
      
      {/* Loading Overlay */}
      {isLoading && (
        <div className="absolute inset-0 z-50 bg-gray-900/80 backdrop-blur-sm flex flex-col items-center justify-center rounded-xl">
           <Loader2 className="w-8 h-8 text-hitbtc-blue animate-spin mb-2" />
           <p className="text-gray-400 text-sm font-medium">Loading Market Data...</p>
        </div>
      )}

      <div className="absolute top-4 left-4 z-10 flex flex-col gap-1 pointer-events-none">
         <div className="flex items-baseline gap-2">
           <h3 className="text-gray-400 text-sm font-medium uppercase tracking-wider">Mid Price</h3>
           <p className="text-2xl font-bold text-white transition-all duration-300 relative">
             ${currentPrice.toFixed(6)}
             <span className="absolute -right-3 top-0 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
             </span>
           </p>
         </div>
         
         <div className="flex items-center gap-3 mt-1 bg-gray-900/90 p-2 rounded border border-gray-800 backdrop-blur-sm shadow-xl z-20">
            <div className="flex flex-col">
               <span className="text-[9px] text-gray-500 font-bold uppercase">Bid</span>
               <span className="text-xs font-mono text-hitbtc-green font-semibold">
                 {currentBid > 0 ? `$${currentBid.toFixed(6)}` : '--'}
               </span>
            </div>
            <div className="w-px h-6 bg-gray-700"></div>
            <div className="flex flex-col">
               <span className="text-[9px] text-gray-500 font-bold uppercase">Ask</span>
               <span className="text-xs font-mono text-hitbtc-red font-semibold">
                 {currentAsk > 0 ? `$${currentAsk.toFixed(6)}` : '--'}
               </span>
            </div>
            <div className="w-px h-6 bg-gray-700"></div>
            <div className="flex flex-col">
               <span className="text-[9px] text-gray-500 font-bold uppercase">Spread</span>
               <span className="text-[10px] font-mono text-gray-400">
                 {spread > 0 ? spread.toFixed(6) : '--'}
               </span>
            </div>
         </div>

         {avgEntryPrice > 0 && (
           <div className="flex items-center gap-2 mt-2">
             <span className="px-2 py-0.5 rounded text-[10px] bg-yellow-500/20 text-yellow-500 border border-yellow-500/30 font-bold">AVG ENTRY</span>
             <span className="text-sm font-mono text-yellow-500">${avgEntryPrice.toFixed(6)}</span>
           </div>
         )}
      </div>

      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data}>
          <defs>
            <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#0984e3" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#0984e3" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#2d3748" vertical={false} />
          <XAxis 
            dataKey="time" 
            hide={true} 
          />
          <YAxis 
            domain={[minDomain, maxDomain]} 
            orientation="right" 
            tick={{ fill: '#718096', fontSize: 10, fontFamily: 'monospace' }}
            tickFormatter={(value) => value.toFixed(6)}
            stroke="#4a5568"
            width={70}
          />
          <Tooltip 
            contentStyle={{ backgroundColor: '#1a202c', borderColor: '#4a5568', color: '#fff' }}
            itemStyle={{ color: '#0984e3' }}
            formatter={(value: number) => [`$${value.toFixed(6)}`, 'Price']}
            labelStyle={{ display: 'none' }}
          />
          
          {/* Grid Lines Visualization */}
          {gridLines.map((line) => (
            <ReferenceLine 
              key={line.id} 
              y={line.price} 
              stroke={line.type === 'BUY' ? '#00b894' : '#ff7675'} 
              strokeDasharray="4 4"
              strokeOpacity={0.4}
              strokeWidth={1}
            />
          ))}

          {/* Real-time Bid/Ask Lines */}
          {currentBid > 0 && (
             <ReferenceLine 
               y={currentBid} 
               stroke="#00b894" 
               strokeDasharray="2 2" 
               strokeOpacity={0.8}
               label={{ position: 'insideRight', value: 'BID', fill: '#00b894', fontSize: 10, offset: 10 }}
             />
          )}
          {currentAsk > 0 && (
             <ReferenceLine 
               y={currentAsk} 
               stroke="#ff7675" 
               strokeDasharray="2 2" 
               strokeOpacity={0.8}
               label={{ position: 'insideRight', value: 'ASK', fill: '#ff7675', fontSize: 10, offset: 10 }}
             />
          )}

          <Area 
            type="monotone" 
            dataKey="price" 
            stroke="#0984e3" 
            strokeWidth={2}
            fillOpacity={1} 
            fill="url(#colorPrice)" 
            isAnimationActive={false}
          />
          
          {/* Current Price Line */}
          <ReferenceLine y={currentPrice} stroke="#fff" strokeDasharray="1 1" opacity={0.3} />

          {/* Average Entry Price Line */}
          {avgEntryPrice > 0 && (
             <ReferenceLine 
               y={avgEntryPrice} 
               stroke="#ecc94b" 
               strokeWidth={1}
               strokeDasharray="5 5"
               label={{ position: 'left', value: 'Avg Entry', fill: '#ecc94b', fontSize: 10 }}
             />
          )}

        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};

export default PriceChart;
