
import React from 'react';
import { BotStats } from '../types';
import { TrendingUp, DollarSign, Clock, Wallet, ArrowUpCircle, ArrowDownCircle, Activity } from 'lucide-react';

interface BotStatsPanelProps {
  stats: BotStats;
}

const StatCard: React.FC<{ label: string; value: string; icon: React.ReactNode; color: string; subValue?: string }> = ({ label, value, icon, color, subValue }) => (
  <div className="bg-gray-850 border border-gray-800 p-4 rounded-xl shadow-md flex items-center justify-between min-w-[200px]">
    <div>
      <p className="text-gray-500 text-xs font-medium uppercase">{label}</p>
      <p className={`text-xl font-bold mt-1 ${color}`}>{value}</p>
      {subValue && <p className="text-xs text-gray-400 mt-1">{subValue}</p>}
    </div>
    <div className={`p-3 rounded-full bg-opacity-10 ${color.replace('text-', 'bg-').replace('500', '500').replace('400', '500')}`}>
      {icon}
    </div>
  </div>
);

const BotStatsPanel: React.FC<BotStatsPanelProps> = ({ stats }) => {
  // Format uptime
  const formatTime = (ms: number) => {
    const seconds = Math.floor((ms / 1000) % 60);
    const minutes = Math.floor((ms / (1000 * 60)) % 60);
    const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  const netPnLColor = stats.currentCyclePnL >= 0 ? 'text-hitbtc-green' : 'text-hitbtc-red';
  const netFills = stats.buyFillCount - stats.sellFillCount;
  const directionColor = netFills > 0 ? 'text-hitbtc-green' : netFills < 0 ? 'text-hitbtc-red' : 'text-gray-400';
  const directionText = netFills > 0 ? 'LONG' : netFills < 0 ? 'SHORT' : 'FLAT';

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
      <StatCard 
        label="Net Cycle PnL" 
        value={`$${stats.currentCyclePnL.toFixed(4)}`} 
        subValue={`Fees Paid: $${stats.totalFees.toFixed(4)}`}
        color={netPnLColor}
        icon={<DollarSign size={20} className={netPnLColor} />}
      />
      
      {/* Directional Fills & Net Count */}
      <div className="bg-gray-850 border border-gray-800 p-4 rounded-xl shadow-md flex flex-col justify-center gap-2">
        <div className="flex justify-between items-center">
             <p className="text-gray-500 text-xs font-medium uppercase">Directional Fills</p>
             <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${directionColor} border-current opacity-70`}>
                NET {netFills > 0 ? '+' : ''}{netFills} ({directionText})
             </span>
        </div>
        <div className="flex items-center justify-between mt-1">
           <div className="flex items-center gap-2 text-hitbtc-green bg-green-900/20 px-3 py-1.5 rounded-lg border border-green-900/50">
             <ArrowUpCircle size={16} />
             <span className="font-bold">{stats.buyFillCount}</span>
             <span className="text-[10px] uppercase opacity-70">Buys</span>
           </div>
           <div className="flex items-center gap-2 text-hitbtc-red bg-red-900/20 px-3 py-1.5 rounded-lg border border-red-900/50">
             <ArrowDownCircle size={16} />
             <span className="font-bold">{stats.sellFillCount}</span>
             <span className="text-[10px] uppercase opacity-70">Sells</span>
           </div>
        </div>
      </div>

      <StatCard 
        label="Current Position" 
        value={`${stats.currentPosition.toFixed(5)}`} 
        subValue={`Entry: ${stats.avgEntryPrice > 0 ? '$'+stats.avgEntryPrice.toFixed(5) : '-'}`}
        color="text-blue-400"
        icon={<Wallet size={20} className="text-blue-400" />}
      />

      <StatCard 
        label="Realized Profit" 
        value={`$${stats.totalProfit.toFixed(4)}`} 
        subValue="Closed Portions"
        color="text-purple-400"
        icon={<Activity size={20} className="text-purple-400" />}
      />
      <StatCard 
        label="Runtime" 
        value={formatTime(stats.uptime)} 
        color="text-yellow-400"
        icon={<Clock size={20} className="text-yellow-400" />}
      />
    </div>
  );
};

export default BotStatsPanel;
