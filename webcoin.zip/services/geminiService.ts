import { GoogleGenAI, Type } from "@google/genai";
import { AIAnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeMarketAndSuggestGrid = async (
  currentPrice: number,
  recentTrend: 'UP' | 'DOWN' | 'SIDEWAYS',
  volatility: 'LOW' | 'MEDIUM' | 'HIGH'
): Promise<AIAnalysisResult> => {
  
  const prompt = `
    Act as a senior crypto futures trading analyst.
    Current Market Data:
    - Current Price: $${currentPrice}
    - Recent Trend: ${recentTrend}
    - Volatility: ${volatility}

    Suggest the FASTEST and MOST PROFITABLE Grid Trading configuration for HitBTC Futures.
    
    CRITICAL RULES:
    1. Grid Profit MUST cover trading fees (approx 0.06% per trade).
    2. Suggest a grid count where the step % is minimal (> 0.08%) to allow HIGH FREQUENCY scalping.
    3. Goal: Rapid execution (fast open/close) with small but guaranteed Net PnL.
    
    Guidelines:
    - Focus on tighter ranges to maximize grid density.
    - If Volatility is High, use range +/- 5% with many grids.
    - If Volatility is Low, use extremely tight range (+/- 1.5%) for scalping.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendation: { type: Type.STRING, description: "NEUTRAL, LONG, or SHORT" },
            suggestedLower: { type: Type.NUMBER, description: "Lower price bound" },
            suggestedUpper: { type: Type.NUMBER, description: "Upper price bound" },
            suggestedGrids: { type: Type.NUMBER, description: "Number of grid lines" },
            reasoning: { type: Type.STRING, description: "Brief explanation of the strategy" },
          },
          required: ["recommendation", "suggestedLower", "suggestedUpper", "suggestedGrids", "reasoning"],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    
    return JSON.parse(text) as AIAnalysisResult;
  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    // Fallback mock data if API fails
    return {
      recommendation: "NEUTRAL",
      suggestedLower: currentPrice * 0.98, // Tighter default
      suggestedUpper: currentPrice * 1.02,
      suggestedGrids: 40, // Higher count default
      reasoning: "AI service unavailable. Returning optimized high-frequency scalping strategy.",
    };
  }
};