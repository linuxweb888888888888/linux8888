
import { GoogleGenAI, Type } from "@google/genai";
import { AIAnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeMarketAndSuggestGrid = async (
  currentPrice: number,
  recentTrend: 'UP' | 'DOWN' | 'SIDEWAYS',
  volatility: 'LOW' | 'MEDIUM' | 'HIGH'
): Promise<AIAnalysisResult> => {
  
  const prompt = `
    Act as a senior crypto futures trading analyst.
    Current Market Data:
    - Current Price: $${currentPrice}
    - Recent Trend: ${recentTrend}
    - Volatility: ${volatility}

    Suggest the FASTEST and MOST PROFITABLE Grid Trading configuration for HitBTC Futures.
    
    CRITICAL RULES:
    1. Grid Profit MUST cover trading fees (approx 0.06% per trade).
    2. Suggest a grid count where the step % is > 0.15% (Fee * 2 + Profit).
    3. Maximize fill frequency (tight grids) but remain net profitable.
    
    Guidelines:
    - If Volatility is High, use wider range (+/- 10%) but keep grids dense.
    - If Volatility is Low, use tight range (+/- 3%).
    - Goal: Rapid execution with positive Net PnL.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendation: { type: Type.STRING, description: "NEUTRAL, LONG, or SHORT" },
            suggestedLower: { type: Type.NUMBER, description: "Lower price bound" },
            suggestedUpper: { type: Type.NUMBER, description: "Upper price bound" },
            suggestedGrids: { type: Type.NUMBER, description: "Number of grid lines" },
            reasoning: { type: Type.STRING, description: "Brief explanation of the strategy" },
          },
          required: ["recommendation", "suggestedLower", "suggestedUpper", "suggestedGrids", "reasoning"],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    
    return JSON.parse(text) as AIAnalysisResult;
  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    // Fallback mock data if API fails
    return {
      recommendation: "NEUTRAL",
      suggestedLower: currentPrice * 0.95,
      suggestedUpper: currentPrice * 1.05,
      suggestedGrids: 30,
      reasoning: "AI service unavailable. Returning optimized fee-aware scalping strategy.",
    };
  }
};
