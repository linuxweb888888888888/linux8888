
import { HitBTCTicker, HitBTCBalance, HitBTCAccount } from '../types';

const BASE_URL = 'https://api.hitbtc.com/api/3';
const PROXIES = [
    (url: string) => `https://corsproxy.io/?${encodeURIComponent(url)}`,
    (url: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`
];

const createHeaders = (apiKey: string, apiSecret: string) => {
  const auth = btoa(`${apiKey}:${apiSecret}`);
  return {
    'Authorization': `Basic ${auth}`,
    'Content-Type': 'application/json',
  };
};

const getUrl = (endpoint: string, useProxy: boolean) => {
    const directUrl = `${BASE_URL}${endpoint}`;
    return useProxy ? PROXIES[0](directUrl) : directUrl;
};

// Helper: Fetch with timeout
const fetchWithTimeout = async (url: string, options: RequestInit = {}, timeout = 5000) => {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    try {
        const response = await fetch(url, { ...options, signal: controller.signal });
        clearTimeout(id);
        return response;
    } catch (err: any) {
        clearTimeout(id);
        throw err;
    }
};

// Helper to convert number to fixed string without scientific notation
const formatQuantity = (qty: number): string => {
  return qty.toFixed(8).replace(/\.?0+$/, "");
};

// Safely parse ticker data preventing NaN
const parseTickerData = (data: any) => {
    if (!data || typeof data !== 'object') return { price: 0, bid: 0, ask: 0 };
    
    // Handle various API response formats safely
    const rawBid = data.bid ?? data.bestBid; 
    const rawAsk = data.ask ?? data.bestAsk;
    const rawLast = data.last ?? data.c; 

    let bid = parseFloat(rawBid);
    let ask = parseFloat(rawAsk);
    let last = parseFloat(rawLast);

    // Convert NaN to 0
    if (isNaN(bid)) bid = 0;
    if (isNaN(ask)) ask = 0;
    if (isNaN(last)) last = 0;

    // Calculate mid price or fallback to last
    let price = last;
    if (bid > 0 && ask > 0) {
        price = (bid + ask) / 2;
    } else if (last === 0 && bid > 0) {
        price = bid;
    }
    
    // Final safety check
    if (isNaN(price)) price = 0;

    return { price, bid: bid || price, ask: ask || price };
};

/**
 * ROBUST MARKET PRICE FETCHER
 */
export const fetchMarketPrice = async (symbol: string): Promise<{ price: number, bid: number, ask: number }> => {
    const timestamp = Date.now();
    const tickerPath = `${BASE_URL}/public/ticker/${symbol}?t=${timestamp}`;
    const orderbookPath = `${BASE_URL}/public/orderbook/${symbol}?limit=1&t=${timestamp}`;

    // Strategy 1: Direct Ticker
    try {
        const res = await fetchWithTimeout(tickerPath, {}, 3000);
        if (res.ok) {
            const data = await res.json();
            const result = parseTickerData(data);
            if (result.price > 0) return result;
        }
    } catch (e) { /* continue */ }

    // Strategy 2: Proxy Ticker (Primary)
    try {
        const res = await fetchWithTimeout(PROXIES[0](tickerPath), {}, 5000);
        if (res.ok) {
            const data = await res.json();
            const result = parseTickerData(data);
            if (result.price > 0) return result;
        }
    } catch (e) { /* continue */ }

    // Strategy 3: Proxy Ticker (Secondary)
    try {
        const res = await fetchWithTimeout(PROXIES[1](tickerPath), {}, 5000);
        if (res.ok) {
            const data = await res.json();
            const result = parseTickerData(data);
            if (result.price > 0) return result;
        }
    } catch (e) { /* continue */ }

    // Strategy 4: Orderbook Fallback (via Proxy)
    try {
        const res = await fetchWithTimeout(PROXIES[0](orderbookPath), {}, 5000);
        if (res.ok) {
            const data = await res.json();
            const bid = data.bid?.[0]?.price ? parseFloat(data.bid[0].price) : 0;
            const ask = data.ask?.[0]?.price ? parseFloat(data.ask[0].price) : 0;
            if (!isNaN(bid) && !isNaN(ask) && bid > 0 && ask > 0) {
                return { price: (bid + ask) / 2, bid, ask };
            }
        }
    } catch (e) { /* continue */ }

    throw new Error(`Could not fetch price for ${symbol} after multiple attempts.`);
};

// Re-export specific ticker fetcher for compatibility
export const fetchTicker = async (symbol: string): Promise<HitBTCTicker> => {
    const { price, bid, ask } = await fetchMarketPrice(symbol);
    return {
        symbol,
        ask: ask.toString(),
        bid: bid.toString(),
        last: price.toString(),
        timestamp: new Date().toISOString()
    };
};

export const fetchFuturesBalance = async (apiKey: string, apiSecret: string, useProxy: boolean = false): Promise<HitBTCBalance[]> => {
  try {
    const response = await fetchWithTimeout(getUrl('/futures/balance', useProxy), {
      method: 'GET',
      headers: createHeaders(apiKey, apiSecret),
    }, 8000);
    
    if (response.status === 401) throw new Error("401 Unauthorized - Check API Keys");
    if (!response.ok) {
      const text = await response.text();
      throw new Error(`Balance fetch failed (${response.status}): ${text}`);
    }
    
    const data = await response.json();
    if (!Array.isArray(data)) {
        if (data.error) throw new Error(`API Error: ${data.error.message || data.error}`);
        throw new Error("Invalid balance data format received");
    }
    return data;
  } catch (error) {
    console.error('Error fetching balance:', error);
    throw error;
  }
};

export const placeFuturesOrder = async (
  apiKey: string, 
  apiSecret: string, 
  symbol: string, 
  side: 'buy' | 'sell', 
  quantity: number,
  useProxy: boolean = false
) => {
  try {
    const qtyString = formatQuantity(quantity);
    
    // STRICT PARAMETERS: symbol, type=market, side, quantity, margin_mode=cross
    const body = {
      symbol: symbol,
      type: 'market',
      side: side,
      quantity: qtyString,
      margin_mode: 'cross'
    };

    console.log(`[HitBTC API] Placing Order:`, body);

    const response = await fetchWithTimeout(getUrl('/futures/order', useProxy), {
      method: 'POST',
      headers: createHeaders(apiKey, apiSecret),
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      const errorText = await response.text();
      try {
        const errJson = JSON.parse(errorText);
        if (errJson.error && errJson.error.message) {
           throw new Error(`${errJson.error.message} (Code: ${errJson.error.code})`);
        }
      } catch (e) { /* ignore parse error */ }
      throw new Error(`API Rejected: ${errorText.substring(0, 150)}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error placing order:', error);
    throw error;
  }
};
