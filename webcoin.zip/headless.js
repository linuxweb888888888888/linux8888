
/**
 * HitBTC AI Scalper - Headless Node.js Edition v4.8
 * Matches Web Preview Logic 1:1 (PnL Stability, Predictive Sizing, Net PnL Fix, Churning Safety)
 * Usage: node headless.js
 */

const fetch = require('node-fetch');
const ccxt = require('ccxt');

// --- CONFIGURATION ---
const MIN_QTY = 0.001;
const RAW_SYMBOL = 'ATOMUSDT_PERP'; 
let CCXT_SYMBOL = 'ATOM/USDT:USDT'; 

const TAKER_FEE_RATE = 0.0009;
const LEVERAGE = 20;
const RSI_PERIOD = 14;
const EMA_PERIOD = 20;
const BB_PERIOD = 20;
const BB_MULTIPLIER = 2;
const SCALING_FACTOR = 100_000_000; 
let MIN_ROIE_PCT = 0.0015; 

const MAX_WALLET_USAGE_PCT = 0.80; 
const BASE_GRID_DEVIATION = 0.001; 
const PYRAMID_THRESHOLD_PNL = 0.0002;
const MICRO_PROFIT_TARGET = 0.00012; 

// --- LEARNING PARAMETERS ---
let patternMemory = [];
let pnlVelocity = []; 
let pnlVarianceHistory = []; // v4.7
let rsiBuyThreshold = 35;
let rsiSellThreshold = 65;
let trendFilterWeight = 1.0;
let lastTradeTime = Date.now(); 

const API_KEY = '-3Mn7DL8P20iTj7QPoOSgyATuDcF-87h';
const API_SECRET = 'WzxCckLuICMXcjdRL-CbgcsbpGXHePcs';

// --- TERMINAL GRAPHICS ---
const C = {
    Reset: "\x1b[0m", Bright: "\x1b[1m", Red: "\x1b[31m", Green: "\x1b[32m", Yellow: "\x1b[33m", Blue: "\x1b[34m", Cyan: "\x1b[36m", Magenta: "\x1b[35m", White: "\x1b[37m", BgBlue: "\x1b[44m"
};

// --- STATE ---
let priceHistory = [];
let rsiHistory = [];
let ccxtExchange = null;
let market = { symbol: RAW_SYMBOL, mid: 0, bid: 0, ask: 0, timestamp: 0 };
let activePosition = null;
let wallet = { balance: 0, virtualBalance: 0, usedMargin: 0, freeMargin: 0, totalProfit: 0, efficiencyIndex: 90 };
let logs = [];
let lastTotalProfit = 0;
let consecutiveWins = 0;
let consecutiveLosses = 0;
let grossWins = 0;
let grossLosses = 0;
let lastTradeCondition = null;

// --- HELPERS ---
function log(msg, type='INFO') {
    const ts = new Date().toLocaleTimeString();
    let color = C.Reset;
    if (type === 'ERROR') color = C.Red;
    if (type === 'SUCCESS') color = C.Green;
    if (type === 'WARNING') color = C.Yellow;
    if (type === 'SYSTEM') color = C.Blue;
    if (type === 'TRADE') color = C.Cyan;
    logs.unshift(`${C.Dim}[${ts}]${C.Reset} ${color}[${type}]${C.Reset} ${msg}`);
    if (logs.length > 10) logs.pop();
    console.log(`${color}[${type}]${C.Reset} ${msg}`);
}

function formatMoney(val) {
    return `$${val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function calculateStandardDeviation(values) {
    if (values.length < 5) return 0;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const variance = values.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / values.length;
    return Math.sqrt(variance);
}

function drawDashboard(rsi, bb, divergence, volatility, regime) {
    console.clear();
    console.log(`${C.BgBlue}${C.White}${C.Bright}  HitBTC AI Scalper Bot v4.8 (VPS Edition)  ${C.Reset}`);
    console.log("");
    const pnlVar = calculateStandardDeviation(pnlVarianceHistory);
    console.log(`${C.Bright}WALLET (High Value Sim):${C.Reset}`);
    console.log(`Virtual Balance: ${C.Green}${formatMoney(wallet.virtualBalance)}${C.Reset} (Real: ${wallet.balance.toFixed(6)})`);
    console.log(`Efficiency Idx:  ${wallet.efficiencyIndex.toFixed(1)}% | PnL Var: ${pnlVar.toFixed(5)}`);
    console.log(`Margin Usage:    ${((wallet.usedMargin/wallet.balance)*100).toFixed(1)}% / ${(MAX_WALLET_USAGE_PCT*100)}% Cap`);
    console.log("");
    console.log(`${C.Bright}MARKET (${CCXT_SYMBOL}):${C.Reset}`);
    console.log(`Price: ${C.Yellow}${market.mid.toFixed(5)}${C.Reset} | Vol: ${volatility.toFixed(2)} | Regime: ${C.Cyan}${regime}${C.Reset}`);
    console.log(`RSI: ${rsi > 70 ? C.Red : rsi < 30 ? C.Green : C.Reset}${rsi.toFixed(1)}${C.Reset} | BB Pos: ${bb.position.toFixed(2)} | Div: ${divergence !== 0 ? (divergence > 0 ? C.Green+"BULL" : C.Red+"BEAR") : "NONE"}`);
    console.log("");
    console.log(`${C.Bright}ACTIVE POSITION:${C.Reset}`);
    if (activePosition) {
        const pnlColor = activePosition.unrealizedPnL >= 0 ? C.Green : C.Red;
        const marginUsed = (activePosition.size * activePosition.entryPrice) / LEVERAGE;
        console.log(`Direction: ${activePosition.direction} | Size: ${activePosition.size} ATOM`);
        console.log(`Margin Used: ${marginUsed.toFixed(5)} USDT`);
        console.log(`Entry: ${activePosition.entryPrice.toFixed(5)} | Mark: ${market.mid.toFixed(5)}`);
        console.log(`PnL (Gross): ${pnlColor}${activePosition.unrealizedPnL.toFixed(6)} USDT${C.Reset}`);
        console.log(`Target PnL:  ${activePosition.targetPnL ? activePosition.targetPnL.toFixed(6) : '---'}`);
    } else {
        console.log(`${C.Dim}Waiting for signal...${C.Reset}`);
    }
    console.log("");
    console.log(`${C.Bright}SYSTEM LOGS:${C.Reset}`);
    logs.slice(0, 5).forEach(l => console.log(l));
}

// --- INDICATORS ---
function calculateRSI(prices) {
  if (prices.length < RSI_PERIOD + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = prices.length - RSI_PERIOD; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff >= 0) gains += diff; else losses -= diff;
  }
  if (losses === 0) return 100;
  const rs = gains / losses;
  return 100 - (100 / (1 + rs));
}

function calculateBollingerBands(prices) {
    if (prices.length < BB_PERIOD) return { position: 0.5 };
    const slice = prices.slice(-BB_PERIOD);
    const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
    const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / slice.length;
    const stdDev = Math.sqrt(variance);
    const upper = mean + (BB_MULTIPLIER * stdDev);
    const lower = mean - (BB_MULTIPLIER * stdDev);
    const current = prices[prices.length - 1];
    let position = 0.5;
    if (upper - lower !== 0) position = (current - lower) / (upper - lower);
    return { upper, lower, position };
}

function calculateEMA(prices, period) {
    if (prices.length < period) return prices[prices.length - 1];
    const k = 2 / (period + 1);
    let ema = prices[0];
    for (let i = 1; i < prices.length; i++) {
        ema = (prices[i] * k) + (ema * (1 - k));
    }
    return ema;
}

function calculateDivergence(prices, rsis) {
    if (prices.length < 10 || rsis.length < 10) return 0;
    const pC = prices[prices.length - 1], pP = prices[prices.length - 6];
    const rC = rsis[rsis.length - 1], rP = rsis[rsis.length - 6];
    if (pC < pP && rC > rP + 2) return 1;
    if (pC > pP && rC < rP - 2) return -1;
    return 0;
}

function detectMarketRegime(volatility, trendStrength) {
    if (volatility > 2.0) return 'VOLATILE';
    if (Math.abs(trendStrength) > 1.0) return 'TRENDING';
    return 'RANGING';
}

function matchPattern(current) {
    if (patternMemory.length === 0) return 0;
    let bestMatchScore = -999;
    for(const mem of patternMemory) {
        const distRsi = Math.abs(current.rsi - mem.rsi);
        const distTrend = Math.abs(current.trendStrength - mem.trendStrength);
        const distVol = Math.abs(current.volatility - mem.volatility);
        const distImb = Math.abs((current.imbalance || 0) - (mem.imbalance || 0));
        const similarity = 100 - (distRsi + (distTrend * 10) + (distVol * 10) + (distImb * 20)); 
        if (similarity > 70) { 
            if (mem.result === 'WIN') bestMatchScore = Math.max(bestMatchScore, 1); 
            if (mem.result === 'LOSS') bestMatchScore = Math.max(bestMatchScore, -1); 
        }
    }
    return bestMatchScore === -999 ? 0 : bestMatchScore;
}

// v4.7 Predictive Sizing
function calculateSmartEntrySize(wallet, marketPrice, patternMatchScore, predictedPnL) {
    let base = MIN_QTY;
    if (wallet.efficiencyIndex > 85) base += MIN_QTY; 
    
    // PnL Stability
    const pnlVariance = calculateStandardDeviation(pnlVarianceHistory);
    if (pnlVariance > 0.0005) base = MIN_QTY; 
    else if (predictedPnL > 1000 && pnlVariance < 0.0001) base *= 1.5;

    if (patternMatchScore > 0) {
        base *= 1.2; 
        base = Math.ceil(base * 1000) / 1000;
    }

    if (wallet.totalProfit > 0) {
        const profitRiskAmount = wallet.totalProfit * 0.15; 
        const extraQty = profitRiskAmount / (marketPrice / LEVERAGE); 
        base += extraQty;
    }
    base = Math.min(base, MIN_QTY * 20); 
    if (consecutiveLosses > 1 || wallet.efficiencyIndex < 60) base = MIN_QTY;
    
    const maxAllowedMarginUsage = (wallet.balance * MAX_WALLET_USAGE_PCT);
    const availableForNewTrade = maxAllowedMarginUsage - wallet.usedMargin;
    let maxSafeQty = 0;
    if (availableForNewTrade > 0) maxSafeQty = (availableForNewTrade * LEVERAGE) / marketPrice;
    const physicalMaxQty = (wallet.freeMargin * 0.99 * LEVERAGE) / marketPrice;
    let finalSize = Math.min(base, maxSafeQty, physicalMaxQty);
    return Math.floor(finalSize * 1000) / 1000;
}

// --- CORE ---
async function init() {
    try {
        log('Initializing CCXT...', 'SYSTEM');
        ccxtExchange = new ccxt.hitbtc({ apiKey: API_KEY, secret: API_SECRET, options: { defaultType: 'swap' } });
        const markets = await ccxtExchange.loadMarkets();
        const marketInfo = Object.values(markets).find(m => m.id === RAW_SYMBOL);
        if (marketInfo) CCXT_SYMBOL = marketInfo.symbol;
        log(`Trading Pair: ${CCXT_SYMBOL}`, 'SUCCESS');
    } catch (e) { log(`Init Failed: ${e.message}`, 'ERROR'); }
}

async function updateMarket() {
    try {
        const ticker = await ccxtExchange.fetchTicker(CCXT_SYMBOL);
        market.mid = (ticker.bid + ticker.ask) / 2;
        market.bid = ticker.bid;
        market.ask = ticker.ask;
        priceHistory.push(market.mid);
        if (priceHistory.length > 100) priceHistory.shift();
    } catch (e) { }
}

async function syncWallet() {
    try {
        const balances = await ccxtExchange.privateGetFuturesBalance();
        let usdt = null;
        if (Array.isArray(balances)) usdt = balances.find(b => b.currency === 'USDT');
        if (usdt) {
            const rawReserve = usdt.cross_margin_reserved || usdt.reserved_margin || 0;
            const rawAvailable = usdt.available || 0;
            const realBalance = parseFloat(rawReserve);
            const available = parseFloat(rawAvailable);
            wallet.balance = realBalance;
            wallet.freeMargin = available > 0 ? available : realBalance;
            wallet.usedMargin = realBalance - wallet.freeMargin;
            wallet.virtualBalance = wallet.balance * SCALING_FACTOR;
        }
    } catch (e) {
        try {
            const bal = await ccxtExchange.fetchBalance({ type: 'swap' });
            if(bal['USDT']) {
                wallet.balance = bal['USDT'].total || 0;
                wallet.freeMargin = bal['USDT'].free || 0;
                wallet.virtualBalance = wallet.balance * SCALING_FACTOR;
            }
        } catch(err) {}
    }
}

async function syncPosition() {
    try {
        const positions = await ccxtExchange.fetchPositions([CCXT_SYMBOL]);
        const pos = positions.find(p => p.symbol === CCXT_SYMBOL);
        if (pos && parseFloat(pos.contracts) > 0) {
            const size = parseFloat(pos.contracts);
            const entry = parseFloat(pos.entryPrice);
            const pnl = parseFloat(pos.unrealizedPnl || 0);
            if (!activePosition) {
                activePosition = {
                    direction: pos.side.toUpperCase(),
                    entryPrice: entry, size: size, unrealizedPnL: pnl, highestPnL: pnl, targetPnL: 0 
                };
            } else {
                activePosition.size = size;
                activePosition.unrealizedPnL = pnl; 
                activePosition.highestPnL = Math.max(activePosition.highestPnL, pnl);
            }
        } else {
            activePosition = null;
        }
    } catch (e) {}
}

async function order(side, amount) {
    try {
        log(`ORDER: ${side.toUpperCase()} ${amount} ${CCXT_SYMBOL}`, 'TRADE');
        await ccxtExchange.createMarketOrder(CCXT_SYMBOL, side, amount);
        log(`Order Placed Successfully`, 'SUCCESS');
        lastTradeTime = Date.now();
    } catch (e) { log(`Order Failed: ${e.message}`, 'ERROR'); }
}

async function checkAndAdoptPositions() {
     try {
        const positions = await ccxtExchange.fetchPositions([CCXT_SYMBOL]);
        const pos = positions.find(p => p.symbol === CCXT_SYMBOL);
        if (pos && parseFloat(pos.contracts) > 0) {
            const pnl = parseFloat(pos.unrealizedPnl || 0);
            const size = parseFloat(pos.contracts);
            const side = pos.side; 
            const entry = parseFloat(pos.entryPrice);
            const estimatedValue = Math.abs(size) * entry;
            const roundTripFee = estimatedValue * TAKER_FEE_RATE * 2;
            const netPnL = pnl - roundTripFee;
            if (netPnL > 0) {
                log(`Startup: Closing profitable ${side} position.`, 'SUCCESS');
                await order(side === 'long' ? 'sell' : 'buy', size);
            } else {
                log(`Startup: Adopting position ${side} (${size}).`, 'WARNING');
                activePosition = {
                    direction: side.toUpperCase(), entryPrice: entry, size: size, unrealizedPnL: pnl, highestPnL: pnl, targetPnL: 0
                };
            }
        }
    } catch(e) { log('Startup Position Check Failed', 'ERROR'); }
}

// --- STRATEGY LOOP ---
async function loop() {
    await updateMarket(); await syncWallet(); await syncPosition();

    // Efficiency Learning
    if (wallet.totalProfit > lastTotalProfit) {
        wallet.efficiencyIndex = Math.min(100, wallet.efficiencyIndex + 5);
        const gain = wallet.totalProfit - lastTotalProfit;
        consecutiveWins++; consecutiveLosses = 0;
        pnlVelocity.unshift(gain); if (pnlVelocity.length > 5) pnlVelocity.pop();
        pnlVarianceHistory.push(gain); if (pnlVarianceHistory.length > 10) pnlVarianceHistory.shift();

        if (consecutiveWins >= 3) { rsiBuyThreshold = Math.min(45, rsiBuyThreshold + 1); rsiSellThreshold = Math.max(55, rsiSellThreshold - 1); }
        if (lastTradeCondition) {
             if (patternMemory.length > 50) patternMemory.shift();
             lastTradeCondition.result = 'WIN'; patternMemory.push(lastTradeCondition); lastTradeCondition = null;
             log(`[LEARNING] Stored Winning Pattern.`, 'SUCCESS');
        }
        lastTotalProfit = wallet.totalProfit;
    } else if (wallet.totalProfit < lastTotalProfit) {
        const loss = lastTotalProfit - wallet.totalProfit;
        wallet.efficiencyIndex = Math.max(40, wallet.efficiencyIndex - 2.5);
        consecutiveLosses++; consecutiveWins = 0;
        pnlVelocity.unshift(-loss); if (pnlVelocity.length > 5) pnlVelocity.pop();
        pnlVarianceHistory.push(loss); if (pnlVarianceHistory.length > 10) pnlVarianceHistory.shift();

        if (consecutiveLosses >= 1) { rsiBuyThreshold = Math.max(25, rsiBuyThreshold - 2); rsiSellThreshold = Math.min(75, rsiSellThreshold + 2); trendFilterWeight = 1.5; }
        if (lastTradeCondition) {
             if (patternMemory.length > 50) patternMemory.shift();
             lastTradeCondition.result = 'LOSS'; patternMemory.push(lastTradeCondition); lastTradeCondition = null;
        }
        lastTotalProfit = wallet.totalProfit;
    }

    const avgVelocity = pnlVelocity.length > 0 ? pnlVelocity.reduce((a,b) => a+b, 0) / pnlVelocity.length : 0;
    const rsi = calculateRSI(priceHistory);
    rsiHistory.push(rsi); if (rsiHistory.length > 50) rsiHistory.shift();
    const bb = calculateBollingerBands(priceHistory);
    const divergence = calculateDivergence(priceHistory, rsiHistory);
    const currentEMA = calculateEMA(priceHistory, EMA_PERIOD);
    // EMA Safety
    const trendStrength = currentEMA !== 0 ? ((market.mid - currentEMA) / currentEMA) * 1000 : 0;
    const stdDev = calculateStandardDeviation(priceHistory.slice(-20));
    const volatility = (stdDev / (market.mid || 1)) * 1000;
    const imbalance = divergence * 500; 
    const regime = detectMarketRegime(volatility, trendStrength);

    drawDashboard(rsi, bb, divergence, volatility, regime);

    if (!activePosition) {
        const atLower = bb.position <= 0.1; const atUpper = bb.position >= 0.9;
        const isOversold = rsi < rsiBuyThreshold; const isOverbought = rsi > rsiSellThreshold;
        let dir = 'NEUTRAL'; let conf = 0;

        if (regime === 'RANGING') { if (atLower && isOversold) { dir = 'LONG'; conf = 80; } else if (atUpper && isOverbought) { dir = 'SHORT'; conf = 80; } } 
        else if (regime === 'TRENDING') { if (trendStrength > 0.5 && isOversold) { dir = 'LONG'; conf = 75; } else if (trendStrength < -0.5 && isOverbought) { dir = 'SHORT'; conf = 75; } } 
        else { if (divergence === 1) { dir = 'LONG'; conf = 65; } else if (divergence === -1) { dir = 'SHORT'; conf = 65; } }
        
        if (divergence === 1 && dir === 'LONG') conf += 15; if (divergence === -1 && dir === 'SHORT') conf += 15;
        const currentPattern = { rsi, volatility, trendStrength, imbalance, regime, result: 'WIN' };
        const matchScore = matchPattern(currentPattern);
        if (matchScore === 1) conf += 15; else if (matchScore === -1) conf -= 30;
        if (dir === 'LONG' && market.mid < currentEMA && conf < 90) conf -= (10 * trendFilterWeight); 
        if (dir === 'SHORT' && market.mid > currentEMA && conf < 90) conf -= (10 * trendFilterWeight);

        const idleTimeMinutes = (Date.now() - lastTradeTime) / 60000;
        let requiredConfidence = 55;
        if (idleTimeMinutes > 3) requiredConfidence -= Math.min(15, Math.floor(idleTimeMinutes - 3) * 2);

        if (dir !== 'NEUTRAL' && conf > requiredConfidence) {
             const walletUsage = wallet.usedMargin / (wallet.balance || 1);
             if (walletUsage < MAX_WALLET_USAGE_PCT && wallet.freeMargin > 0.0000001) {
                const predictedPnL = wallet.virtualBalance * 0.01 * (conf / 100);
                let size = calculateSmartEntrySize(wallet, market.mid, matchScore, predictedPnL);
                log(`SIGNAL: ${dir} (${conf}%) [${regime}]`, 'TRADE');
                await order(dir === 'LONG' ? 'buy' : 'sell', size);
                lastTradeCondition = currentPattern;
             }
        }
    } else {
        lastTradeTime = Date.now();
        const pnl = activePosition.unrealizedPnL;
        const size = activePosition.size;
        const entry = activePosition.entryPrice;
        const entryFee = (size * entry * TAKER_FEE_RATE);
        const exitFee = (size * market.mid * TAKER_FEE_RATE);
        const roundTripFee = entryFee + exitFee;
        const netPnL = pnl - roundTripFee;
        const roiTarget = (size * entry) * MIN_ROIE_PCT;
        let target = Math.max(roundTripFee * 3.0, roiTarget, MICRO_PROFIT_TARGET);
        if (avgVelocity > 0.0005) target *= 1.15; else if (avgVelocity < 0) target *= 0.9;
        if (volatility > 2.0) target *= 2.0; else if (volatility > 1.0) target *= 1.5; else if (volatility < 0.5) target *= 0.8;
        if (wallet.efficiencyIndex > 95) target *= 1.2; else if (wallet.efficiencyIndex < 80) target *= 0.9;
        if (regime === 'TRENDING') target *= 1.5;
        activePosition.targetPnL = target;

        if (activePosition.highestPnL >= roundTripFee * 3.0) { if (pnl < roundTripFee * 2.8) { log('Fee Floor Hit (2.8x) - Closing', 'WARNING'); await order(activePosition.direction === 'LONG' ? 'sell' : 'buy', size); wallet.totalProfit += netPnL; activePosition = null; return; } }
        if (pnl > target * 1.1) { log(`Target 110% Hit - Closing`, 'SUCCESS'); await order(activePosition.direction === 'LONG' ? 'sell' : 'buy', size); wallet.totalProfit += netPnL; activePosition = null; return; }
        if (activePosition.highestPnL > target * 0.9) { if (pnl < activePosition.highestPnL * 0.8) { log('Ratchet Stop Hit', 'SUCCESS'); await order(activePosition.direction === 'LONG' ? 'sell' : 'buy', size); wallet.totalProfit += netPnL; activePosition = null; return; } }

        const isStale = (Date.now() - activePosition.timestamp) > (15 * 60 * 1000);
        if (isStale && Math.abs(pnl) < (target * 0.5) && size > MIN_QTY && netPnL > 0) { log('Stalemate Profit Exit.', 'WARNING'); await order(activePosition.direction === 'LONG' ? 'sell' : 'buy', size); wallet.totalProfit += netPnL; activePosition = null; return; }
        
        const usage = wallet.usedMargin / wallet.balance;
        // PnL Churning with Net PnL Fix + Size Safety
        if (size > MIN_QTY * 5 && usage > 0.40 && netPnL > MIN_QTY * market.mid * 0.001 && Math.random() < 0.2) { 
             log('Churning Micro-Profit', 'SUCCESS'); 
             await order(activePosition.direction === 'LONG' ? 'sell' : 'buy', MIN_QTY);
             const portionGross = (pnl / size) * MIN_QTY;
             const portionFees = (market.mid * MIN_QTY * TAKER_FEE_RATE) + (entry * MIN_QTY * TAKER_FEE_RATE);
             wallet.totalProfit += (portionGross - portionFees);
             activePosition.size -= MIN_QTY; 
        }
        // De-Risking with Net PnL Fix + Size Safety
        if (usage > 0.85 && pnl < -0.0005 && size > MIN_QTY * 2) { 
             log('High Usage De-Risking', 'WARNING'); 
             await order(activePosition.direction === 'LONG' ? 'sell' : 'buy', MIN_QTY);
             const portionGross = (pnl / size) * MIN_QTY;
             const portionFees = (market.mid * MIN_QTY * TAKER_FEE_RATE) + (entry * MIN_QTY * TAKER_FEE_RATE);
             wallet.totalProfit += (portionGross - portionFees);
             activePosition.size -= MIN_QTY; 
        }
        
        if (activePosition && usage < MAX_WALLET_USAGE_PCT) {
             if (pnl > PYRAMID_THRESHOLD_PNL) { log('Pyramiding Winner', 'TRADE'); await order(activePosition.direction === 'LONG' ? 'buy' : 'sell', MIN_QTY); activePosition.size += MIN_QTY; }
             const deviation = Math.abs((market.mid - entry) / entry);
             if (deviation > BASE_GRID_DEVIATION && pnl < 0) { const rsiSafe = activePosition.direction === 'LONG' ? rsi < 40 : rsi > 60; if (rsiSafe) { log('Grid Averaging', 'TRADE'); await order(activePosition.direction === 'LONG' ? 'buy' : 'sell', MIN_QTY); activePosition.size += MIN_QTY; } }
        }
    }
}

module.exports = { start: loop }; 
if (require.main === module) { init().then(() => { checkAndAdoptPositions().then(() => setInterval(loop, 200)); }); }
