
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { LayoutDashboard, Settings, LineChart, Github, RefreshCw, Terminal, Activity, Trash2, BrainCircuit, Zap } from 'lucide-react';
import { MarketData, GridConfig, BotStatus, GridLine, BotStats, AIAnalysisResult, HitBTCAccount } from './types';
import PriceChart from './components/PriceChart';
import ConfigForm from './components/ConfigForm';
import BotStatsPanel from './components/BotStatsPanel';
import { analyzeMarketAndSuggestGrid } from './services/geminiService';
import { fetchMarketPrice, fetchFuturesBalance, placeFuturesOrder } from './services/hitbtcApi';

// Initial config
const DEFAULT_CONFIG: GridConfig = {
  mode: 'LIVE', 
  apiKey: '-3Mn7DL8P20iTj7QPoOSgyATuDcF-87h',
  apiSecret: 'WzxCckLuICMXcjdRL-CbgcsbpGXHePcs',
  symbol: 'ATOMUSDT_PERP',
  lowerPrice: 0, 
  upperPrice: 0, 
  grids: 0, 
  leverage: 10,
  investment: 20,
  type: 'NEUTRAL',
  takeProfitUSD: 1,
  feeRate: 0.06, 
  useProxy: true,
  autoAdjust: true 
};

const App: React.FC = () => {
  // --- State ---
  const [config, setConfig] = useState<GridConfig>(DEFAULT_CONFIG);
  const [botStatus, setBotStatus] = useState<BotStatus>(BotStatus.IDLE);
  const [isStarting, setIsStarting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  // Market Data
  const [currentPrice, setCurrentPrice] = useState<number>(0);
  const [currentBid, setCurrentBid] = useState<number>(0);
  const [currentAsk, setCurrentAsk] = useState<number>(0);
  const [marketData, setMarketData] = useState<MarketData[]>([]);
  const [isMarketDataLoading, setIsMarketDataLoading] = useState<boolean>(true);
  
  // Bot State
  const [gridLines, setGridLines] = useState<GridLine[]>([]);
  const [botStats, setBotStats] = useState<BotStats>({
    totalProfit: 0,
    currentCyclePnL: 0,
    activeOrders: 0,
    filledOrders: 0,
    uptime: 0,
    startPrice: 0,
    currentPosition: 0,
    avgEntryPrice: 0,
    totalFees: 0,
    buyFillCount: 0,
    sellFillCount: 0,
    currentVolatility: 0
  });
  
  // Logs
  const [logs, setLogs] = useState<string[]>(['[SYSTEM] Bot Dashboard Initialized. Waiting for user command...']);
  const logsEndRef = useRef<HTMLDivElement>(null);
  
  // AI State
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult | null>(null);

  // Refs for loop access
  const startTimeRef = useRef<number | null>(null);
  const gridLinesRef = useRef<GridLine[]>([]);
  const currentPriceRef = useRef<number>(0);
  const currentBidRef = useRef<number>(0);
  const currentAskRef = useRef<number>(0);
  const lastLogTimeRef = useRef<number>(Date.now());
  const botLoopRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const gridStepRef = useRef<number>(0);
  const activeBoundsRef = useRef({ lower: 0, upper: 0 }); // Tracks dynamic bounds
  const lastAutoAdjustTimeRef = useRef<number>(0);
  const hasAutoStarted = useRef(false);
  
  // Paper Trading State
  const paperState = useRef({
    position: 0,
    entryPrice: 0,
    accumulatedCost: 0,
    fees: 0
  });

  // Keep refs in sync
  useEffect(() => { gridLinesRef.current = gridLines; }, [gridLines]);
  useEffect(() => {
    currentPriceRef.current = currentPrice;
    currentBidRef.current = currentBid;
    currentAskRef.current = currentAsk;
  }, [currentPrice, currentBid, currentAsk]);

  // Logging Function
  const addLog = useCallback((msg: string, type: 'INFO' | 'SUCCESS' | 'ERROR' | 'WARN' = 'INFO') => {
    const time = new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const prefix = type === 'INFO' ? '' : `[${type}] `;
    console.log(`%cBOT: ${prefix}${msg}`, type === 'ERROR' ? 'color: red' : 'color: cyan'); 
    setLogs(prev => {
      const newLogs = [...prev, `${prefix}[${time}] ${msg}`];
      return newLogs.slice(-200); 
    });
    if (type !== 'INFO') {
        setTimeout(() => logsEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
    }
    if (type !== 'INFO' || msg.includes('Filled')) {
      lastLogTimeRef.current = Date.now();
    }
  }, []);

  const clearLogs = () => {
    setLogs([`Logs cleared. System ready.`]);
  };

  // --- Volatility Calculation ---
  const calculateVolatility = useCallback((data: MarketData[]) => {
      if (data.length < 10) return 0;
      const prices = data.map(d => d.price);
      const mean = prices.reduce((a, b) => a + b, 0) / prices.length;
      const variance = prices.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / prices.length;
      return (Math.sqrt(variance) / mean) * 100; // % Volatility
  }, []);

  // --- Smart Grid Optimization ---
  const optimizeGridConfig = useCallback((price: number, cfg: GridConfig, volatility: number = 0.5) => {
      // 1. Calculate Minimum Viable Grid Step to cover Fees
      // Formula: (Fee * 2) + AdaptiveProfit
      // If volatility is high, we want larger steps to capture swings.
      // If volatility is low, we want tighter steps (but must cover fees).
      
      const minProfitBase = 0.05; // 0.05% absolute min
      const adaptiveProfit = Math.max(minProfitBase, volatility * 0.4); // Scale profit target with volatility
      
      const requiredSpreadPercent = (cfg.feeRate * 2) + adaptiveProfit; 
      const minGridStepPrice = price * (requiredSpreadPercent / 100);

      // 2. Determine Range based on Direction (Auto Learn / Adjust)
      let lower = 0;
      let upper = 0;
      
      // Scale range with volatility too
      const rangeMultiplier = Math.max(1, volatility); 
      let rangePercent = 0.05 * rangeMultiplier; 

      if (cfg.type === 'NEUTRAL') {
          lower = price * (1 - rangePercent);
          upper = price * (1 + rangePercent);
      } else if (cfg.type === 'LONG') {
          lower = price * (1 - (rangePercent * 0.8)); // Tighter bottom
          upper = price * (1 + (rangePercent * 1.2)); // Higher top
      } else if (cfg.type === 'SHORT') {
          lower = price * (1 - (rangePercent * 1.2));
          upper = price * (1 + (rangePercent * 0.8));
      }

      // 3. Calculate Optimal Grid Count
      const totalRange = upper - lower;
      const rawGridCount = totalRange / minGridStepPrice;
      const optimalGrids = Math.floor(Math.max(5, Math.min(rawGridCount, 150))); 

      const actualStep = totalRange / optimalGrids;
      const actualStepPercent = (actualStep / price) * 100;

      return {
          lower: parseFloat(lower.toFixed(8)),
          upper: parseFloat(upper.toFixed(8)),
          grids: optimalGrids,
          step: actualStep,
          stepPercent: actualStepPercent,
          requiredSpread: requiredSpreadPercent
      };
  }, []);

  // --- Grid Calculation ---
  const calculateGrids = useCallback((cfg: GridConfig, refPrice: number) => {
    const lines: GridLine[] = [];
    if (cfg.grids < 2 || isNaN(refPrice) || refPrice <= 0) return lines;
    
    const range = cfg.upperPrice - cfg.lowerPrice;
    const step = range / cfg.grids;
    
    for (let i = 0; i <= cfg.grids; i++) {
      const price = parseFloat((cfg.lowerPrice + (step * i)).toFixed(8));
      let type: 'BUY' | 'SELL';
      
      if (cfg.type === 'NEUTRAL') {
          if (price < refPrice) type = 'BUY';
          else type = 'SELL';
      } else if (cfg.type === 'LONG') {
          type = price < refPrice ? 'BUY' : 'SELL';
      } else {
          type = price > refPrice ? 'SELL' : 'BUY';
      }
      
      lines.push({
        id: `grid-${i}-${Date.now()}`,
        price,
        type,
        status: 'OPEN'
      });
    }
    return lines;
  }, []);

  // --- Auto-Config on Symbol Change ---
  useEffect(() => {
    const autoAdjustConfig = async () => {
      if (botStatus === BotStatus.RUNNING) return;
      setIsMarketDataLoading(true);
      try {
        const { price } = await fetchMarketPrice(config.symbol);
        if (price > 0 && !isNaN(price)) {
          const isBTC = config.symbol.includes('BTC') && !config.symbol.includes('USDT');
          let defaultInv = isBTC ? 0.002 : 50;
          let defaultTP = isBTC ? 0.0001 : 2;

          // Initial optimization with default volatility assumption
          const optimized = optimizeGridConfig(price, config, 0.5);

          setConfig(prev => ({
            ...prev,
            lowerPrice: optimized.lower,
            upperPrice: optimized.upper,
            grids: optimized.grids,
            investment: defaultInv,
            takeProfitUSD: defaultTP
          }));
          
          addLog(`Smart Grid Initialized: ${optimized.grids} Grids`);
          addLog(`Step: ${optimized.stepPercent.toFixed(3)}% (Covers ${config.feeRate*2}% fees + profit)`);
        }
      } catch (e) {
        console.error(e);
      }
      setIsMarketDataLoading(false);
    };
    if (config.symbol) autoAdjustConfig();
  }, [config.symbol, config.type, config.feeRate, optimizeGridConfig]);

  // --- Market Data Polling ---
  const performMarketFetch = useCallback(async () => {
      try {
        const { price, bid, ask } = await fetchMarketPrice(config.symbol);
        
        if (price > 0 && !isNaN(price)) {
          setCurrentPrice(price);
          setCurrentBid(bid);
          setCurrentAsk(ask);
          setIsMarketDataLoading(false);
          setMarketData(prev => {
             const newData = [...prev, { 
               time: new Date().toLocaleTimeString(),
               price: price,
               volume: 0 
             }];
             return newData.slice(-100);
          });
          return price;
        }
        return 0;
      } catch (err) {
         return 0;
      }
  }, [config.symbol]);

  useEffect(() => {
    performMarketFetch();
    const interval = setInterval(performMarketFetch, 1000); 
    return () => clearInterval(interval);
  }, [performMarketFetch]);


  // --- Bot Control ---
  const handleStart = async () => {
    setIsStarting(true);
    setError(null);
    addLog(`System initializing for ${config.mode} mode...`);

    try {
      addLog("Fetching precise market entry price...", 'INFO');
      let startPrice = await performMarketFetch();
      
      if (!startPrice || isNaN(startPrice) || startPrice <= 0) {
         try {
             const freshData = await fetchMarketPrice(config.symbol);
             startPrice = freshData.price;
         } catch (e) {
             throw new Error("Cannot start: Market price unavailable.");
         }
      }
      
      if (!startPrice || isNaN(startPrice) || startPrice <= 0) {
        throw new Error("Price is invalid. Cannot calculate grids.");
      }

      if (config.mode === 'LIVE') {
        if (!config.apiKey || !config.apiSecret) throw new Error("API credentials missing");
        addLog("Checking HitBTC Balance...", 'INFO');
        const balances = await fetchFuturesBalance(config.apiKey, config.apiSecret, config.useProxy);
        const hasBalance = balances.some(b => parseFloat(b.available) > 0.0001);
        if (!hasBalance) addLog("Warning: Low/Zero balance detected.", 'WARN');
        else addLog("Connection verified. Balance available.", 'SUCCESS');
      }

      // Initial Volatility Check
      const vol = calculateVolatility(marketData) || 0.5;
      
      // Optimize
      const optimized = optimizeGridConfig(startPrice, config, vol);
      
      // Update UI Config for visibility
      setConfig(prev => ({...prev, grids: optimized.grids, lowerPrice: optimized.lower, upperPrice: optimized.upper}));
      
      // Store in Refs for reliable loop access
      gridStepRef.current = (optimized.upper - optimized.lower) / optimized.grids;
      activeBoundsRef.current = { lower: optimized.lower, upper: optimized.upper };

      const lines = calculateGrids({ ...config, grids: optimized.grids, lowerPrice: optimized.lower, upperPrice: optimized.upper }, startPrice);
      
      setGridLines(lines);
      setBotStats({
        totalProfit: 0,
        currentCyclePnL: 0,
        activeOrders: lines.length,
        filledOrders: 0,
        uptime: 0,
        startPrice: startPrice,
        currentPosition: 0,
        avgEntryPrice: 0,
        totalFees: 0,
        buyFillCount: 0,
        sellFillCount: 0,
        currentVolatility: vol
      });
      
      paperState.current = { position: 0, entryPrice: 0, accumulatedCost: 0, fees: 0 };
      startTimeRef.current = Date.now();
      
      setBotStatus(BotStatus.RUNNING);
      addLog(`BOT STARTED. Range: ${optimized.lower} - ${optimized.upper}`, 'SUCCESS');
      addLog(`Adaptive Step: ${optimized.stepPercent.toFixed(3)}% (Vol: ${vol.toFixed(3)}%)`, 'SUCCESS');

    } catch (e: any) {
      setError(e.message);
      addLog(`START FAILED: ${e.message}`, 'ERROR');
    } finally {
      setIsStarting(false);
    }
  };

  const handleStop = () => {
    setBotStatus(BotStatus.IDLE);
    addLog('Bot stopped by user.', 'WARN');
  };

  const handleAIAnalysis = async () => {
    setIsAnalyzing(true);
    const vol = calculateVolatility(marketData);
    const result = await analyzeMarketAndSuggestGrid(currentPrice, 'SIDEWAYS', vol > 1 ? 'HIGH' : 'LOW');
    setAiAnalysis(result);
    setIsAnalyzing(false);
    addLog('AI Strategy Generated.', 'SUCCESS');
  };

  // --- AUTO START EFFECT ---
  useEffect(() => {
    const autoStart = async () => {
       if (!hasAutoStarted.current && config.apiKey && config.mode === 'LIVE') {
           hasAutoStarted.current = true;
           await new Promise(r => setTimeout(r, 1500)); // Delay for market data init
           if (botStatus === BotStatus.IDLE) {
              addLog('Auto-Starting with pre-configured credentials...', 'WARN');
              handleStart();
           }
       }
    };
    autoStart();
  }, []);

  // --- MAIN BOT LOOP ---
  useEffect(() => {
    if (botLoopRef.current) clearInterval(botLoopRef.current);
    botLoopRef.current = setInterval(async () => {
      if (botStatus !== BotStatus.RUNNING) return;

      const price = currentPriceRef.current;
      const bid = currentBidRef.current;
      const ask = currentAskRef.current;
      
      if (price <= 0 || isNaN(price)) return; 

      // Update Uptime
      if (startTimeRef.current) {
        setBotStats(prev => ({ ...prev, uptime: Date.now() - (startTimeRef.current || Date.now()) }));
      }

      // --- AUTO LEARNING & ADAPTATION ---
      // Run every ~5 seconds
      if (config.autoAdjust && Date.now() - lastAutoAdjustTimeRef.current > 5000) {
          const vol = calculateVolatility(marketData);
          setBotStats(prev => ({ ...prev, currentVolatility: vol }));
          
          // 1. Adaptive Step Calculation
          // If volatility spikes, we increase the step for future grids
          const optimized = optimizeGridConfig(price, config, vol);
          const currentStep = gridStepRef.current;
          const newStep = optimized.step;
          
          // Only update if difference is significant (>10%) to avoid jitter
          if (Math.abs(newStep - currentStep) / currentStep > 0.1) {
              gridStepRef.current = newStep;
              addLog(`[Auto-Learn] Volatility ${vol.toFixed(2)}%. Adjusted grid step to ${optimized.stepPercent.toFixed(3)}% for max profit.`, 'WARN');
          }

          // 2. Infinite Grid (Dynamic Bounds)
          // If price moves close to edges (within 1 grid step), expand bounds
          const { lower, upper } = activeBoundsRef.current;
          const expansionBuffer = gridStepRef.current * 2;
          
          if (price > upper - expansionBuffer) {
              const newUpper = price + (price * 0.05); // Add 5% headroom
              activeBoundsRef.current.upper = newUpper;
              // Also sync UI silently
              setConfig(prev => ({ ...prev, upperPrice: newUpper }));
              addLog(`[Infinite Grid] Price trending up. Auto-expanded Upper Range to ${newUpper.toFixed(4)}`, 'SUCCESS');
          } else if (price < lower + expansionBuffer) {
              const newLower = price - (price * 0.05); // Add 5% legroom
              activeBoundsRef.current.lower = newLower;
              setConfig(prev => ({ ...prev, lowerPrice: newLower }));
              addLog(`[Infinite Grid] Price trending down. Auto-expanded Lower Range to ${newLower.toFixed(4)}`, 'SUCCESS');
          }

          lastAutoAdjustTimeRef.current = Date.now();
      }

      // Watchdog
      if (Date.now() - lastLogTimeRef.current > 10000) {
         const active = gridLinesRef.current.filter(g => g.status === 'OPEN');
         let minDiff = Number.MAX_VALUE;
         active.forEach(g => {
             const diff = Math.abs(price - g.price);
             if (diff < minDiff) minDiff = diff;
         });
         addLog(`[Monitor] Price: ${price} | Nearest Grid: ${(minDiff/price*100).toFixed(4)}% away`, 'INFO');
         lastLogTimeRef.current = Date.now(); 
      }

      // --- PROCESS GRIDS ---
      const activeGrids = gridLinesRef.current.filter(g => g.status === 'OPEN');
      const triggeredGrids: GridLine[] = [];
      
      for (const grid of activeGrids) {
         if (grid.type === 'BUY' && ask <= grid.price) triggeredGrids.push(grid);
         else if (grid.type === 'SELL' && bid >= grid.price) triggeredGrids.push(grid);
      }

      if (triggeredGrids.length === 0) return;

      // --- EXECUTE ORDERS ---
      const amountPerGrid = config.investment / config.grids;
      const rawQty = amountPerGrid / price;
      const minQty = 0.00001; 
      const qty = Math.max(rawQty, minQty); 

      const executionPromises = triggeredGrids.map(async (grid) => {
         const side = grid.type === 'BUY' ? 'buy' : 'sell';
         if (config.mode === 'PAPER') {
            return { status: 'fulfilled', grid, side, qty, price: grid.price };
         } else {
            try {
               await placeFuturesOrder(
                  config.apiKey, 
                  config.apiSecret, 
                  config.symbol, 
                  side, 
                  qty, 
                  config.useProxy
               );
               return { status: 'fulfilled', grid, side, qty, price: grid.price };
            } catch (e: any) {
               addLog(`Order Error (${side}): ${e.message}`, 'ERROR');
               return { status: 'rejected', reason: e.message, grid };
            }
         }
      });

      const results = await Promise.allSettled(executionPromises);
      const successfulGridIds: string[] = [];
      const newGridLines: GridLine[] = []; 
      let netRealizedPnL = 0;
      let buyCount = 0;
      let sellCount = 0;
      let feesIncurred = 0;

      results.forEach((res) => {
         if (res.status === 'fulfilled' && res.value && res.value.status === 'fulfilled') {
            // @ts-ignore
            const { grid, side, qty, price } = res.value;
            successfulGridIds.push(grid.id);
            addLog(`${config.mode} ${side.toUpperCase()} Filled @ ${price}`, 'SUCCESS');

            // --- CALCULATE FEES ---
            const tradeFee = qty * price * (config.feeRate / 100);
            feesIncurred += tradeFee;

            // --- RECURRENT GRID LOGIC (PING-PONG) ---
            // Uses the dynamically adjusted gridStepRef
            const step = gridStepRef.current;
            if (step > 0) {
               if (side === 'buy') {
                   const newPrice = parseFloat((price + step).toFixed(8));
                   // Check against dynamic bounds
                   if (newPrice <= activeBoundsRef.current.upper) {
                       newGridLines.push({
                           id: `grid-flip-sell-${Date.now()}-${Math.random()}`,
                           price: newPrice,
                           type: 'SELL',
                           status: 'OPEN'
                       });
                   }
               } else {
                   const newPrice = parseFloat((price - step).toFixed(8));
                   if (newPrice >= activeBoundsRef.current.lower) {
                       newGridLines.push({
                           id: `grid-flip-buy-${Date.now()}-${Math.random()}`,
                           price: newPrice,
                           type: 'BUY',
                           status: 'OPEN'
                       });
                   }
               }
            }

            if (side === 'buy') {
               buyCount++;
               if (config.mode === 'PAPER') {
                  paperState.current.position += qty;
                  paperState.current.accumulatedCost += (qty * price);
                  paperState.current.fees += tradeFee;
               }
            } else {
               sellCount++;
               // Net Profit Calculation: (Sell - Buy) - 2*Fees
               // Note: We are approximating the Buy price as (SellPrice - Step)
               // This is accurate for grid trading because we only sell what we bought at the lower step
               const effectiveBuyPrice = price - step;
               const grossProfit = (price - effectiveBuyPrice) * qty;
               const roundTripFees = tradeFee * 2; // Approx
               const netProfit = grossProfit - roundTripFees;
               
               if (netProfit > 0) netRealizedPnL += netProfit;

               if (config.mode === 'PAPER') {
                  paperState.current.position -= qty;
                  paperState.current.accumulatedCost -= (qty * price);
                  paperState.current.fees += tradeFee;
               }
            }
         }
      });

      if (successfulGridIds.length > 0) {
         setGridLines(prev => {
             const updated = prev.map(g => successfulGridIds.includes(g.id) ? { ...g, status: 'FILLED' } : g);
             return [...updated, ...newGridLines];
         });

         setBotStats(prev => ({
            ...prev,
            filledOrders: prev.filledOrders + successfulGridIds.length,
            activeOrders: prev.activeOrders - successfulGridIds.length + newGridLines.length,
            buyFillCount: prev.buyFillCount + buyCount,
            sellFillCount: prev.sellFillCount + sellCount,
            totalProfit: prev.totalProfit + netRealizedPnL, 
            totalFees: prev.totalFees + feesIncurred,
            currentCyclePnL: prev.currentCyclePnL + netRealizedPnL 
         }));
      }

      if (config.mode === 'PAPER') {
         const currentVal = paperState.current.position * price;
         const entryVal = paperState.current.accumulatedCost;
         const unrealizedPnL = currentVal - entryVal;
         setBotStats(prev => ({
            ...prev,
            currentPosition: paperState.current.position,
            currentCyclePnL: unrealizedPnL - paperState.current.fees,
            avgEntryPrice: paperState.current.position > 0 ? entryVal / paperState.current.position : 0
         }));
      }

    }, 250);

    return () => { if (botLoopRef.current) clearInterval(botLoopRef.current); };
  }, [botStatus, config, marketData, calculateVolatility, optimizeGridConfig]); // Added dependencies for auto-learn

  return (
    <div className="min-h-screen bg-gray-950 text-gray-200 font-sans selection:bg-hitbtc-blue selection:text-white">
      <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-md sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-hitbtc-blue to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <LayoutDashboard size={18} className="text-white" />
            </div>
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
              GridMaster <span className="text-hitbtc-blue">AI</span>
            </h1>
            <span className="text-[10px] bg-gray-800 text-gray-400 px-2 py-0.5 rounded border border-gray-700">HitBTC v3</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 text-xs text-gray-500 bg-gray-900/80 px-3 py-1.5 rounded-full border border-gray-800">
               {config.autoAdjust ? <BrainCircuit size={14} className="text-hitbtc-blue animate-pulse" /> : <Settings size={14} />}
               <span>{config.autoAdjust ? 'Auto-Learning Active' : 'Manual Mode'}</span>
            </div>
             <a href="https://github.com" target="_blank" rel="noreferrer" className="text-gray-500 hover:text-white transition-colors">
               <Github size={20} />
             </a>
          </div>
        </div>
      </header>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <BotStatsPanel stats={botStats} />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <PriceChart 
               data={marketData} 
               gridLines={gridLines} 
               currentPrice={currentPrice}
               avgEntryPrice={botStats.avgEntryPrice}
               currentBid={currentBid}
               currentAsk={currentAsk}
               isLoading={isMarketDataLoading}
            />
            <div className="bg-gray-850 rounded-xl border border-gray-800 shadow-lg flex flex-col h-[300px]">
              <div className="p-3 border-b border-gray-800 flex items-center justify-between bg-gray-900/50 rounded-t-xl">
                <div className="flex items-center gap-2 text-gray-400">
                  <Terminal size={16} />
                  <span className="text-xs font-mono font-medium">System Logs</span>
                </div>
                <button onClick={clearLogs} className="text-gray-500 hover:text-white transition-colors">
                  <Trash2 size={14} />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-3 font-mono text-xs space-y-1 custom-scrollbar bg-gray-950/80 text-gray-300">
                {logs.length === 0 && <span className="text-gray-600 italic">No activity recorded yet...</span>}
                {logs.map((log, i) => {
                   let color = 'text-gray-300';
                   if (log.includes('[SUCCESS]')) color = 'text-green-400';
                   if (log.includes('[ERROR]')) color = 'text-red-400';
                   if (log.includes('[WARN]')) color = 'text-yellow-400';
                   return (
                     <div key={i} className={`${color} break-all border-b border-gray-800/50 pb-0.5 mb-0.5 last:border-0`}>
                       {log}
                     </div>
                   );
                })}
                <div ref={logsEndRef} />
              </div>
            </div>
          </div>
          <div className="lg:col-span-1">
            <ConfigForm 
              config={config} 
              setConfig={setConfig} 
              botStatus={botStatus}
              isStarting={isStarting}
              onStart={handleStart} 
              onStop={handleStop}
              onAIRequest={handleAIAnalysis}
              isAnalyzing={isAnalyzing}
              aiAnalysis={aiAnalysis}
              error={error}
            />
          </div>
        </div>
      </main>
    </div>
  );
};
export default App;
