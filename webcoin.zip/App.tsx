
// Bridge file to redirect to the correct source code in src/
// This fixes the "@/" alias error by using the relative-path compliant App.tsx in src/
export { default } from './src/App';