
import { BotState, Direction, LogEntry, Position, MarketData } from '../types';

// This file now acts as a Client-Server Bridge.
// It attempts to fetch the REAL state from the Node.js server.
// If the server is unreachable (e.g. preview mode), it falls back to the browser simulation logic.

// --- Constants (Fallback) ---
const MIN_QTY = 0.001;
const SYMBOL = 'ATOMUSDT_PERP';
const DISPLAY_SYMBOL = 'ATOM/USDT (Perp)';
const SCALING_FACTOR = 100_000_000;
const SERVER_URL = 'http://localhost:3000/api/state';

// --- State ---
let currentState: BotState = getFreshState();
let timerWorker: Worker | null = null;
let useServer = false;

function getFreshState(): BotState {
    return {
        isRunning: true,
        market: { symbol: DISPLAY_SYMBOL, bid: 0, ask: 0, mid: 0, timestamp: Date.now() },
        activePosition: null,
        wallet: { startBalance: 0, balance: 0, virtualBalance: 0, virtualEquity: 0, usedMargin: 0, freeMargin: 0, totalProfit: 0, virtualTotalProfit: 0, growthPercentage: 0, winRate: 100, efficiencyIndex: 90 },
        signal: { direction: Direction.NEUTRAL, confidence: 0, predictedPnL: 0, features: { rsi: 50, stochK: 50, stochD: 50, bbPosition: 0.5, volatility: 0, trendStrength: 0, imbalance: 0, divergence: 0 } },
        logs: [],
        simulationsRun: 0,
    };
}

// --- Server Sync ---
async function syncWithServer() {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 500); // 500ms timeout
        const res = await fetch(SERVER_URL, { signal: controller.signal });
        if (res.ok) {
            const serverState = await res.json();
            currentState = serverState;
            useServer = true;
        } else {
            useServer = false;
        }
    } catch (e) {
        useServer = false;
    }
}

// --- Fallback Simulation (Simplified for brevity, full logic remains in previous version if needed) ---
// In this standalone version, we assume the user will run the server. 
// However, to keep the preview alive, we run a basic tick.
function runFallbackSimulation() {
    // Basic price movement
    const mid = currentState.market.mid || 2.74;
    currentState.market.mid = mid + (Math.random() - 0.5) * 0.001;
    currentState.market.bid = currentState.market.mid - 0.0001;
    currentState.market.ask = currentState.market.mid + 0.0001;
    
    // Basic Signal
    currentState.signal.features.rsi = 50 + Math.sin(Date.now() / 1000) * 20;
    currentState.simulationsRun++;
    
    // We keep logs alive
    if(currentState.logs.length === 0) {
        addLog("[CLIENT] Server not detected. Running UI in Simulation Mode.", "WARNING");
    }
}

function addLog(msg: string, type: LogEntry['type']) {
    const entry: LogEntry = { id: Date.now() + Math.random(), timestamp: new Date().toLocaleTimeString(), message: msg, type };
    currentState.logs = [entry, ...currentState.logs].slice(0, 50);
}

export function startBotEngine() {
    if (timerWorker) { timerWorker.terminate(); }
    
    // Web Worker for loop
    const blob = new Blob([`
        let interval;
        self.onmessage = function(e) {
            if (e.data.action === 'start') {
                interval = setInterval(() => self.postMessage('tick'), 1000);
            } else if (e.data.action === 'stop') clearInterval(interval);
        }
    `], { type: 'application/javascript' });

    timerWorker = new Worker(URL.createObjectURL(blob));
    timerWorker.onmessage = async () => {
        await syncWithServer();
        if (!useServer) runFallbackSimulation();
    };
    timerWorker.postMessage({ action: 'start' });
}

export function stopBotEngine() {
    if (timerWorker) timerWorker.postMessage({ action: 'stop' });
    currentState.isRunning = false;
}

export async function toggleBot() {
    if (useServer) {
        try { await fetch('http://localhost:3000/api/toggle', { method: 'POST' }); } catch(e) {}
    } else {
        currentState.isRunning = !currentState.isRunning;
    }
    return currentState.isRunning;
}

export function getUpdatedState(): BotState {
    return { ...currentState };
}
