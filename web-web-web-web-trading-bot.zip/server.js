
const express = require('express');
const cors = require('cors');
const ccxt = require('ccxt');
const path = require('path');
const fs = require('fs');

// --- CONFIGURATION ---
const PORT = 3000;
const MIN_QTY = 0.001;
const SYMBOL = 'ATOMUSDT_PERP';
const DISPLAY_SYMBOL = 'ATOM/USDT (Perp)';
const TAKER_FEE_RATE = 0.0009;
const LEVERAGE = 20;
const SCALING_FACTOR = 100_000_000;
const MIN_ROIE_PCT = 0.0015;
const MICRO_PROFIT_TARGET = 0.00006;
const MAX_WALLET_USAGE_PCT = 0.60;
const BASE_GRID_DEVIATION = 0.002;
const PYRAMID_THRESHOLD_PNL = 0.0005;
const STALEMATE_THRESHOLD_MS = 15 * 60 * 1000;

// API KEYS (Ideally load from process.env or file)
const API_KEY = '-3Mn7DL8P20iTj7QPoOSgyATuDcF-87h';
const API_SECRET = 'WzxCckLuICMXcjdRL-CbgcsbpGXHePcs';

// --- APP SETUP ---
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '.'))); // Serve frontend files

// --- STATE ---
let botState = {
    isRunning: true,
    market: { symbol: DISPLAY_SYMBOL, bid: 0, ask: 0, mid: 0, timestamp: Date.now() },
    activePosition: null,
    wallet: { 
        startBalance: 0, 
        balance: 0, 
        virtualBalance: 0, 
        virtualEquity: 0, 
        usedMargin: 0, 
        freeMargin: 0, 
        totalProfit: 0, 
        virtualTotalProfit: 0,
        growthPercentage: 0,
        winRate: 100,
        efficiencyIndex: 90 
    },
    signal: { 
        direction: 'NEUTRAL', 
        confidence: 0, 
        predictedPnL: 0, 
        features: { rsi: 50, stochK: 50, stochD: 50, bbPosition: 0.5, volatility: 0, trendStrength: 0, imbalance: 0, divergence: 0 } 
    },
    logs: [],
    simulationsRun: 0
};

let priceHistory = [];
let rsiHistory = [];
let lastTotalProfit = 0;
let ccxtExchange = null;

// --- HELPERS ---
function addLog(msg, type='INFO') {
    const entry = { id: Date.now() + Math.random(), timestamp: new Date().toLocaleTimeString(), message: msg, type };
    botState.logs = [entry, ...botState.logs].slice(0, 100);
    console.log(`[${type}] ${msg}`);
}

function formatVirtual(val) { return `$${(val * SCALING_FACTOR).toFixed(2)}`; }

function calculateRSI(prices) {
    if (prices.length < 15) return 50;
    let gains = 0, losses = 0;
    for (let i = prices.length - 14; i < prices.length; i++) {
        const diff = prices[i] - prices[i - 1];
        if (diff >= 0) gains += diff; else losses -= diff;
    }
    if (losses === 0) return 100;
    return 100 - (100 / (1 + (gains / losses)));
}

function calculateStochRSI(rsis) {
    if (rsis.length < 14) return { k: 50, d: 50 };
    const slice = rsis.slice(-14);
    const min = Math.min(...slice), max = Math.max(...slice);
    let k = 50;
    if (max - min !== 0) k = ((slice[slice.length-1] - min) / (max - min)) * 100;
    return { k, d: k * 0.9 + 5 };
}

function calculateBollingerBands(prices) {
    if (prices.length < 20) return { position: 0.5 };
    const slice = prices.slice(-20);
    const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
    const stdDev = Math.sqrt(slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / slice.length);
    const current = prices[prices.length - 1];
    const upper = mean + (2 * stdDev);
    const lower = mean - (2 * stdDev);
    let pos = 0.5;
    if (upper - lower !== 0) pos = (current - lower) / (upper - lower);
    return { position: pos };
}

function calculateDivergence(prices, rsis) {
    if (prices.length < 10) return 0;
    const pC = prices[prices.length-1], pP = prices[prices.length-6];
    const rC = rsis[rsis.length-1], rP = rsis[rsis.length-6];
    if (pC < pP && rC > rP + 2) return 1;
    if (pC > pP && rC < rP - 2) return -1;
    return 0;
}

// --- TRADING ENGINE ---
async function initExchange() {
    try {
        ccxtExchange = new ccxt.hitbtc({ apiKey: API_KEY, secret: API_SECRET, options: { defaultType: 'future' } });
        addLog('Connected to HitBTC (Server)', 'SUCCESS');
    } catch (e) { addLog('CCXT Init Failed', 'ERROR'); }
}

async function updateMarket() {
    try {
        const ticker = await ccxtExchange.fetchTicker(SYMBOL);
        botState.market.bid = ticker.bid;
        botState.market.ask = ticker.ask;
        botState.market.mid = (ticker.bid + ticker.ask) / 2;
        botState.market.timestamp = Date.now();
        priceHistory.push(botState.market.mid);
        if (priceHistory.length > 100) priceHistory.shift();
    } catch (e) {}
}

async function syncWallet() {
    try {
        const balance = await ccxtExchange.fetchBalance({ type: 'future' });
        const usdt = balance['USDT'];
        if (usdt) {
            const realBal = usdt.total || 0;
            botState.wallet.balance = realBal;
            botState.wallet.freeMargin = usdt.free || 0;
            botState.wallet.usedMargin = usdt.used || 0;
            
            // Virtual Mapping
            botState.wallet.virtualBalance = realBal * SCALING_FACTOR;
            botState.wallet.virtualTotalProfit = botState.wallet.totalProfit * SCALING_FACTOR;
            if (botState.wallet.startBalance === 0 && realBal > 0) botState.wallet.startBalance = realBal;
        }
    } catch (e) {}
}

async function syncPosition() {
    try {
        const positions = await ccxtExchange.fetchPositions([SYMBOL]);
        const pos = positions.find(p => p.symbol === SYMBOL);
        if (pos && parseFloat(pos.contracts) > 0) {
            const size = parseFloat(pos.contracts);
            const entry = parseFloat(pos.entryPrice);
            const pnl = parseFloat(pos.unrealizedPnl || 0);
            
            // Persist highest PnL
            let highest = pnl;
            if (botState.activePosition) highest = Math.max(botState.activePosition.highestPnL, pnl);
            
            const fee = (size * entry * TAKER_FEE_RATE) * 2;
            const roiTarget = (size * entry) * MIN_ROIE_PCT;
            const target = Math.max(fee * 3, roiTarget, MICRO_PROFIT_TARGET);

            botState.activePosition = {
                id: 'REAL', symbol: SYMBOL,
                direction: pos.side.toUpperCase(),
                entryPrice: entry,
                size: size,
                unrealizedPnL: pnl,
                highestPnL: highest,
                targetPnL: target,
                leverage: LEVERAGE,
                timestamp: botState.activePosition ? botState.activePosition.timestamp : Date.now()
            };
        } else {
            botState.activePosition = null;
        }
    } catch (e) {}
}

async function executeOrder(side, amount) {
    try {
        addLog(`Executing ${side.toUpperCase()} ${amount}`, 'WARNING');
        await ccxtExchange.createMarketOrder(SYMBOL, side, amount);
        addLog('Order Success', 'SUCCESS');
        return true;
    } catch (e) { 
        addLog(`Order Failed: ${e.message}`, 'ERROR');
        return false;
    }
}

async function strategyLoop() {
    if (!botState.isRunning || !ccxtExchange) return;
    
    await updateMarket();
    await syncWallet();
    await syncPosition();
    
    // Indicators
    const rsi = calculateRSI(priceHistory);
    rsiHistory.push(rsi); if (rsiHistory.length > 50) rsiHistory.shift();
    const stoch = calculateStochRSI(rsiHistory);
    const bb = calculateBollingerBands(priceHistory);
    const div = calculateDivergence(priceHistory, rsiHistory);
    
    // Update Signal
    const atLower = bb.position <= 0.1;
    const atUpper = bb.position >= 0.9;
    let dir = 'NEUTRAL', conf = 0;
    
    if (atLower && stoch.k < 20) { dir = 'LONG'; conf = 75 + (div===1?15:0); }
    else if (atUpper && stoch.k > 80) { dir = 'SHORT'; conf = 75 + (div===-1?15:0); }
    
    botState.signal = { 
        direction: dir, confidence: conf, predictedPnL: 0,
        features: { rsi, stochK: stoch.k, stochD: stoch.d, bbPosition: bb.position, volatility: 0, trendStrength: 0, imbalance: 0, divergence: div }
    };
    botState.simulationsRun++;

    const walletUsage = botState.wallet.usedMargin / (botState.wallet.balance || 1);

    // --- ENTRY ---
    if (!botState.activePosition && dir !== 'NEUTRAL' && conf > 55) {
        if (walletUsage < MAX_WALLET_USAGE_PCT && botState.wallet.freeMargin > 0.01) {
            await executeOrder(dir === 'LONG' ? 'buy' : 'sell', MIN_QTY);
        }
    } 
    // --- MANAGE ---
    else if (botState.activePosition) {
        const pos = botState.activePosition;
        const pnl = pos.unrealizedPnL;
        const target = pos.targetPnL || MICRO_PROFIT_TARGET;
        
        // 1. Fee Floor Logic
        const fee = (pos.size * pos.entryPrice * TAKER_FEE_RATE) * 2;
        if (pos.highestPnL > fee * 3 && pnl < fee * 3) {
            addLog('Fee Floor Hit', 'WARNING');
            await executeOrder(pos.direction === 'LONG' ? 'sell' : 'buy', pos.size);
            return;
        }

        // 2. Take Profit
        if (pnl > target * 1.1) {
             addLog('Force Take Profit', 'SUCCESS');
             await executeOrder(pos.direction === 'LONG' ? 'sell' : 'buy', pos.size);
             return;
        }

        // 3. Ratchet
        if (pos.highestPnL > target * 0.8 && pnl < Math.max(pos.highestPnL * 0.8, fee*2)) {
             addLog('Ratchet Profit', 'SUCCESS');
             await executeOrder(pos.direction === 'LONG' ? 'sell' : 'buy', pos.size);
             return;
        }

        // 4. De-Risking
        if (walletUsage > 0.85 && pnl < -0.0005 && pos.size > MIN_QTY) {
            addLog('High Usage De-Risking', 'WARNING');
            await executeOrder(pos.direction === 'LONG' ? 'sell' : 'buy', MIN_QTY);
            return;
        }
    }
}

// --- API ROUTES ---
app.get('/api/state', (req, res) => res.json(botState));
app.post('/api/toggle', (req, res) => { 
    botState.isRunning = !botState.isRunning; 
    addLog(botState.isRunning ? 'Bot Resumed' : 'Bot Paused', 'INFO');
    res.json({ status: 'ok' }); 
});

// --- START ---
app.listen(PORT, async () => {
    console.log(`Bot Server running on port ${PORT}`);
    await initExchange();
    setInterval(strategyLoop, 2000);
});
