const express = require('express');
const path = require('path');
const headless = require('./headless');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files from the React app build (if available)
// For now, we serve a basic status page
app.get('/', (req, res) => {
    res.send('HitBTC Bot Server is Running. Check terminal for logs.');
});

app.listen(PORT, () => {
    console.log(`Web Server running on http://localhost:${PORT}`);
    console.log('Starting Headless Bot Logic...');
    // Headless bot starts automatically via require, but we can also trigger specific logic here
});
