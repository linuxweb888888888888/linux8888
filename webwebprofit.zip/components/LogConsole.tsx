
import React from 'react';
import { LogEntry } from '../types';

interface LogConsoleProps {
  logs: LogEntry[];
}

const LogConsole: React.FC<LogConsoleProps> = ({ logs }) => {
  return (
    <div className="bg-slate-900 border border-slate-700 rounded-lg p-4 h-64 flex flex-col">
      <h3 className="text-xs font-bold text-slate-400 uppercase mb-2 tracking-wider flex justify-between items-center">
        <span>/var/www/html/dashboard.html (System Logs)</span>
        <span className="inline-block w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
      </h3>
      <div className="flex-1 overflow-y-auto font-mono text-xs space-y-1 custom-scrollbar">
        {logs.map((log) => (
          <div key={log.id} className="flex items-start border-b border-slate-800/50 pb-1 last:border-0">
            <span className="text-slate-500 mr-2 shrink-0">[{log.timestamp}]</span>
            <span className={`${
              log.type === 'SUCCESS' ? 'text-emerald-400' :
              log.type === 'ERROR' ? 'text-rose-500' :
              log.type === 'WARNING' ? 'text-amber-400' :
              'text-slate-300'
            }`}>
              {log.message}
            </span>
          </div>
        ))}
        {logs.length === 0 && (
          <div className="text-slate-600 italic">Waiting for bot output...</div>
        )}
      </div>
    </div>
  );
};

export default LogConsole;
    