bidask="$(echo "$1" | sed "s/\/.*//g")"

#while true
#do

#linuxlinuxweb8888="$(curl -s "https://api.hitbtc.com/api/3/public/symbol/$(echo "$bidask")_PERP" | jq | jq .quantity_increment | sed 's/"//g')"

#if [[ $2 ]]
#then

#linuxlinuxweb8888="$(cat /quantityincrement$(echo "$bidask") | tail -n1)"

#linuxlinuxweb8888="$(echo "$linuxlinuxweb8888 10" | awk '{print $1*$2}' | awk -F"E" 'BEGIN{OFMT="%10.10f"} {print $1 * (10 ^ $2)}')"

#else

#linuxlinuxweb8888="$(cat /quantityincrement$(echo "$bidask")$(echo "$2") | tail -n1)"

if [[ $3 ]]
then

linuxlinuxweb8888="$3"

else

linuxlinuxweb8888="$(cat ./quantityincrement$(echo "$bidask")$(echo "$2") | tail -n1)"

fi

#fi

#linuxlinuxweb8888="$(curl -s "https://api.hitbtc.com/api/3/public/symbol/$(echo "$bidask")USDT_PERP" | jq | jq .quantity_increment | sed 's/"//g')"

#linuxlinuxweb8888="$(echo "$linuxlinuxweb8888 2" | awk '{print $1*$2}' | awk -F"E" 'BEGIN{OFMT="%10.10f"} {print $1 * (10 ^ $2)}')"

#if [[ $(echo "$linuxlinuxweb8888" | grep -v "Insufficient margin") ]]
#then

if [[ $(cat /var/www/html/user | sed -n "/^$(echo "$2" | sed "s/ .*//g") .*$/p" | sed "s/.* .* //g" | uniq) == "virtual" ]]
then

curl -X POST -u "$(cat ./userapisetting | sed -n "/^$(echo "$2" | sed "s/ .*//g") .*$/p" | cut -d" " -f2 | tail -n1):$(cat ./userapisetting | sed -n "/^$(echo "$2" | sed "s/ .*//g") .*$/p" | cut -d" " -f3 | tail -n1)" "https://api.hitbtc.com/api/3/futures/order" -d "type=market&symbol=$(echo $bidask)USDT_PERP&side=buy&quantity=$(echo "$linuxlinuxweb8888")&margin_mode=cross"

fi

#break

#fi

#sleep 1

#done
