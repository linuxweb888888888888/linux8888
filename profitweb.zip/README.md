# HitBTC AI Scalper Bot v3.4.1

## Features
- **Hybrid Engine**: Runs in Browser (React) or Headless (Node.js).
- **AI Strategy**: RandomForest Regression logic with RSI, Bollinger Bands, StochRSI, and Divergence detection.
- **Risk Management**: De-Risking at 60% margin usage, Fee-Adjusted Take Profits, and Break-Even protection.
- **High Value Simulation**: Treats 0.01 Real USDT as 1M Virtual USDT.

## Getting Started

### Option 1: Quick Download
1. Open `download.html` in your browser.
2. Click "Download .ZIP".
3. Extract the folder.

### Option 2: Setup
1. Install Node.js v20+
2. Run `./install.sh` (or `npm install` manually).
3. Run `node headless.js` to start trading.

## Web Dashboard
The React dashboard code is located in `index.tsx` and `App.tsx`. It requires a React build environment (Vite/CRA) to compile fully, but `server.js` is configured to serve the static output if built.
