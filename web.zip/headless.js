
/**
 * HitBTC AI Scalper - Headless Node.js Edition
 * Run this script to execute the bot 24/7 without a browser.
 * Usage: node headless.js
 */

const fetch = require('node-fetch');
const ccxt = require('ccxt');

// --- CONFIGURATION ---
const MIN_QTY = 0.001;
const SYMBOL = 'ATOMUSDT_PERP';
const TAKER_FEE_RATE = 0.0009;
const LEVERAGE = 20;
const RSI_PERIOD = 14;
const EMA_PERIOD = 20;
const BB_PERIOD = 20;
const BB_MULTIPLIER = 2;
const SCALING_FACTOR = 100_000_000;
const MIN_ROIE_PCT = 0.0015;
const MICRO_PROFIT_TARGET = 0.00006;
const MAX_WALLET_USAGE_PCT = 0.60;
const BASE_GRID_DEVIATION = 0.002;
const PYRAMID_THRESHOLD_PNL = 0.0005;
const STALEMATE_THRESHOLD_MS = 15 * 60 * 1000;

const API_KEY = '-3Mn7DL8P20iTj7QPoOSgyATuDcF-87h';
const API_SECRET = 'WzxCckLuICMXcjdRL-CbgcsbpGXHePcs';

// --- STATE ---
let priceHistory = [];
let rsiHistory = [];
let ccxtExchange = null;
let market = { symbol: SYMBOL, mid: 0, bid: 0, ask: 0, timestamp: 0 };
let activePosition = null;
let wallet = { 
    balance: 0, 
    usedMargin: 0, 
    freeMargin: 0, 
    totalProfit: 0, 
    efficiencyIndex: 90 
};
let signal = { direction: 'NEUTRAL', confidence: 0, features: {} };

// --- HELPERS ---
function log(msg, type='INFO') {
    const ts = new Date().toLocaleTimeString();
    console.log(`[${ts}] [${type}] ${msg}`);
}

function calculateRSI(prices) {
  if (prices.length < RSI_PERIOD + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = prices.length - RSI_PERIOD; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff >= 0) gains += diff; else losses -= diff;
  }
  if (losses === 0) return 100;
  const rs = gains / losses;
  return 100 - (100 / (1 + rs));
}

function calculateBollingerBands(prices) {
    if (prices.length < BB_PERIOD) return { position: 0.5 };
    const slice = prices.slice(-BB_PERIOD);
    const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
    const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / slice.length;
    const stdDev = Math.sqrt(variance);
    const upper = mean + (BB_MULTIPLIER * stdDev);
    const lower = mean - (BB_MULTIPLIER * stdDev);
    const current = prices[prices.length - 1];
    let position = 0.5;
    if (upper - lower !== 0) position = (current - lower) / (upper - lower);
    return { upper, lower, position };
}

function calculateEMA(prices, period) {
    if (prices.length < period) return prices[prices.length - 1];
    const k = 2 / (period + 1);
    let ema = prices[0];
    for (let i = 1; i < prices.length; i++) ema = (prices[i] * k) + (ema * (1 - k));
    return ema;
}

function calculateStandardDeviation(prices) {
    if (prices.length < 5) return 0;
    const mean = prices.reduce((a, b) => a + b, 0) / prices.length;
    const variance = prices.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / prices.length;
    return Math.sqrt(variance);
}

function calculateDivergence(prices, rsis) {
    if (prices.length < 10 || rsis.length < 10) return 0;
    const pC = prices[prices.length - 1], pP = prices[prices.length - 6];
    const rC = rsis[rsis.length - 1], rP = rsis[rsis.length - 6];
    if (pC < pP && rC > rP + 2) return 1;
    if (pC > pP && rC < rP - 2) return -1;
    return 0;
}

// --- CORE ---
async function init() {
    try {
        ccxtExchange = new ccxt.hitbtc({ apiKey: API_KEY, secret: API_SECRET, options: { defaultType: 'future' } });
        log('HitBTC API Initialized (Headless Mode)', 'SUCCESS');
    } catch (e) { log(e.message, 'ERROR'); }
}

async function updateMarket() {
    try {
        const ticker = await ccxtExchange.fetchTicker(SYMBOL);
        market.mid = (ticker.bid + ticker.ask) / 2;
        market.bid = ticker.bid;
        market.ask = ticker.ask;
        market.timestamp = Date.now();
        priceHistory.push(market.mid);
        if (priceHistory.length > 100) priceHistory.shift();
    } catch (e) {}
}

async function syncWallet() {
    try {
        const bal = await ccxtExchange.fetchBalance({ type: 'future' });
        const usdt = bal['USDT'];
        if (usdt) {
            wallet.balance = usdt.total || 0;
            wallet.freeMargin = usdt.free || 0;
            wallet.usedMargin = usdt.used || 0;
        }
    } catch (e) {}
}

async function syncPosition() {
    try {
        const positions = await ccxtExchange.fetchPositions([SYMBOL]);
        const pos = positions.find(p => p.symbol === SYMBOL);
        if (pos && parseFloat(pos.contracts) > 0) {
            activePosition = {
                direction: pos.side.toUpperCase(),
                entryPrice: parseFloat(pos.entryPrice),
                size: parseFloat(pos.contracts),
                unrealizedPnL: parseFloat(pos.unrealizedPnl || 0),
                timestamp: activePosition ? activePosition.timestamp : Date.now(),
                highestPnL: activePosition ? Math.max(activePosition.highestPnL, parseFloat(pos.unrealizedPnl)) : parseFloat(pos.unrealizedPnl)
            };
        } else {
            activePosition = null;
        }
    } catch (e) {}
}

async function order(side, amount) {
    try {
        log(`Placing ${side} ${amount}`, 'WARNING');
        await ccxtExchange.createMarketOrder(SYMBOL, side, amount);
        log('Order Executed', 'SUCCESS');
    } catch (e) { log(e.message, 'ERROR'); }
}

// --- STRATEGY LOOP ---
async function loop() {
    await updateMarket();
    await syncWallet();
    await syncPosition();

    // Indicators
    const rsi = calculateRSI(priceHistory);
    rsiHistory.push(rsi);
    if (rsiHistory.length > 50) rsiHistory.shift();
    const bb = calculateBollingerBands(priceHistory);
    const ema = calculateEMA(priceHistory, EMA_PERIOD);
    const stdDev = calculateStandardDeviation(priceHistory.slice(-20));
    const volatility = (stdDev / market.mid) * 1000;
    const divergence = calculateDivergence(priceHistory, rsiHistory);
    
    // Logic
    const atLower = bb.position <= 0.1;
    const atUpper = bb.position >= 0.9;
    const isOversold = rsi < 35;
    const isOverbought = rsi > 65;
    let dir = 'NEUTRAL';
    let conf = 0;

    if (atLower && isOversold) { dir = 'LONG'; conf = 75 + (divergence===1?15:0); }
    else if (atUpper && isOverbought) { dir = 'SHORT'; conf = 75 + (divergence===-1?15:0); }
    
    // Execution
    if (!activePosition && dir !== 'NEUTRAL' && conf > 55) {
         const walletUsage = wallet.usedMargin / wallet.balance;
         if (walletUsage < MAX_WALLET_USAGE_PCT && wallet.freeMargin > 0.01) {
             await order(dir === 'LONG' ? 'buy' : 'sell', MIN_QTY);
         }
    } else if (activePosition) {
        // PnL Management
        const pnl = activePosition.unrealizedPnL;
        const size = activePosition.size;
        const entry = activePosition.entryPrice;
        const fee = (size * entry * TAKER_FEE_RATE) * 2;
        const target = Math.max(fee * 3, (size * entry * MIN_ROIE_PCT));
        
        if (pnl > target * 1.1) { // Force Take Profit
             log(`Take Profit: ${pnl}`, 'SUCCESS');
             await order(activePosition.direction === 'LONG' ? 'sell' : 'buy', size);
        } else if (activePosition.highestPnL > target && pnl < target * 0.8) { // Ratchet
             log(`Ratchet Stop: ${pnl}`, 'WARNING');
             await order(activePosition.direction === 'LONG' ? 'sell' : 'buy', size);
        } else if (pnl < -0.0005 && conf > 80) { // Stop & Reverse
             log('Stop & Reverse', 'WARNING');
             await order(activePosition.direction === 'LONG' ? 'sell' : 'buy', size);
        }
        
        // De-Risking
        if (wallet.usedMargin / wallet.balance > 0.85 && pnl < -0.0005) {
             log('De-Risking Trim', 'WARNING');
             await order(activePosition.direction === 'LONG' ? 'sell' : 'buy', MIN_QTY);
        }
    }
}

// Start
init().then(() => setInterval(loop, 2000));
console.log("Headless Bot Started. Press Ctrl+C to stop.");
