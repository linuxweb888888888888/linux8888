<?php

$linux8888 = file("/profitprofitprofitprofitlinuxlinux8888" . $argv[1] . "linux8888@gmail.com");

$real = $linux8888;
$timePeriod = 4;

$timePeriod8888 = 6;

$data = trader_mom($real,$timePeriod);

$data = trader_sma($data,$timePeriod8888);

$data = trader_sma($data,$timePeriod8888);

$arr = $data;
$len = count($arr);
$tmp = array_fill(0, $len, 0);
$data8888 = array_merge($tmp, $arr);

$data8888 = array_slice($data8888, 0,-4);

$linux88888888 = implode("\n",$data8888);

file_put_contents("/var/www/html/linuxlinuxwebweb8888","$linux88888888");

$linux88888888 = end($data8888);

$real = $linux8888;
$timePeriod = 4;

$timePeriod8888 = 6;

$data = trader_mom($real,$timePeriod);

$data = trader_sma($data,$timePeriod8888);

$data = trader_sma($data,$timePeriod8888);

$arr = $data;
$len = count($arr);
$tmp = array_fill(0, $len, 0);
$data = array_merge($tmp, $arr);

//$data8888 = array_slice($data8888, 0, count($data), true);

$linux8888 = implode("\n",$data);

file_put_contents("/var/www/html/linuxlinuxwebweblinuxlinux8888","$linux8888");

$reverse = array_reverse($data);
$linux1 = $reverse[5];

$linux2 = $reverse[3];

$linux8888 = end($data);

if ($linux2 > $linux8888)

{

if ($linux1 < $linux2)

{

if ($linux8888 < 0)

{

echo "buy";

}

}

}

else

{

if ($linux2 < $linux8888)

{

if ($linux1 > $linux2)

{

if ($linux8888 > 0)

{

echo "sell";

}

}

}

}

?>
