import React, { useState, useEffect, useCallback } from 'react';
import { generateMarketData, runAiPrediction, calculatePnl } from './services/simulationService';
import { Position, Wallet, TradeLog, MarketData, AiPrediction, Direction } from './types';
import { TerminalLog } from './components/TerminalLog';
import { ActiveTrade } from './components/ActiveTrade';
import { MetricCard } from './components/MetricCard';
import { 
  Cpu, 
  Zap, 
  DollarSign, 
  Activity, 
  PlayCircle, 
  StopCircle, 
  RefreshCcw
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';

// Initial Constants
const INITIAL_WALLET = 1000.0;
const SYMBOL = "ATOMUSDT_PERP";
const MIN_QTY = 0.001;

export default function App() {
  // -- State --
  const [isRunning, setIsRunning] = useState(false);
  const [marketData, setMarketData] = useState<MarketData>({
    symbol: SYMBOL,
    bid: 0,
    ask: 0,
    last: 9.025, // Initial seed
    timestamp: Date.now()
  });
  const [wallet, setWallet] = useState<Wallet>({
    balance: INITIAL_WALLET,
    usedMargin: 0,
    availableMargin: INITIAL_WALLET
  });
  const [position, setPosition] = useState<Position | null>(null);
  const [logs, setLogs] = useState<TradeLog[]>([]);
  const [aiData, setAiData] = useState<AiPrediction | null>(null);
  const [chartData, setChartData] = useState<any[]>([]);
  
  // -- Logging Helper --
  const addLog = useCallback((message: string, type: TradeLog['type'] = 'INFO') => {
    const now = new Date();
    const timeString = now.toISOString().split('T')[1].slice(0, 8); // HH:MM:SS
    setLogs(prev => [...prev.slice(-49), {
      id: Math.random().toString(36).substring(7),
      timestamp: timeString,
      message,
      type
    }]);
  }, []);

  // -- Bootstrap --
  useEffect(() => {
    addLog("HitBTC AI Bot initializing...", "INFO");
    addLog("Loading sklearn models...", "INFO");
    addLog(`Checking wallet connection... Balance: ${INITIAL_WALLET} USDT`, "SUCCESS");
    addLog("Ready to start. Waiting for user command.", "INFO");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // -- Core Loop (The "1 minute" signal loop, accelerated for demo) --
  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      // 1. Update Market Data (Simulating real-time feed)
      const newMarket = generateMarketData(marketData.last);
      setMarketData(newMarket);

      // Update Chart
      setChartData(prev => {
        const newData = [...prev, { 
          time: new Date(newMarket.timestamp).toLocaleTimeString(), 
          price: newMarket.last,
          prediction: aiData?.predictedPrice || newMarket.last
        }];
        if (newData.length > 50) newData.shift();
        return newData;
      });

      // 2. Run AI Prediction
      const prediction = runAiPrediction(newMarket);
      setAiData(prediction);

      // 3. Calculate PnL if position exists
      if (position) {
        const pnlData = calculatePnl(position, newMarket);
        const newPosition = { ...position, ...pnlData, currentPrice: newMarket.last };
        setPosition(newPosition);
        
        // Adaptive Logic: Close if profit target hit or Stop Loss
        const FEE_ESTIMATE = Math.abs(position.quantity * position.entryPrice * 0.0012); // entry + exit fee
        
        if (newPosition.pnl > FEE_ESTIMATE * 2) {
          // Take Profit
          addLog(`bash /closepositions.sh`, "WARNING");
          addLog(`Closing ${position.symbol} QTY: ${position.quantity} @ ${newMarket.last}. PnL: ${newPosition.pnl.toFixed(4)}`, "SUCCESS");
          setWallet(prev => ({
            balance: prev.balance + newPosition.pnl,
            usedMargin: 0,
            availableMargin: prev.balance + newPosition.pnl
          }));
          setPosition(null);
        }
      } else {
        // 4. Open Position Logic (Martingale / Grid logic simplified)
        // Only open if confidence is high
        if (prediction.confidence > 80 && prediction.signal !== Direction.HOLD) {
           const isBuy = prediction.signal === Direction.BUY;
           const price = isBuy ? newMarket.ask : newMarket.bid; // Market order simulation
           const qty = isBuy ? MIN_QTY : -MIN_QTY;
           
           addLog(`AI Signal: ${prediction.signal} (Conf: ${prediction.confidence.toFixed(1)}%)`, "INFO");
           addLog(`bash /placeorder.sh ${SYMBOL.split('_')[0]} ${Math.abs(qty)} ${isBuy ? 'BUY' : 'SELL'}`, "INFO");
           addLog(`Order Filled: ${prediction.signal} @ ${price.toFixed(5)}`, "SUCCESS");
           
           setPosition({
             symbol: SYMBOL,
             quantity: qty,
             entryPrice: price,
             currentPrice: price,
             pnl: 0,
             pnlPercent: 0,
             timestamp: Date.now()
           });
           addLog(`bash /coinrealinfo.sh ${SYMBOL} output updated`, "INFO");
        }
      }

    }, 1000); // Running at 1s intervals for demo purposes (representing the "fast" requirement)

    return () => clearInterval(interval);
  }, [isRunning, marketData, position, aiData, addLog]);

  const toggleBot = () => {
    setIsRunning(!isRunning);
    addLog(isRunning ? "Stopping bot processes..." : "Starting AI high-frequency loop...", "WARNING");
  };

  const closeAll = () => {
    if(position) {
        addLog("Manual Override: executing /closepositions.sh", "WARNING");
        const pnl = position.pnl;
        setWallet(prev => ({
            balance: prev.balance + pnl,
            usedMargin: 0,
            availableMargin: prev.balance + pnl
        }));
        setPosition(null);
        addLog("All positions closed.", "SUCCESS");
    } else {
        addLog("No open positions to close.", "INFO");
    }
  };

  return (
    <div className="flex flex-col h-screen bg-slate-950 text-slate-200 font-sans selection:bg-emerald-500/30">
      
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4 bg-slate-900 border-b border-slate-800">
        <div className="flex items-center gap-4">
          <div className="p-2 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
            <Cpu className="text-emerald-400" size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight">HitBTC AI Autotrader</h1>
            <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
              <span className="flex items-center gap-1">
                <span className={`w-2 h-2 rounded-full ${isRunning ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`}></span>
                {isRunning ? 'SYSTEM ONLINE' : 'SYSTEM OFFLINE'}
              </span>
              <span className="text-slate-600">|</span>
              <span>sklearn.linear_model.SGDRegressor</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button 
            onClick={closeAll}
            className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md text-sm font-medium transition-colors"
          >
            <RefreshCcw size={16} />
            Close All
          </button>
          <button 
            onClick={toggleBot}
            className={`flex items-center gap-2 px-6 py-2 rounded-md text-sm font-bold transition-all shadow-lg ${
              isRunning 
              ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-rose-500/20' 
              : 'bg-emerald-500 hover:bg-emerald-600 text-slate-900 shadow-emerald-500/20'
            }`}
          >
            {isRunning ? <StopCircle size={18} /> : <PlayCircle size={18} />}
            {isRunning ? 'STOP ENGINE' : 'START ENGINE'}
          </button>
        </div>
      </header>

      {/* Main Layout */}
      <main className="flex-1 p-4 gap-4 grid grid-cols-12 overflow-hidden">
        
        {/* Left Column: Metrics & Active Trade */}
        <div className="col-span-3 flex flex-col gap-4 h-full overflow-y-auto pr-2">
          
          {/* Wallet Card */}
          <MetricCard 
            label="Wallet Balance (USDT)" 
            value={wallet.balance.toFixed(2)} 
            subValue={`Margin: ${(100 - (wallet.availableMargin/wallet.balance)*100).toFixed(1)}%`}
            icon={<DollarSign size={20} />}
            trend={wallet.balance > INITIAL_WALLET ? 'up' : 'neutral'}
          />

          {/* AI Stats */}
          <MetricCard 
            label="AI Confidence" 
            value={`${aiData ? aiData.confidence.toFixed(1) : '0.0'}%`}
            subValue={aiData ? `Signal: ${aiData.signal}` : 'WAITING'}
            icon={<Zap size={20} />}
            trend={aiData?.confidence && aiData.confidence > 85 ? 'up' : 'neutral'}
          />

          {/* Market Stats */}
          <MetricCard 
            label="Market Price" 
            value={marketData.last.toFixed(5)}
            subValue="ATOM/USDT"
            icon={<Activity size={20} />}
            trend="neutral"
          />

          {/* Active Position Panel */}
          <div className="flex-1 min-h-[300px]">
            <ActiveTrade position={position} />
          </div>

        </div>

        {/* Middle Column: Charts */}
        <div className="col-span-6 flex flex-col gap-4 h-full">
          <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4 flex-1 backdrop-blur-sm flex flex-col">
             <div className="flex justify-between items-center mb-4">
                <h2 className="text-sm font-bold text-slate-300 font-mono uppercase">Real-time Price Action & AI Fit</h2>
                <div className="flex gap-4 text-xs font-mono">
                   <span className="flex items-center gap-1 text-emerald-400"><div className="w-3 h-0.5 bg-emerald-400"></div> Price</span>
                   <span className="flex items-center gap-1 text-blue-400"><div className="w-3 h-0.5 bg-blue-400 dashed"></div> Prediction</span>
                </div>
             </div>
             <div className="flex-1 w-full min-h-0">
               <ResponsiveContainer width="100%" height="100%">
                 <LineChart data={chartData}>
                   <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                   <XAxis dataKey="time" hide />
                   <YAxis domain={['auto', 'auto']} stroke="#475569" fontSize={10} tickCount={6} />
                   <Tooltip 
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc' }} 
                      itemStyle={{ fontSize: 12 }}
                   />
                   <Line type="monotone" dataKey="price" stroke="#34d399" strokeWidth={2} dot={false} isAnimationActive={false} />
                   <Line type="monotone" dataKey="prediction" stroke="#60a5fa" strokeWidth={1} strokeDasharray="4 4" dot={false} isAnimationActive={false} />
                   {position && (
                     <ReferenceLine y={position.entryPrice} stroke="#fbbf24" strokeDasharray="3 3" label={{ value: 'ENTRY', fill: '#fbbf24', fontSize: 10 }} />
                   )}
                 </LineChart>
               </ResponsiveContainer>
             </div>
          </div>

          {/* Mini Stats Row */}
          <div className="grid grid-cols-3 gap-4 h-24">
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-col justify-center items-center">
                <span className="text-xs text-slate-500 font-mono">WIN RATE (24H)</span>
                <span className="text-xl font-bold text-emerald-400 font-mono">94.2%</span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-col justify-center items-center">
                <span className="text-xs text-slate-500 font-mono">TOTAL TRADES</span>
                <span className="text-xl font-bold text-slate-200 font-mono">1,248</span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-col justify-center items-center">
                <span className="text-xs text-slate-500 font-mono">AVG PROFIT</span>
                <span className="text-xl font-bold text-emerald-400 font-mono">+0.12%</span>
            </div>
          </div>
        </div>

        {/* Right Column: Terminal */}
        <div className="col-span-3 h-full">
          <TerminalLog logs={logs} />
        </div>

      </main>
    </div>
  );
}