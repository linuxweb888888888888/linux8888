import { Direction, MarketData, Position, AiPrediction } from '../types';

// Simulation constants
const INITIAL_PRICE = 9.025;
const VOLATILITY = 0.005;
const FEE_RATE = 0.0006; // Futures fee

export const generateMarketData = (prevPrice: number): MarketData => {
  const change = (Math.random() - 0.5) * VOLATILITY;
  const newPrice = Math.max(0.000001, prevPrice + change);
  const spread = 0.001;
  
  return {
    symbol: 'ATOMUSDT_PERP',
    last: newPrice,
    bid: newPrice - spread / 2,
    ask: newPrice + spread / 2,
    timestamp: Date.now(),
  };
};

export const runAiPrediction = (marketData: MarketData): AiPrediction => {
  // Mocking sklearn SDRegressor logic
  const rsi = 30 + Math.random() * 40; // Random RSI between 30-70
  const cci = (Math.random() - 0.5) * 200;
  
  let signal = Direction.HOLD;
  if (rsi < 35) signal = Direction.BUY;
  if (rsi > 65) signal = Direction.SELL;

  const noise = (Math.random() - 0.5) * 0.02;
  const predictedPrice = marketData.last * (1 + noise);

  return {
    predictedPrice,
    confidence: 75 + Math.random() * 20, // 75-95% confidence
    signal,
    features: {
      rsi,
      cci,
      trendStrength: Math.random() * 100,
    }
  };
};

export const calculatePnl = (position: Position, currentMarket: MarketData): { pnl: number, pnlPercent: number } => {
  if (position.quantity === 0) return { pnl: 0, pnlPercent: 0 };
  
  const isLong = position.quantity > 0;
  // For Long, exit at Bid. For Short, exit at Ask.
  const exitPrice = isLong ? currentMarket.bid : currentMarket.ask;
  
  // Raw PnL calculation
  const rawPnl = isLong 
    ? (exitPrice - position.entryPrice) * Math.abs(position.quantity)
    : (position.entryPrice - exitPrice) * Math.abs(position.quantity);
    
  return {
    pnl: rawPnl,
    pnlPercent: (rawPnl / (position.entryPrice * Math.abs(position.quantity))) * 100
  };
};