export enum Direction {
  BUY = 'BUY',
  SELL = 'SELL',
  HOLD = 'HOLD'
}

export interface Position {
  symbol: string;
  quantity: number;
  entryPrice: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
  timestamp: number;
}

export interface Wallet {
  balance: number; // USDT
  usedMargin: number;
  availableMargin: number;
}

export interface TradeLog {
  id: string;
  timestamp: string;
  message: string;
  type: 'INFO' | 'SUCCESS' | 'ERROR' | 'WARNING';
}

export interface MarketData {
  symbol: string;
  bid: number;
  ask: number;
  last: number;
  timestamp: number;
}

export interface AiPrediction {
  predictedPrice: number;
  confidence: number; // 0-100
  signal: Direction;
  features: {
    rsi: number;
    cci: number;
    trendStrength: number;
  };
}