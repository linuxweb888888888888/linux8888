import React from 'react';

interface MetricCardProps {
  label: string;
  value: string | number;
  subValue?: string;
  trend?: 'up' | 'down' | 'neutral';
  icon?: React.ReactNode;
  color?: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({ label, value, subValue, trend, icon, color = "slate" }) => {
  const trendColor = trend === 'up' ? 'text-emerald-400' : trend === 'down' ? 'text-rose-400' : 'text-slate-400';
  const borderColor = trend === 'up' ? 'border-emerald-500/20' : trend === 'down' ? 'border-rose-500/20' : 'border-slate-700/50';

  return (
    <div className={`bg-slate-900/50 border ${borderColor} rounded-lg p-4 flex items-start justify-between backdrop-blur-sm`}>
      <div>
        <p className="text-slate-400 text-xs font-mono uppercase tracking-wider mb-1">{label}</p>
        <h3 className={`text-2xl font-bold font-mono ${trendColor}`}>{value}</h3>
        {subValue && <p className="text-slate-500 text-xs mt-1 font-mono">{subValue}</p>}
      </div>
      {icon && <div className={`p-2 rounded-md bg-slate-800/50 ${trendColor}`}>{icon}</div>}
    </div>
  );
};