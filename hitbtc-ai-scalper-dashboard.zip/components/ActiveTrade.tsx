import React from 'react';
import { Position, Direction } from '../types';
import { TrendingUp, TrendingDown, Wallet } from 'lucide-react';

interface ActiveTradeProps {
  position: Position | null;
}

export const ActiveTrade: React.FC<ActiveTradeProps> = ({ position }) => {
  if (!position || position.quantity === 0) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-slate-600 border border-slate-800 border-dashed rounded-lg bg-slate-900/20 p-8">
        <Wallet className="mb-3 opacity-50" size={32} />
        <span className="text-sm font-mono">NO ACTIVE POSITIONS</span>
        <span className="text-xs mt-1">Waiting for AI Signal...</span>
      </div>
    );
  }

  const isLong = position.quantity > 0;
  const pnlColor = position.pnl >= 0 ? 'text-emerald-400' : 'text-rose-400';
  const bgPnl = position.pnl >= 0 ? 'bg-emerald-500/10' : 'bg-rose-500/10';
  const borderColor = position.pnl >= 0 ? 'border-emerald-500/30' : 'border-rose-500/30';

  return (
    <div className={`bg-slate-900 border ${borderColor} rounded-lg p-5 h-full flex flex-col justify-between relative overflow-hidden`}>
      <div className={`absolute top-0 right-0 p-2 px-4 rounded-bl-lg text-xs font-bold font-mono flex items-center gap-2 ${isLong ? 'bg-emerald-500 text-slate-950' : 'bg-rose-500 text-slate-950'}`}>
        {isLong ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
        {isLong ? 'LONG' : 'SHORT'}
      </div>

      <div className="space-y-6 mt-2">
        <div>
          <div className="text-xs text-slate-400 uppercase tracking-wider font-mono mb-1">Symbol</div>
          <div className="text-2xl font-bold text-slate-100 font-mono">{position.symbol}</div>
        </div>

        <div className="grid grid-cols-2 gap-4">
           <div>
            <div className="text-xs text-slate-500 uppercase font-mono mb-1">Quantity</div>
            <div className="text-lg font-mono text-slate-200">{Math.abs(position.quantity).toFixed(3)}</div>
           </div>
           <div>
            <div className="text-xs text-slate-500 uppercase font-mono mb-1">Entry Price</div>
            <div className="text-lg font-mono text-slate-200">{position.entryPrice.toFixed(5)}</div>
           </div>
        </div>

        <div className={`p-4 rounded-lg ${bgPnl} border border-dashed ${borderColor}`}>
           <div className="flex justify-between items-end">
             <div>
               <div className="text-xs text-slate-400 uppercase font-mono mb-1">Unrealized PnL</div>
               <div className={`text-3xl font-bold font-mono ${pnlColor}`}>
                 {position.pnl > 0 ? '+' : ''}{position.pnl.toFixed(4)} USDT
               </div>
             </div>
             <div className={`text-sm font-mono font-bold ${pnlColor}`}>
               {position.pnlPercent > 0 ? '+' : ''}{position.pnlPercent.toFixed(2)}%
             </div>
           </div>
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t border-slate-800 text-xs font-mono text-slate-500 flex justify-between">
         <span>Source: coinrealinfo.sh</span>
         <span>Margin: Cross</span>
      </div>
    </div>
  );
};