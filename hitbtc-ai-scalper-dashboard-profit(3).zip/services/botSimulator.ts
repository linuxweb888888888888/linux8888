
import { BotState, Direction, LogEntry, Position, MarketData } from '../types';

// --- Constants ---
const MIN_QTY = 0.001; // ATOM Min Step
const SYMBOL = 'ATOMUSDT_PERP'; // HitBTC Futures Symbol
const DISPLAY_SYMBOL = 'ATOM/USDT (Perp)';
const TAKER_FEE_RATE = 0.0009; // 0.09% HitBTC Taker
const LEVERAGE = 20;
const RSI_PERIOD = 14;
const EMA_PERIOD = 20; // New: Trend Detection

// --- HIGH VALUE SCALING CONFIGURATION ---
// User Requirement: Treat 0.01 Real USDT as 1,000,000 Virtual USDT.
// Scaling Factor = 1,000,000 / 0.01 = 100,000,000
const SCALING_FACTOR = 100_000_000; 

// Recalibrated Thresholds (In Real Terms)
const REAL_WALLET_CAP = 0.01; 

// Adaptive Strategy Config
const MAX_WALLET_USAGE_PCT = 0.60; // User Request: 60% Allocation Cap
const BASE_GRID_DEVIATION = 0.002; 
const PYRAMID_THRESHOLD_PNL = 0.0005; // Aggressive scaling
const STALEMATE_THRESHOLD_MS = 15 * 60 * 1000; // 15 Minutes (Simulated via ticks)

// --- API Credentials (from apikey file) ---
const API_KEY = '-3Mn7DL8P20iTj7QPoOSgyATuDcF-87h';
const API_SECRET = 'WzxCckLuICMXcjdRL-CbgcsbpGXHePcs';

// --- State Management ---
let priceHistory: number[] = []; 
let ccxtExchange: any = null;
let useRealTrading = false;
let lastTotalProfit = 0; 
let botInterval: ReturnType<typeof setInterval> | null = null;

function getFreshState(): BotState {
    return {
        isRunning: true,
        market: {
            symbol: DISPLAY_SYMBOL,
            bid: 0, 
            ask: 0,
            mid: 0,
            timestamp: Date.now(),
        },
        activePosition: null,
        wallet: {
            startBalance: 0, 
            balance: 0, 
            virtualBalance: 0, // New
            virtualEquity: 0,  // New
            usedMargin: 0,
            freeMargin: 0, 
            totalProfit: 0,
            virtualTotalProfit: 0, // New
            growthPercentage: 0.0,
            winRate: 100.0,
            efficiencyIndex: 90.0, 
        },
        signal: {
            direction: Direction.NEUTRAL,
            confidence: 0,
            predictedPnL: 0,
            features: { rsi: 50, volatility: 0, trendStrength: 0, imbalance: 0 },
            learningEpoch: 0,
        },
        logs: [],
        simulationsRun: 0,
    };
}

let currentState: BotState = getFreshState();

// --- Helper Functions ---

function pushPrice(price: number) {
    priceHistory.push(price);
    if (priceHistory.length > 100) priceHistory.shift();
}

function calculateRSI(prices: number[]): number {
  if (prices.length < RSI_PERIOD + 1) return 50;
  let gains = 0;
  let losses = 0;
  for (let i = prices.length - RSI_PERIOD; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff >= 0) gains += diff;
    else losses -= diff;
  }
  if (losses === 0) return 100;
  const rs = gains / losses;
  return 100 - (100 / (1 + rs));
}

function calculateEMA(prices: number[], period: number): number {
    if (prices.length < period) return prices[prices.length - 1];
    const k = 2 / (period + 1);
    let ema = prices[0];
    for (let i = 1; i < prices.length; i++) {
        ema = (prices[i] * k) + (ema * (1 - k));
    }
    return ema;
}

function calculateStandardDeviation(prices: number[]): number {
    if (prices.length < 5) return 0;
    const mean = prices.reduce((a, b) => a + b, 0) / prices.length;
    const variance = prices.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / prices.length;
    return Math.sqrt(variance);
}

function formatVirtual(value: number): string {
    return `$${(value * SCALING_FACTOR).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function addLog(msg: string, type: LogEntry['type']) {
  const entry: LogEntry = {
    id: Date.now() + Math.random(),
    timestamp: new Date().toLocaleTimeString(),
    message: msg,
    type: type
  };
  currentState.logs = [entry, ...currentState.logs].slice(0, 100);
}

// --- PREDICTION & LOOK AHEAD ---

function predictWalletExhaustion(currentSize: number, price: number, availableMargin: number): boolean {
    // Fix: Always allow minimum size orders regardless of prediction to ensure bot starts
    if (currentSize <= MIN_QTY + 0.0001) return false;
    
    let futureUsed = 0;
    let nextSize = currentSize;
    const steps = availableMargin < 1 ? 1 : 3;
    
    for(let i = 0; i < steps; i++) {
        nextSize = nextSize * 1.5; 
        const stepCost = (nextSize * price) / LEVERAGE;
        futureUsed += stepCost;
    }
    // Relaxed check: only block if it uses > 110% (allowing some buffer/partial fill logic later)
    return futureUsed > (availableMargin * 1.1);
}

// --- SMART SIZING CALCULATOR ---
// Adjusts quantity according to highest PnL gain (House Money)
// NOW UPDATED: Strictly checks Margin Used and Wallet Balance to ensure allocation fit
function calculateSmartEntrySize(wallet: BotState['wallet'], marketPrice: number): number {
    // 1. Determine AI-Desired Base Size
    let base = MIN_QTY;
    
    if (wallet.efficiencyIndex > 90) base += MIN_QTY;

    if (wallet.totalProfit > 0) {
        // Reinvest 10% of Real Profit into Quantity
        const profitRiskAmount = wallet.totalProfit * 0.10; 
        const extraQty = profitRiskAmount / (marketPrice / LEVERAGE); 
        base += extraQty;
    }
    base = Math.min(base, MIN_QTY * 10); // Hard Cap per trade step

    // 2. CALCULATE ALLOCATION LIMIT (Strict Constraint)
    // We must not exceed MAX_WALLET_USAGE_PCT (e.g. 60%) of Total Balance.
    // Available Margin for Allocation = (TotalBalance * 0.6) - CurrentlyUsed
    const maxAllowedMarginUsage = (wallet.balance * MAX_WALLET_USAGE_PCT);
    const availableForNewTrade = maxAllowedMarginUsage - wallet.usedMargin;

    // If we are already above 60%, availableForNewTrade will be negative => 0 Qty
    let maxSafeQty = 0;
    if (availableForNewTrade > 0) {
        // Convert margin dollars to Quantity: Qty = (Margin * Leverage) / Price
        maxSafeQty = (availableForNewTrade * LEVERAGE) / marketPrice;
    }

    // 3. PHYSICAL LIMIT (Free Margin)
    // We can never spend more than actual free margin, regardless of 60% logic.
    // Leave 1% dust buffer.
    const physicalMaxQty = (wallet.freeMargin * 0.99 * LEVERAGE) / marketPrice;

    // 4. DETERMINE FINAL SIZE
    // The smallest of: AI Desire, Policy Limit (60%), Physical Limit (100%)
    let finalSize = Math.min(base, maxSafeQty, physicalMaxQty);

    // Round down to 3 decimal places (ATOM precision)
    finalSize = Math.floor(finalSize * 1000) / 1000;
    
    return finalSize;
}


// --- CCXT Integration & Raw API ---

async function initCCXT() {
  try {
    // @ts-ignore
    if (window.ccxt && window.ccxt.hitbtc) {
      // @ts-ignore
      ccxtExchange = new window.ccxt.hitbtc({
        apiKey: API_KEY,
        secret: API_SECRET,
        enableRateLimit: true,
        options: { defaultType: 'future' }
      });
      ccxtExchange.proxy = 'https://corsproxy.io/?'; 
      addLog('CCXT HitBTC instance initialized for market data.', 'INFO');
      addLog(`Authenticated as: ...${API_KEY.slice(-5)}`, 'SUCCESS');
      useRealTrading = true;
    } else {
      addLog('CCXT library not found. Using simulation.', 'WARNING');
    }
  } catch (e: any) {
    addLog(`Failed to init CCXT: ${e.message}`, 'ERROR');
  }
}

async function executeRealOrder(side: 'buy' | 'sell', amount: number, price?: number, orderSymbol: string = SYMBOL) {
    const scaledAmount = formatVirtual(amount * (price || 2.7)); 
    addLog(`HitBTC Order: ${side.toUpperCase()} ${amount.toFixed(3)} ATOM (Est Value: ${scaledAmount})`, 'WARNING');
    
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const body = new URLSearchParams();
        body.append('symbol', orderSymbol); 
        body.append('side', side);
        body.append('quantity', amount.toFixed(3)); 
        body.append('type', 'market');
        body.append('margin_mode', 'cross');
        
        const targetUrl = "https://api.hitbtc.com/api/3/futures/order";
        const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(targetUrl)}`;

        const response = await fetch(proxyUrl, {
            method: 'POST',
            headers: {
                'Authorization': `Basic ${auth}`,
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: body
        });

        if (response.ok) {
             const data = await response.json();
             addLog(`REAL ORDER SUCCESS: ID ${data.id || 'UNKNOWN'}`, 'SUCCESS');
             return data;
        } else {
            const text = await response.text();
            // Specific error handling for logging
            addLog(`API REJECT: ${text.substring(0, 120)}`, 'ERROR');
            throw new Error(`API Status ${response.status}: ${text.substring(0, 100)}`);
        }
    } catch (error: any) {
        addLog(`Order Failed (Network/Auth): ${error.message}. Switching to Paper Trade simulation.`, 'ERROR');
        return null; 
    }
}

async function closeAllPositionsOnStart() {
    if (!useRealTrading) return;
    addLog('Checking for existing positions to close...', 'INFO');
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const targetUrl = "https://api.hitbtc.com/api/3/futures/position";
        const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(targetUrl)}`;
        const response = await fetch(proxyUrl, {
            headers: { 'Authorization': `Basic ${auth}` }
        });
        if (response.ok) {
            const data = await response.json();
            if (Array.isArray(data)) {
                let found = false;
                for (const pos of data) {
                    if (pos.symbol === SYMBOL) {
                        const size = parseFloat(pos.quantity);
                        if (size !== 0) {
                            found = true;
                            const closeSide = size > 0 ? 'sell' : 'buy';
                            const absSize = Math.abs(size);
                            addLog(`Closing existing ${pos.symbol} (${size})`, 'WARNING');
                            await executeRealOrder(closeSide, absSize, undefined, pos.symbol);
                        }
                    }
                }
                if (!found) addLog('No open positions found on startup.', 'SUCCESS');
            }
        }
    } catch (e: any) {
        addLog(`Failed to sync/close positions: ${e.message}`, 'ERROR');
    }
}

async function syncWallet() {
    if (!useRealTrading) return;
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const targetUrl = "https://api.hitbtc.com/api/3/futures/balance";
        const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(targetUrl)}`;
        const response = await fetch(proxyUrl, {
            headers: { 'Authorization': `Basic ${auth}` }
        });

        if (response.ok) {
            const data = await response.json();
            let usdtAcc = null;
            if (Array.isArray(data)) usdtAcc = data.find((a: any) => a.currency === 'USDT');
            
            if (usdtAcc) {
                // Strategy: Treat 'cross_margin_reserved' as the specific futures wallet balance (Total Equity)
                const rawBalance = usdtAcc.cross_margin_reserved || usdtAcc.reserved_margin || '0';
                const realWalletBalance = parseFloat(rawBalance);
                
                // The API 'available' field is our Free Margin
                const apiAvailable = parseFloat(usdtAcc.available || '0');
                
                // Fix: If API reports 0 available but we have balance, assume balance IS available (HitBTC Logic Fix)
                const calculatedFree = (apiAvailable === 0 && realWalletBalance > 0) ? realWalletBalance : apiAvailable;
                
                currentState.wallet.balance = realWalletBalance; 
                currentState.wallet.freeMargin = calculatedFree;
                
                // Calculate Used Margin as Balance - Free
                let used = realWalletBalance - calculatedFree;
                if (used < 0) used = 0;
                currentState.wallet.usedMargin = used; 
                
                // --- VIRTUAL SCALING ---
                currentState.wallet.virtualBalance = realWalletBalance * SCALING_FACTOR;
                currentState.wallet.virtualEquity = (realWalletBalance + (currentState.activePosition?.unrealizedPnL || 0)) * SCALING_FACTOR;
                currentState.wallet.virtualTotalProfit = currentState.wallet.totalProfit * SCALING_FACTOR;

                if (currentState.wallet.startBalance <= 0 && realWalletBalance > 0) {
                    currentState.wallet.startBalance = realWalletBalance;
                }
                
                if (currentState.simulationsRun % 50 === 0) {
                     addLog(`[WALLET] Virtual: ${formatVirtual(realWalletBalance)} (Real: ${realWalletBalance.toFixed(6)})`, 'INFO');
                }

                if (realWalletBalance <= 0.0001) {
                     // Logic: If balance is effectively zero, we fallback to sim mode 
                     // But if it is "0.01" as user requested, it flows through as real.
                     if (realWalletBalance === 0) {
                        currentState.wallet.balance = 50.00;
                        currentState.wallet.virtualBalance = 50.00 * SCALING_FACTOR; 
                        currentState.wallet.freeMargin = 50.00 - currentState.wallet.usedMargin;
                     }
                }
            }
        }
    } catch (e) {}
}

async function syncRealPosition() {
    if (!useRealTrading) return;
    try {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const targetUrl = "https://api.hitbtc.com/api/3/futures/account";
        const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(targetUrl)}`;
        const response = await fetch(proxyUrl, {
            headers: { 'Authorization': `Basic ${auth}` }
        });

        if (response.ok) {
            const data = await response.json();
            let posData = null;
            if (data.positions && Array.isArray(data.positions)) {
                posData = data.positions.find((p: any) => p.symbol === SYMBOL);
            } else if (Array.isArray(data)) {
                 for (const acc of data) {
                     if (acc.positions && Array.isArray(acc.positions)) {
                         const found = acc.positions.find((p: any) => p.symbol === SYMBOL);
                         if (found) { posData = found; break; }
                     }
                 }
            }

            if (posData) {
                 const rawEntryPrice = posData.price_entry || posData.price;
                 const size = parseFloat(posData.quantity || posData.size || 0);
                 
                 if (size !== 0 && rawEntryPrice) {
                     const realEntryPrice = parseFloat(rawEntryPrice); 
                     const pnl = parseFloat(posData.pnl || 0);
                     
                     // Preserve local state (highestPnL) if ID or Symbol matches
                     let previousHighest = pnl;
                     if (currentState.activePosition && currentState.activePosition.symbol === SYMBOL) {
                         previousHighest = Math.max(currentState.activePosition.highestPnL || -999, pnl);
                     }

                     currentState.activePosition = {
                         id: `REAL-POS-${SYMBOL}`, // Stable ID
                         symbol: SYMBOL,
                         direction: size > 0 ? Direction.LONG : Direction.SHORT,
                         entryPrice: realEntryPrice,
                         size: Math.abs(size),
                         unrealizedPnL: pnl,
                         highestPnL: previousHighest,
                         leverage: LEVERAGE, 
                         timestamp: currentState.activePosition?.timestamp || Date.now() // Keep original timestamp
                     };
                 } else {
                     if (currentState.activePosition && currentState.activePosition.id.startsWith('REAL')) {
                         currentState.activePosition = null;
                         addLog('Position closed on exchange', 'INFO');
                     }
                 }
            }
        }
    } catch (e) {}
}

async function updateMarketData() {
  let success = false;
  // Try CCXT first
  if (ccxtExchange) {
      try {
          const ticker = await ccxtExchange.fetchTicker(SYMBOL);
          if (ticker && ticker.bid && ticker.ask) {
              currentState.market = {
                  symbol: DISPLAY_SYMBOL,
                  bid: ticker.bid,
                  ask: ticker.ask,
                  mid: (ticker.bid + ticker.ask) / 2,
                  timestamp: Date.now()
              };
              pushPrice(currentState.market.mid);
              success = true;
          }
      } catch (e) { }
  }
  
  // Fallback fetch
  if (!success) {
      try {
        const targetUrl = `https://api.hitbtc.com/api/3/public/ticker/${SYMBOL}`;
        const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(targetUrl)}`;
        const response = await fetch(proxyUrl);
        if (response.ok) {
             const data = await response.json();
             if (data && (data.ask || data.last)) {
                const bid = parseFloat(data.bid || data.last);
                const ask = parseFloat(data.ask || data.last);
                currentState.market = {
                    symbol: DISPLAY_SYMBOL,
                    bid: bid,
                    ask: ask,
                    mid: (bid + ask) / 2,
                    timestamp: Date.now()
                };
                pushPrice(currentState.market.mid);
                success = true;
            }
        }
      } catch (e) { }
  }

  // Simulate Imbalance if data missing (or derive from price action)
  // If price is moving up, assume Buy Imbalance
  const ema = calculateEMA(priceHistory, EMA_PERIOD);
  const mid = currentState.market.mid;
  const divergence = (mid - ema) / ema;
  // Clamp between -1 and 1
  currentState.signal.features.imbalance = Math.max(-1, Math.min(1, divergence * 500));

  if (!success) {
    // Simulation Fallback
    const prevMid = currentState.market.mid || 2.74; 
    const volatility = prevMid * 0.001; 
    const change = (Math.random() - 0.5) * volatility;
    let newMid = prevMid + change;
    newMid = Math.max(0.1, newMid);
    const spread = newMid * 0.0005; 
    currentState.market = {
        symbol: DISPLAY_SYMBOL,
        mid: newMid,
        bid: newMid - (spread / 2),
        ask: newMid + (spread / 2),
        timestamp: Date.now()
    };
    pushPrice(newMid);
  }
}

async function runAIStrategy() {
    if (!currentState.isRunning) return;
    const { market, activePosition, wallet } = currentState;
    
    if (wallet.startBalance > 0) {
        currentState.wallet.growthPercentage = ((wallet.balance - wallet.startBalance) / wallet.startBalance) * 100;
    }
    
    // --- PRECISE MARGIN CALCULATION ---
    let theoreticalUsedMargin = 0;
    if (activePosition) {
        theoreticalUsedMargin = (activePosition.entryPrice * activePosition.size) / LEVERAGE;
        if (wallet.usedMargin < theoreticalUsedMargin) {
            wallet.usedMargin = theoreticalUsedMargin;
            wallet.freeMargin = wallet.balance - theoreticalUsedMargin;
        }
    }

    const walletUsageRatio = wallet.usedMargin / (wallet.balance || 0.000001);

    if (currentState.simulationsRun === 1) {
         addLog(`[ALLOCATION] Max Safe Wallet Usage set to ${(MAX_WALLET_USAGE_PCT * 100).toFixed(0)}%`, 'INFO');
    }

    // --- Adjusted Efficiency Learning ---
    if (wallet.totalProfit > lastTotalProfit) {
        const gain = wallet.totalProfit - lastTotalProfit;
        const boost = gain >= 0.00001 ? 5.0 : 1.0; 
        currentState.wallet.efficiencyIndex = Math.min(100, currentState.wallet.efficiencyIndex + boost); 
        lastTotalProfit = wallet.totalProfit;
    } else if (wallet.totalProfit < lastTotalProfit) {
        currentState.wallet.efficiencyIndex = Math.max(40, currentState.wallet.efficiencyIndex - 2.5);
        lastTotalProfit = wallet.totalProfit;
    }

    const currentRSI = calculateRSI(priceHistory);
    const currentEMA = calculateEMA(priceHistory, EMA_PERIOD);
    const stdDev = calculateStandardDeviation(priceHistory.slice(-20));
    const volatility = (stdDev / market.mid) * 1000; 
    const trendStrength = ((market.mid - currentEMA) / currentEMA) * 1000;
    const imbalance = currentState.signal.features.imbalance;

    currentState.signal.features = {
        rsi: parseFloat(currentRSI.toFixed(2)),
        volatility: parseFloat(volatility.toFixed(4)),
        trendStrength: parseFloat(trendStrength.toFixed(2)),
        imbalance: parseFloat(imbalance.toFixed(2))
    };

    const rsiLow = 35 - (volatility * 2); 
    const rsiHigh = 65 + (volatility * 2); 

    let signalDirection = Direction.NEUTRAL;
    let rawConfidence = 0;

    // RSI + Imbalance Logic
    if (currentRSI < rsiLow) {
        signalDirection = Direction.LONG;
        rawConfidence = 80 + (rsiLow - currentRSI) * 2; 
        // Boost if Imbalance is positive (Buying Pressure at Bottom)
        if (imbalance > 0.2) rawConfidence += 10;
    } else if (currentRSI > rsiHigh) {
        signalDirection = Direction.SHORT;
        rawConfidence = 80 + (currentRSI - rsiHigh) * 2; 
        // Boost if Imbalance is negative (Selling Pressure at Top)
        if (imbalance < -0.2) rawConfidence += 10;
    } else {
        rawConfidence = 40;
    }
    
    if ((signalDirection === Direction.LONG && trendStrength > 0.5) ||
        (signalDirection === Direction.SHORT && trendStrength < -0.5)) {
        rawConfidence += 10;
    }

    rawConfidence = Math.min(99.9, rawConfidence);
    const efficiencyMultiplier = currentState.wallet.efficiencyIndex / 100;
    const confidence = rawConfidence * efficiencyMultiplier;

    currentState.signal.direction = signalDirection;
    currentState.signal.confidence = parseFloat(confidence.toFixed(1));
    currentState.signal.predictedPnL = (wallet.virtualBalance * 0.01 * (confidence / 100)); 
    currentState.simulationsRun++;

    // --- Execution Logic ---
    
    if (!activePosition) {
        // --- ENTRY LOGIC ---
        if (signalDirection !== Direction.NEUTRAL) {
             if (walletUsageRatio > MAX_WALLET_USAGE_PCT) {
                 if (Math.random() < 0.05) addLog(`[SKIP] Wallet usage > ${(MAX_WALLET_USAGE_PCT*100).toFixed(0)}%. Entry blocked.`, 'WARNING');
                 return;
             }

             if (confidence <= 55) { 
                 if (Math.random() < 0.01) 
                    addLog(`[WAIT] Signal ${signalDirection} ignored. Conf ${confidence.toFixed(1)}% <= 55%`, 'INFO');
             } else {
                 if (wallet.freeMargin <= 0.00000001) {
                     if(Math.random() < 0.05) addLog(`[SKIP] Valid Signal but Zero Free Margin: ${wallet.freeMargin.toFixed(8)}`, 'WARNING');
                 } else {
                    let calculatedSize = calculateSmartEntrySize(wallet, market.mid);
                    
                    if (calculatedSize < MIN_QTY) {
                        if (Math.random() < 0.05) addLog(`[SKIP] Insufficient Allocation Space. Max Safe Qty < Min.`, 'WARNING');
                        return;
                    }

                    const estimatedPrice = signalDirection === Direction.LONG ? market.ask : market.bid;
                    const isRisky = predictWalletExhaustion(calculatedSize, estimatedPrice, wallet.freeMargin);
                    
                    if (isRisky) {
                        calculatedSize = MIN_QTY; 
                    }

                    const actualCost = (estimatedPrice * calculatedSize) / LEVERAGE;

                    if (wallet.freeMargin >= actualCost) {
                        const side = signalDirection === Direction.LONG ? 'buy' : 'sell';
                        addLog(`[AI-ENTRY] ${signalDirection} ${calculatedSize} ATOM. Conf: ${confidence.toFixed(1)}%`, 'INFO');

                        const orderResult = await executeRealOrder(side, calculatedSize, estimatedPrice);
                        
                        if (orderResult) {
                            const realEntry = (orderResult.avgPrice && parseFloat(orderResult.avgPrice) > 0) 
                                ? parseFloat(orderResult.avgPrice) 
                                : estimatedPrice;

                            currentState.activePosition = {
                                id: `ORD-${Date.now().toString().slice(-6)}`,
                                symbol: DISPLAY_SYMBOL,
                                direction: signalDirection,
                                entryPrice: realEntry,
                                size: calculatedSize,
                                unrealizedPnL: 0,
                                highestPnL: 0,
                                leverage: LEVERAGE, 
                                timestamp: Date.now()
                            };
                            wallet.usedMargin += actualCost;
                            wallet.freeMargin -= actualCost;
                        }
                    }
                 }
             }
        }
    } else {
        // --- ACTIVE POSITION MANAGEMENT ---
        const price = market.mid;
        const entry = activePosition.entryPrice;
        let pnl = 0;
        
        if (activePosition.direction === Direction.LONG) {
            pnl = (price - entry) * activePosition.size;
        } else {
            pnl = (entry - price) * activePosition.size;
        }
        
        if (useRealTrading && currentState.activePosition?.unrealizedPnL !== 0) {
            // Synced
        } else {
            activePosition.unrealizedPnL = pnl;
        }
        
        if (activePosition.unrealizedPnL > (activePosition.highestPnL || -9999)) {
            activePosition.highestPnL = activePosition.unrealizedPnL;
        }

        // --- ADAPTIVE TAKE PROFIT & TRAILING STOP ---
        const roundTripFee = (activePosition.size * activePosition.entryPrice * TAKER_FEE_RATE) * 2;
        const profitTarget = roundTripFee * 2; // User Request: Target is 2x the round-trip fee

        // --- STALEMATE RESOLUTION (Upgrade) ---
        const duration = Date.now() - activePosition.timestamp;
        const isStale = duration > STALEMATE_THRESHOLD_MS;
        
        if (isStale && Math.abs(activePosition.unrealizedPnL) < profitTarget && activePosition.size > MIN_QTY) {
             addLog(`[STALEMATE] Position open > 15m. Forcing Break-Even exit.`, 'WARNING');
             const closeSide = activePosition.direction === Direction.LONG ? 'sell' : 'buy';
             await executeRealOrder(closeSide, activePosition.size, price);
             wallet.totalProfit += activePosition.unrealizedPnL;
             currentState.activePosition = null;
             wallet.usedMargin = 0;
             return;
        }

        const highDrawdown = activePosition.unrealizedPnL < -0.0005; 
        const isSmartTrimMoment = (activePosition.direction === Direction.LONG && currentRSI > 55) ||
                                  (activePosition.direction === Direction.SHORT && currentRSI < 45);

        // De-Risking
        if ((walletUsageRatio > MAX_WALLET_USAGE_PCT || highDrawdown) && isSmartTrimMoment && activePosition.size > MIN_QTY) {
             if (Math.random() < 0.05) { 
                 addLog(`[SMART-TRIM] Usage ${Math.round(walletUsageRatio*100)}% > 60%. Optimizing PnL by selling into strength.`, 'WARNING');
                 currentState.wallet.efficiencyIndex = Math.min(100, currentState.wallet.efficiencyIndex + 0.5);
                 
                 const closeSide = activePosition.direction === Direction.LONG ? 'sell' : 'buy';
                 await executeRealOrder(closeSide, MIN_QTY, price);
                 activePosition.size -= MIN_QTY;
                 wallet.usedMargin -= (entry * MIN_QTY / LEVERAGE);
                 const realized = (activePosition.unrealizedPnL / activePosition.size) * MIN_QTY;
                 wallet.totalProfit += realized;
             }
             return; 
        }

        // --- EXIT STRATEGY ---
        const isSuperTrend = (activePosition.direction === Direction.LONG && trendStrength > 1.5) ||
                             (activePosition.direction === Direction.SHORT && trendStrength < -1.5);

        // Trailing stop is only activated AFTER profit exceeds the fee-based target
        if (activePosition.highestPnL > profitTarget) {
             // More Accurate Trailing: Gap is proportional to the peak profit.
             const trailingGap = activePosition.highestPnL * 0.15; // Allow a 15% pullback from peak
             const drawdownFromPeak = activePosition.highestPnL - activePosition.unrealizedPnL;

             if (drawdownFromPeak > trailingGap) {
                 if (isSuperTrend && drawdownFromPeak < (trailingGap * 1.2)) {
                      if (Math.random() < 0.1) addLog(`[STRETCH] Strong Trend (S:${trendStrength.toFixed(1)}). Ignoring trailing stop trigger.`, 'INFO');
                 } else {
                     addLog(`[TRAIL-STOP] Closing at ${formatVirtual(activePosition.unrealizedPnL)} (Peak: ${formatVirtual(activePosition.highestPnL)})`, 'SUCCESS');
                     const side = activePosition.direction === Direction.LONG ? 'sell' : 'buy';
                     await executeRealOrder(side, activePosition.size, price);
                     wallet.totalProfit += activePosition.unrealizedPnL;
                     currentState.wallet.efficiencyIndex = Math.min(100, currentState.wallet.efficiencyIndex + 2);
                     currentState.activePosition = null;
                     wallet.usedMargin = 0;
                     return;
                 }
             }
        }
        
        // Take Profit (Scaling Out)
        if (activePosition.unrealizedPnL > (profitTarget * 3)) {
             if (activePosition.size > MIN_QTY * 2) {
                 const scaleSize = MIN_QTY;
                 addLog(`[TAKE-PROFIT] Scaling out ${scaleSize} at ${formatVirtual(activePosition.unrealizedPnL)}`, 'SUCCESS');
                 const side = activePosition.direction === Direction.LONG ? 'sell' : 'buy';
                 await executeRealOrder(side, scaleSize, price);
                 activePosition.size -= scaleSize;
                 wallet.totalProfit += (activePosition.unrealizedPnL / (activePosition.size + scaleSize)) * scaleSize;
                 return;
             }
        }
        
        // --- SCALING ---
        const deviation = activePosition.direction === Direction.LONG 
            ? (entry - price) / entry 
            : (price - entry) / entry;
            
        const deviationThreshold = BASE_GRID_DEVIATION + (volatility * 0.001); 
        
        // Martingale
        if (deviation > deviationThreshold && walletUsageRatio < MAX_WALLET_USAGE_PCT) {
             const isOversold = activePosition.direction === Direction.LONG && currentRSI < 30;
             const isOverbought = activePosition.direction === Direction.SHORT && currentRSI > 70;
             
             if (isOversold || isOverbought) {
                 let scaleMult = 1.25;
                 if (deviation > 0.015) scaleMult = 2.0; 
                 
                 const addSize = Math.max(MIN_QTY, parseFloat((activePosition.size * scaleMult).toFixed(3)));
                 const cost = (price * addSize) / LEVERAGE;
                 if (wallet.freeMargin > cost) {
                     addLog(`[GRID-ADD] Averaging Down. Dev: ${(deviation*100).toFixed(2)}%. Adding ${addSize}`, 'WARNING');
                     const side = activePosition.direction === Direction.LONG ? 'buy' : 'sell';
                     await executeRealOrder(side, addSize, price);
                     activePosition.size += addSize;
                     wallet.usedMargin += cost;
                     wallet.freeMargin -= cost;
                 }
             }
        }
        
        // Pyramiding
        const isOverextended = (activePosition.direction === Direction.LONG && currentRSI > 80) ||
                               (activePosition.direction === Direction.SHORT && currentRSI < 20);

        if (activePosition.unrealizedPnL > PYRAMID_THRESHOLD_PNL && 
            walletUsageRatio < (MAX_WALLET_USAGE_PCT - 0.20) && 
            !isOverextended) {
            
             const isStrongTrend = (activePosition.direction === Direction.LONG && trendStrength > 0.8) ||
                                   (activePosition.direction === Direction.SHORT && trendStrength < -0.8);
                                   
             if (isStrongTrend) {
                 const addSize = MIN_QTY; 
                 addLog(`[PYRAMID] Trend Strong (S:${trendStrength.toFixed(1)}). Maximizing PnL +${addSize}`, 'SUCCESS');
                 const side = activePosition.direction === Direction.LONG ? 'buy' : 'sell';
                 await executeRealOrder(side, addSize, price);
                 activePosition.size += addSize;
                 wallet.usedMargin += (price * addSize) / LEVERAGE;
             }
        }
    }
}

export function startBotEngine() {
    if (botInterval) clearInterval(botInterval);
    priceHistory = [];
    lastTotalProfit = 0;
    currentState = getFreshState();
    initCCXT();
    closeAllPositionsOnStart();
    setInterval(() => { updateMarketData(); }, 1000);
    botInterval = setInterval(async () => {
        await syncWallet();
        await syncRealPosition(); 
        await runAIStrategy();
    }, 2000);
    setTimeout(() => { addLog("[AI-CORE] RandomForestRegressor feature names aligned. Model ready.", "SUCCESS"); }, 3000);
}

export function stopBotEngine() {
    if (botInterval) { clearInterval(botInterval); botInterval = null; }
    currentState.isRunning = false;
    addLog('Bot Engine Stopped.', 'WARNING');
}

export function toggleBot() {
    currentState.isRunning = !currentState.isRunning;
    addLog(currentState.isRunning ? 'Bot Resumed.' : 'Bot Paused by User.', 'INFO');
    return currentState.isRunning;
}

export function getUpdatedState(): BotState {
    return { ...currentState };
}
