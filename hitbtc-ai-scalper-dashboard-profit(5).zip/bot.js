const ccxt = require('ccxt');
const chalk = require('chalk');
const fs = require('fs');

// --- Load API Credentials ---
let apiCredentials = {};
try {
    apiCredentials = JSON.parse(fs.readFileSync('apikey.json', 'utf8'));
} catch (e) {
    console.log(chalk.red('FATAL: apikey.json not found or is invalid. Please create it with your apiKey and apiSecret.'));
    process.exit(1);
}

// --- Constants ---
const MIN_QTY = 0.001;
const SYMBOL = 'ATOM/USDT:USDT'; // CCXT format for HitBTC Futures
const DISPLAY_SYMBOL = 'ATOM/USDT (Perp)';
const TAKER_FEE_RATE = 0.0009;
const LEVERAGE = 20;
const RSI_PERIOD = 14;
const EMA_PERIOD = 20;

// --- Adaptive Strategy Config ---
const MAX_WALLET_USAGE_PCT = 0.60;
const BASE_GRID_DEVIATION = 0.002;
const PYRAMID_THRESHOLD_PNL = 0.0005;

// --- State Management ---
let priceHistory = [];
let ccxtExchange = null;
let lastTotalProfit = 0;
let botInterval = null;

let currentState = {
    isRunning: true,
    market: { symbol: DISPLAY_SYMBOL, bid: 0, ask: 0, mid: 0, timestamp: Date.now() },
    activePosition: null,
    wallet: { balance: 0, usedMargin: 0, freeMargin: 0, totalProfit: 0, efficiencyIndex: 90.0 },
    signal: {
        direction: 'NEUTRAL',
        confidence: 0,
        features: { rsi: 50, volatility: 0, trendStrength: 0, imbalance: 0 },
    },
};

// --- Helper & Logging Functions ---
const addLog = (msg, type) => {
    const timestamp = new Date().toLocaleTimeString();
    let coloredMsg = msg;
    switch (type) {
        case 'SUCCESS': coloredMsg = chalk.green(msg); break;
        case 'ERROR': coloredMsg = chalk.red(msg); break;
        case 'WARNING': coloredMsg = chalk.yellow(msg); break;
        case 'INFO': coloredMsg = chalk.blue(msg); break;
    }
    console.log(`[${timestamp}] ${coloredMsg}`);
};

const pushPrice = (price) => {
    priceHistory.push(price);
    if (priceHistory.length > 100) priceHistory.shift();
};

const calculateRSI = (prices) => {
    if (prices.length < RSI_PERIOD + 1) return 50;
    let gains = 0;
    let losses = 0;
    for (let i = prices.length - RSI_PERIOD; i < prices.length; i++) {
        const diff = prices[i] - prices[i - 1];
        if (diff >= 0) gains += diff;
        else losses -= diff;
    }
    if (losses === 0) return 100;
    const rs = gains / losses;
    return 100 - (100 / (1 + rs));
};

const calculateEMA = (prices, period) => {
    if (prices.length < period) return prices[prices.length - 1];
    const k = 2 / (period + 1);
    let ema = prices[0];
    for (let i = 1; i < prices.length; i++) {
        ema = (prices[i] * k) + (ema * (1 - k));
    }
    return ema;
};

const calculateStandardDeviation = (prices) => {
    if (prices.length < 5) return 0;
    const mean = prices.reduce((a, b) => a + b, 0) / prices.length;
    const variance = prices.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / prices.length;
    return Math.sqrt(variance);
};

// --- CCXT Exchange Functions ---

const initCCXT = async () => {
    try {
        ccxtExchange = new ccxt.hitbtc({
            apiKey: apiCredentials.apiKey,
            secret: apiCredentials.apiSecret,
            enableRateLimit: true,
            options: { defaultType: 'swap' } // Use 'swap' for perpetual futures
        });
        await ccxtExchange.loadMarkets();
        // Set leverage for the symbol
        await ccxtExchange.setLeverage(LEVERAGE, SYMBOL);
        addLog('CCXT HitBTC instance initialized and markets loaded.', 'SUCCESS');
        return true;
    } catch (e) {
        addLog(`FATAL: Failed to initialize CCXT: ${e.message}`, 'ERROR');
        return false;
    }
};

const updateMarketData = async () => {
    try {
        const ticker = await ccxtExchange.fetchTicker(SYMBOL);
        if (ticker && ticker.bid && ticker.ask) {
            currentState.market = {
                symbol: DISPLAY_SYMBOL,
                bid: ticker.bid,
                ask: ticker.ask,
                mid: (ticker.bid + ticker.ask) / 2,
                timestamp: Date.now()
            };
            pushPrice(currentState.market.mid);
        }
    } catch (e) {
        addLog(`Error fetching market data: ${e.message}`, 'WARNING');
    }
};

const syncWalletAndPosition = async () => {
    try {
        const balance = await ccxtExchange.fetchBalance({ type: 'swap' });
        const usdt = balance.USDT;
        if (usdt) {
            currentState.wallet.balance = usdt.total || 0;
            currentState.wallet.freeMargin = usdt.free || 0;
            currentState.wallet.usedMargin = usdt.used || 0;
        }

        const positions = await ccxtExchange.fetchPositions([SYMBOL]);
        const atomPosition = positions.find(p => p.symbol === SYMBOL);

        if (atomPosition && atomPosition.contracts && atomPosition.contracts !== 0) {
            currentState.activePosition = {
                symbol: DISPLAY_SYMBOL,
                direction: atomPosition.side.toUpperCase(),
                entryPrice: atomPosition.entryPrice,
                size: Math.abs(atomPosition.contracts),
                unrealizedPnL: atomPosition.unrealizedPnl,
                leverage: LEVERAGE,
                timestamp: atomPosition.timestamp
            };
        } else {
            currentState.activePosition = null;
        }
    } catch (e) {
        addLog(`Error syncing wallet/position: ${e.message}`, 'ERROR');
    }
};

const executeRealOrder = async (side, amount) => {
    addLog(`Executing REAL ORDER: ${side.toUpperCase()} ${amount.toFixed(3)} ${DISPLAY_SYMBOL}`, 'WARNING');
    try {
        const order = await ccxtExchange.createMarketOrder(SYMBOL, side, amount, { 'marginMode': 'cross' });
        addLog(`Order successful. ID: ${order.id}`, 'SUCCESS');
        return order;
    } catch (e) {
        addLog(`ORDER FAILED: ${e.message}`, 'ERROR');
        return null;
    }
};

const closeAllPositionsOnStart = async () => {
    addLog('Checking for existing positions to close...', 'INFO');
    await syncWalletAndPosition(); // Sync first
    if (currentState.activePosition) {
        const { direction, size } = currentState.activePosition;
        const closeSide = direction === 'LONG' ? 'sell' : 'buy';
        addLog(`Found open ${direction} position of size ${size}. Closing now.`, 'WARNING');
        await executeRealOrder(closeSide, size);
    } else {
        addLog('No open positions found on startup.', 'SUCCESS');
    }
};

// --- Core AI Strategy ---
const runAIStrategy = async () => {
    const { market, activePosition, wallet } = currentState;

    if (wallet.totalProfit > lastTotalProfit) {
        currentState.wallet.efficiencyIndex = Math.min(100, currentState.wallet.efficiencyIndex + 5.0);
        lastTotalProfit = wallet.totalProfit;
    } else if (wallet.totalProfit < lastTotalProfit) {
        currentState.wallet.efficiencyIndex = Math.max(40, currentState.wallet.efficiencyIndex - 2.5);
        lastTotalProfit = wallet.totalProfit;
    }

    const currentRSI = calculateRSI(priceHistory);
    const currentEMA = calculateEMA(priceHistory, EMA_PERIOD);
    const stdDev = calculateStandardDeviation(priceHistory.slice(-20));
    const volatility = (stdDev / market.mid) * 1000;
    const trendStrength = ((market.mid - currentEMA) / currentEMA) * 1000;

    currentState.signal.features = {
        rsi: parseFloat(currentRSI.toFixed(2)),
        volatility: parseFloat(volatility.toFixed(4)),
        trendStrength: parseFloat(trendStrength.toFixed(2)),
    };

    const rsiLow = 35 - (volatility * 2);
    const rsiHigh = 65 + (volatility * 2);

    let signalDirection = 'NEUTRAL';
    let rawConfidence = 0;

    if (currentRSI < rsiLow) {
        signalDirection = 'LONG';
        rawConfidence = 80 + (rsiLow - currentRSI) * 2;
    } else if (currentRSI > rsiHigh) {
        signalDirection = 'SHORT';
        rawConfidence = 80 + (currentRSI - rsiHigh) * 2;
    }
    rawConfidence = Math.min(99.9, rawConfidence);
    const confidence = rawConfidence * (currentState.wallet.efficiencyIndex / 100);

    currentState.signal.direction = signalDirection;
    currentState.signal.confidence = parseFloat(confidence.toFixed(1));

    const walletUsageRatio = wallet.usedMargin / (wallet.balance || 1);

    if (!activePosition) {
        // --- ENTRY LOGIC ---
        if (signalDirection !== 'NEUTRAL' && confidence > 55 && walletUsageRatio < MAX_WALLET_USAGE_PCT) {
            const size = MIN_QTY; // Start with minimum size
            const cost = (market.mid * size) / LEVERAGE;
            if (wallet.freeMargin > cost) {
                addLog(`[AI-ENTRY] Signal: ${signalDirection}, Confidence: ${confidence.toFixed(1)}%. Opening position.`, 'INFO');
                await executeRealOrder(signalDirection === 'LONG' ? 'buy' : 'sell', size);
            }
        }
    } else {
        // --- ACTIVE POSITION MANAGEMENT ---
        const { direction, size, entryPrice, unrealizedPnL } = activePosition;
        const roundTripFee = (size * entryPrice * TAKER_FEE_RATE) * 2;
        const profitTarget = roundTripFee * 2;

        // Take Profit / Trailing Stop
        if (unrealizedPnL > profitTarget) {
            addLog(`[TAKE-PROFIT] Target hit. PnL: ${unrealizedPnL.toFixed(6)} USDT`, 'SUCCESS');
            await executeRealOrder(direction === 'LONG' ? 'sell' : 'buy', size);
            return; // Exit after closing
        }
        
        // De-Risking / Trimming
        if (walletUsageRatio > MAX_WALLET_USAGE_PCT && size > MIN_QTY) {
            const isSmartTrimMoment = (direction === 'LONG' && currentRSI > 55) || (direction === 'SHORT' && currentRSI < 45);
            if(isSmartTrimMoment) {
                addLog(`[SMART-TRIM] Usage > 60%. Trimming position by ${MIN_QTY}.`, 'WARNING');
                await executeRealOrder(direction === 'LONG' ? 'sell' : 'buy', MIN_QTY);
            }
            return;
        }

        // Martingale (Scaling Down)
        const deviation = direction === 'LONG' ? (entryPrice - market.mid) / entryPrice : (market.mid - entryPrice) / entryPrice;
        if (deviation > BASE_GRID_DEVIATION && walletUsageRatio < MAX_WALLET_USAGE_PCT) {
            const isOversold = direction === 'LONG' && currentRSI < 30;
            const isOverbought = direction === 'SHORT' && currentRSI > 70;
            if (isOversold || isOverbought) {
                const addSize = size * 1.25;
                const cost = (market.mid * addSize) / LEVERAGE;
                if (wallet.freeMargin > cost) {
                    addLog(`[GRID-ADD] Averaging Down. Adding ${addSize.toFixed(3)}`, 'WARNING');
                    await executeRealOrder(direction === 'LONG' ? 'buy' : 'sell', addSize);
                }
            }
        }
    }
};

// --- Main Execution Loop ---
const main = async () => {
    addLog('--- HitBTC AI Scalper (Node.js) Initializing ---', 'INFO');
    const initialized = await initCCXT();
    if (!initialized) return;

    await closeAllPositionsOnStart();

    addLog('--- Starting Main Trading Loop ---', 'SUCCESS');
    botInterval = setInterval(async () => {
        try {
            await updateMarketData();
            await syncWalletAndPosition();
            await runAIStrategy();

            // --- Console Dashboard ---
            const { market, wallet, signal, activePosition } = currentState;
            let statusLine = `Price: ${market.mid.toFixed(5)} | Bal: ${wallet.balance.toFixed(4)} | Free: ${wallet.freeMargin.toFixed(4)} | Sig: ${signal.direction} (${signal.confidence}%)`;
            if (activePosition) {
                const pnlColor = activePosition.unrealizedPnL >= 0 ? chalk.green : chalk.red;
                statusLine += ` | Pos: ${activePosition.direction} ${activePosition.size} @ ${activePosition.entryPrice.toFixed(5)} | PnL: ${pnlColor(activePosition.unrealizedPnL.toFixed(6))}`;
            }
            process.stdout.write(`\r${statusLine}  `);

        } catch (e) {
            addLog(`Unhandled error in main loop: ${e.message}`, 'ERROR');
        }
    }, 3000); // Run every 3 seconds
};

main();
