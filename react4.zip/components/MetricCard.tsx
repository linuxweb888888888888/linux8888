
import React from 'react';

interface MetricCardProps {
  title: string;
  value: string | number;
  subValue?: string;
  trend?: 'up' | 'down' | 'neutral';
  color?: string;
  icon?: React.ReactNode;
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, subValue, trend, color = 'text-white', icon }) => {
  return (
    <div className="bg-slate-800 rounded-lg p-4 shadow-lg border border-slate-700/50 relative overflow-hidden">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-slate-400 text-xs font-medium uppercase tracking-wider">{title}</p>
          <h3 className={`text-2xl font-bold mt-1 ${color}`}>{value}</h3>
          {subValue && (
            <p className={`text-xs mt-1 font-mono ${
              trend === 'up' ? 'text-emerald-400' : 
              trend === 'down' ? 'text-rose-400' : 'text-slate-500'
            }`}>
              {subValue}
            </p>
          )}
        </div>
        {icon && <div className="text-slate-600 bg-slate-900/50 p-2 rounded-full">{icon}</div>}
      </div>
      
      {/* Decorative background glow */}
      <div className={`absolute -right-4 -bottom-4 w-24 h-24 rounded-full blur-3xl opacity-10 ${
         trend === 'up' ? 'bg-emerald-500' : 
         trend === 'down' ? 'bg-rose-500' : 'bg-blue-500'
      }`}></div>
    </div>
  );
};

export default MetricCard;